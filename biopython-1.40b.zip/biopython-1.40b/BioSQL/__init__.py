"""Code for storing and retrieving biological objects from relational dbs.
"""
