"""Main entry point for application command line wrappers related to sequencing.
"""
from _Novoalign import NovoalignCommandline
