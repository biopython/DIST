# This is a Python module.
"""Properties for functionality such as transcription and translation.
"""
