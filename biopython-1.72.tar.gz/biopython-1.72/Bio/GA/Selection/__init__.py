"""Support for selections in the Genetic Algorithms module."""
# TODO: Remove empty __init__.py once we drop Python 2 support
