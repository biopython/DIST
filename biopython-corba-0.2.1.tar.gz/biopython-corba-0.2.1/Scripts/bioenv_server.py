#!/usr/bin/env python
"""Start up a basic BioEnv server.

Right now this is mostly meant to fire up a server which can be used to
test all of the functionality of the Biopython client and server.

Right now has the following databases loaded up.
o opuntia_fasta - Fasta-based database of Opuntia sequences
o cor_genbank - GenBank-based database of some cold tolerance genes

The IOR for the BioEnv server is written to the file ../ior/bioenv.ior

Usage:
python bioenv_server.py

The server will block and wait for client calls, so you need to run it
in the background if you want to run a client in the same window.
"""
# standard modules
import os
import string

# biopython
from Bio import Fasta
from Bio.Alphabet import IUPAC
from Bio import GenBank

# biopython-corba
from BioCorba.Server.Seqcore import CorbaBioEnv

# -- constants
ior_file = os.path.join(os.getcwd(), os.pardir, 'ior', 'bioenv.ior')
file_dir = os.path.join(os.getcwd(), os.pardir, 'Tests', 'files')

fasta_files = [(os.path.join(file_dir, 'opuntia.fasta'), 'opuntia_fasta')]
gb_files = [(os.path.join(file_dir, 'cor6_6.gb'), 'cor_genbank')]

# create the IOR directory if it doesn't exist
if not(os.path.exists(os.path.dirname(ior_file))):
       os.makedirs(os.path.dirname(ior_file))

# useful functions for extracting accession number information
def fasta_acc_number(record):
    """Retrieve an accession number from a Fasta record.
    """
    # first split up the title by whitespace
    title_atoms = string.split(record.title)

    # now split up the accession info by '|'
    acc_atoms = string.split(title_atoms[0], '|')

    # if we've only got one thing, this is the accession number to be returned
    if len(acc_atoms) == 1:
        return acc_atoms[0]
    # otherwise, the 4th element is what we want
    else:
        return acc_atoms[3]

# now load up dictionaries for the files we want in the database
db_dict = {}
print "Creating databases..."
# load FASTA files
for fasta_info in fasta_files:
    fasta_file = fasta_info[0]
    # create the name of the index file
    file_name, ext = os.path.splitext(fasta_file)
    index_file = file_name + '.idx'

    # now index the file
    Fasta.index_file(fasta_file, index_file, fasta_acc_number)

    # now get the parser and set up the dictionary
    seq_parser = Fasta.SequenceParser(IUPAC.ambiguous_dna)
    fasta_dict = Fasta.Dictionary(index_file, seq_parser)

    # finally, add the dictionary to the list of dictionaries
    db_dict[(fasta_info[1], 1)] = fasta_dict

# load up Genbank files
for genbank_info in gb_files:
    gb_file = genbank_info[0]

    # create the name of the index file
    file_name, ext = os.path.splitext(gb_file)
    index_file = file_name + '.idx'

    # now index the file
    GenBank.index_file(gb_file, index_file)

    # now get the parser and set up the dictionary
    seqfeat_parser = GenBank.FeatureParser()
    gb_dict = GenBank.Dictionary(index_file, seqfeat_parser)

    # finally, add the dictionary to the list of dictionaries
    db_dict[(genbank_info[1], 1)] = gb_dict

# now setup the BioEnv server and write the IOR to a file
bio_env_server = CorbaBioEnv.CorbaBioEnv(db_dict)
bio_env_server.string_ior_to_file(ior_file)
print "BioEnv server is running. IOR is located at %s..." % ior_file

# run the server and wait for client calls
bio_env_server.run()
    
