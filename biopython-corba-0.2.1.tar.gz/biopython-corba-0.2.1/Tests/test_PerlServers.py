#!/usr/bin/env python
"""Test the bioperl-corba-server implementations.

This tries to do a thorough test of the Bioperl Biocorba server
implementation. To perform the test, you'll need to get the
bioperl-corba-server from Bioperl CVS. Instructions for doing this
are at:

http://cvs.bioperl.org

Usage:
python test_PerlServers.py </path/to/bioperl-corba-server>

You need to supply this with the directory where your
bioperl-corba-server is unpacked, and then this will try to do all of
the magic necessary to start the servers and test them.

Options:
--test=<name of bioperl server>   Only test the specified bioperl server, and
                                  do not automatically start the server.
"""
# standard modules
import sys
import getopt
import os
import popen2
import time
import shutil

# pyunit
import unittest

# the UnitTests for the various interfaces
import InterfaceTests

# local modules
from BioCorba.Client.BiocorbaConnect import PerlCorbaClient
from BioCorba.Client.Seqcore.CorbaBioEnv import CorbaBioEnv
from BioCorba.Client.Seqcore.CorbaPrimarySeq import CorbaPrimarySeq
from BioCorba.Client.Seqcore.CorbaPrimarySeq import CorbaPrimarySeqIterator
from BioCorba.Client.Seqcore.CorbaSeq import CorbaSeq, CorbaSeqDB

def test_bioperl_server(server_dir, server_name, client_type, unit_test,
                        extra_args = "", ior_name = None, start_server = 1):
    """Perform a test on a bioperl server.

    Arguments:

    o server_dir -- The location of the bioperl-corba-server directory.

    o server_name -- The name of the server we are going to be running
    (ie. bioenv_server.pl). This server is assumed to be in the servers
    directory, and to create an IOR file with the same name as the server
    but with .ior as the extension.

    o client_type -- The class that we will need to create a client of.

    o unit_test -- The UnitTest which should be created to test the server.

    o extra_args -- Extra arguments that need to be passed to the
    server.

    o ior_name -- Specify the name of the IOR file we need to load from the
    bioperl server. If not specified, this defaults to the name of the
    server with an ior extension.

    o start_server - Whether or not to start the specified bioperl server.
    If set at zero, we assume the server has already been started by
    other means.
    """
    print "##############"
    print "Testing bioperl-corba server %s..." % server_name
    
    # setup -- get the name of the script and the IOR file we will retrieve
    server_script = os.path.join("servers", server_name)
    base_name, ext = os.path.splitext(server_name)
    if ior_name is None:
        ior_name = base_name + '.ior'
    ior_file = os.path.join(server_dir, ior_name)

    # --- start up the server
    # we need to change into the bioperl-corba-server directory and
    # run the servers from there, otherwise the scripts won't be able
    # to find the biocorba.idl file they need
    if start_server:
        start_dir = os.getcwd()
        os.chdir(server_dir)
    
        running_server = popen2.Popen3("perl %s %s" % (server_script,
                                                       extra_args),
                                       capturestderr = 1)

        # wait for the server to start
        time.sleep(3)

        os.chdir(start_dir)

    # --- perform the test
    # get the server
    server_retriever = PerlCorbaClient(client_type)
    server_ref = server_retriever.from_file_ior(ior_file)

    # pass the server to the unittest and run it
    test_suite = unittest.makeSuite(unit_test, 't_',
                                    args = [server_ref])
    runner = unittest.TextTestRunner(sys.stdout)
    runner.run(test_suite)

    # clean up -- kill the server we started
    if start_server:
        os.kill(running_server.pid, 9)

    # --- print out whatever the server said
    # XXX Can't get popen to give up the info -- calling a read() or anything
    # similar makes it lock up :-<
    # print "******"
    # print "Server Output"
    # print running_server.childerr.read()
    # print "******"

class BioperlServerInfo:
    """Hold information about testing a biopython server.
    """
    def __init__(self, args = [], keywords = {}):
        self.args = args
        self.keywords = keywords
    
def main(argv):
    """Perform unit tests against the Bioperl Biocorba servers.
    """
        # deal with command line arguments
    try:
        options, arguments = getopt.getopt(sys.argv[1:], '', ["test="])
    except getopt.error, msg:
        print msg
        print __doc__
        return 2
                        
    if len(arguments) != 1:
        print "Only one argument should be specified."
        print __doc__
        return 2
    
    input_fasta = os.path.join(os.getcwd(), "files", "opuntia.fasta")

    # create a dictionary with all of the testing information
    all_test_info = {}
    all_test_info["simpleseq"] = BioperlServerInfo(
        [arguments[0], "simpleseq.pl", CorbaPrimarySeq,
         InterfaceTests.PrimarySeqPrint], {"extra_args": "< " + input_fasta})

    all_test_info["bioiterator"] = BioperlServerInfo(
        [arguments[0], "bioiterator.pl", CorbaPrimarySeqIterator,
         InterfaceTests.PrimarySeqIteratorPrint],
        {"extra_args" : "< " + input_fasta})

    all_test_info["seqfeatures"] = BioperlServerInfo(
        [arguments[0], "seqfeatures.pl", CorbaSeq, InterfaceTests.SeqPrint])

    all_test_info["seqdbsrv"] = BioperlServerInfo(
        [arguments[0], "seqdbsrv.pl", CorbaSeqDB, SeqDBServerTest])

    all_test_info["bioenv_server"] = BioperlServerInfo(
        [arguments[0], "bioenv_server.pl", CorbaBioEnv, BioEnvServerTest],
        {"ior_name" : "bioenv.ior"})

    # deal with possible options
    tests_to_run = []
    for option, value in options:
        if option == "--test":
            try:
                test_info = all_test_info[value]
                test_info.keywords["start_server"] = 0
                tests_to_run.append(test_info)
            except KeyError:
                print "Name passed does not match a possible Bioperl server"
                print "Servers are: %s" % all_test_info.keys()
                print __doc__
                return 2

    # if the user didn't supply any tests, we should run them all
    if len(tests_to_run) == 0:
        test_names = ["simpleseq", "bioiterator", "seqfeatures",
                      "seqdbsrv", "bioenv_server"]
        for test_name in test_names:
            tests_to_run.append(all_test_info[test_name])

    for test in tests_to_run:
        apply(test_bioperl_server, test.args, test.keywords)

# --- unittests which test various Perl Servers
class SeqDBServerTest(InterfaceTests.SeqDBPrint):
    def __init__(self, method, test_ob):
        test_acc_num = "MMWHISK" 
        InterfaceTests.SeqDBPrint.__init__(self, method, test_ob, test_acc_num)


class BioEnvServerTest(unittest.TestCase):
    def __init__(self, method, test_ob):
        self._test_ob = test_ob
        unittest.TestCase.__init__(self, method)

    def setUp(self):
        """Set up the test files to use in subsequence tests.
        """
        self.test_fasta = os.path.join(os.getcwd(), 'files',
                                       'saccharum.fasta')
        self.test_gb = os.path.join(os.getcwd(), 'files', 'cor6_6.gb')

    def t_get_SeqDB_info(self):
        """Retrieve all sequence database info from the BioEnv server.
        """
        all_seq_dbs = self._test_ob.get_SeqDB_names()

        for seq_db in all_seq_dbs:
            db_versions = self._test_ob.get_SeqDB_versions(seq_db)

            for version in db_versions:
                print "Got database %s, version %s" % seq_db, version

                print "Testing database"
                test_seq_db = self._test_ob.get_SeqDB_by_name(seq_db, version)
                test_suite = unittest.makeSuite(InterfaceTests.SeqDBPrint,
                                                't_', args = [test_seq_db])
                runner = unittest.TextTestRunner(sys.stdout)
                runner.run(test_suite)

    def t_get_PrimarySeqIterator_from_file(self):
        """Create a PrimarySeqIterator from a local file using BioEnv.
        """
        pseq_it = \
              self._test_ob.get_PrimarySeqIterator_from_file('fasta',
                                                             self.test_fasta)

        # now test the iterator
        test_suite = unittest.makeSuite(InterfaceTests.PrimarySeqIteratorPrint,
                                        't_', args = [pseq_it])
        runner = unittest.TextTestRunner(sys.stdout)
        runner.run(test_suite)

    def t_get_PrimarySeq_from_file(self):
        """Create a PrimarySeq object from a local file using BioEnv.
        """
        pseq = self._test_ob.get_PrimarySeq_from_file('fasta', self.test_fasta)

        # now test the primary seq
        test_suite = unittest.makeSuite(InterfaceTests.PrimarySeqPrint,
                                        't_', args = [pseq])
        runner = unittest.TextTestRunner(sys.stdout)
        runner.run(test_suite)

    def t_get_Seq_from_file(self):
        """Create a Seq object from a local file using BioEnv server.
        """
        seq = self._test_ob.get_Seq_from_file('genbank', self.test_gb)

        # now test the primary seq
        test_suite = unittest.makeSuite(InterfaceTests.SeqPrint,
                                        't_', args = [seq])
        runner = unittest.TextTestRunner(sys.stdout)
        runner.run(test_suite)
            
if __name__ == "__main__":
    sys.exit(main(sys.argv))
