#!/usr/bin/env python
"""Run the biopython tests as a set of PyUnit tests.

This is the top level function for running all tests.
"""
# standard modules
import sys
import cStringIO
import os

# PyUnit
import unittest

def run_tests(argv):
    all_tests = findtests()
    test_suite = unittest.TestSuite()

    for test in all_tests:
        class BiopythonTest(unittest.TestCase):
            def __init__(self, test_name):
                unittest.TestCase.__init__(self)
                self.test_name = test_name

            def shortDescription(self):
                return self.test_name
            
            def runTest(self):
                output = cStringIO.StringIO()

                # remember standard out so we can reset it after we are done
                save_stdout = sys.stdout
                try:
                    # write the output from the test into a string
                    sys.stdout = output
                    __import__(self.test_name)
                finally:
                    # return standard out to its normal setting
                    sys.stdout = save_stdout
        
        # run the test as a PyUnit test
        test_suite.addTest(BiopythonTest(test))

    runner = unittest.TextTestRunner()
    runner.run(test_suite)

def findtests():
    """Return a list of all applicable test modules."""
    testdir = findtestdir()
    names = os.listdir(testdir)
    tests = []
    for name in names:
        if name[:5] == "test_" and name[-3:] == ".py":
	    tests.append(name[:-3])
    tests.sort()
    return tests

def findtestdir():
    if __name__ == '__main__':
        file = sys.argv[0]
    else:
        file = __file__
    testdir = os.path.dirname(file) or os.curdir
    return testdir
                
if __name__ == "__main__":
    sys.exit(run_tests(sys.argv))
