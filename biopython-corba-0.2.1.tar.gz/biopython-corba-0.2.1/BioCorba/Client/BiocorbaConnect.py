# Copyright 2000 by Brad Chapman.  All rights reserved.
# This code is part of the Biopython distribution and governed by its
# license.  Please see the LICENSE file that should have been included
# as part of this package.
"""BiocorbaConnect.py

This module provides classes to connect with and get information from
different corba servers. This provides a GenericCorbaClient object which
should be used in most cases for connecting. In cases where specific hacks
are required for a server in a particular language (ie. Perl and omniORB)
the provided language specific clients should be used.

Classes:
GenericCorbaClient
PythonCorbaClient
PerlCorbaClient
JavaCorbaClient
"""
# standard modules
import os
import urllib

# the configuration file for BioCorba
from BioCorba.biocorbaconfig import *

if orb_implementation == 'Fnorb':
    # import Fnorb
    from Fnorb.orb import CORBA
elif orb_implementation == 'omniORB':
    # import omniORB
    from omniORB import CORBA
elif orb_implementation == 'ORBit':
    # import ORBit-python
    import CORBA
else:
    raise ValueError('Unsupported orb %s defined in biocorbaconfig.py' %
                     orb_implementation)

# the stubs for the client
# XXX Right now we need to import these in a specific order to prevent
# not being able to find modules. I guess this is a bug in omniidl or something
# but I haven't been able to figure it out yet, so I'll work around it.

if 'ensembl' in supported_interfaces:
    import BioCorba.org.ensembl
if 'biocorba' in supported_interfaces:
    import BioCorba.GNOME
    import BioCorba.org.biocorba.seqcore

class GenericCorbaClient:
    """Base class for connecting with corba servers.

    Provides common code for dealing with getting information from
    servers from any language. This class should be extended
    to provide a specific implementation for a language connection,
    if specific languages require workarounds.
    """
    def __init__(self, server_class):
        """Set base initialization variables and connect with the orb.

        Arguments:
        o server_class - A class object (not an instance, the actual class
        object) corresponding to the server interface we are loading from
        the object reference (IOR or naming service reference). This will
        be used to verify the remote object and to return the local
        instance of this object.
        """
        self.server_class = server_class
        self.argv = []

    def _get_ior_server(self, string_ior):
        """Return a reference to the server object from the connection.

        Arguments:
        o string_ior - The stringifier IOR to be used to get the server.
        """
        orb = CORBA.ORB_init(self.argv, CORBA.ORB_ID)
        server = orb.string_to_object(string_ior)

        return self.server_class(server)

    def from_string_ior(self, string_ior):
        return self._get_ior_server(string_ior)

    def from_file_ior(self, file_location):
        """Create a connection with a server whose IOR is specified in a file.

        Arguments:
        o file_location - The full path to the file containing the IOR.
        """
        ior_file = open(file_location, 'r')
        string_ior = ior_file.read()
        ior_file.close()

        if string_ior[0:3] != 'IOR':
            raise IOError("The passed IOR appears invalid: %s" % string_ior)

        return self._get_ior_server(string_ior)

    def from_url_ior(self, url_location):
        ior_url = urllib.urlopen(url_location)
        string_ior = ior_url.read()
        ior_url.close()

        if string_ior[0:3] != 'IOR':
            raise IOError("The passed IOR appears invalid: %s" % string_ior)

        return self._get_ior_server(string_ior)

class PythonCorbaClient(GenericCorbaClient):
    """Connect with a python implemented BioCorba server.
    """
    def __init__(self, initializer):
        GenericCorbaClient.__init__(self, initializer)

class PerlCorbaClient(GenericCorbaClient):
    """Connect with a perl implemented BioCorba server.
    """
    def __init__(self, initializer):
        """Create a client connected to a perl BioCorba server.
        
        hack/fix for dealing with the CORBA::ORBit perl server. CORBA::ORBit
        bombs out whenever an _is_a() call is make on an object, and omniORB
        calls _is_a() by default when getting an object, so we need to add
        an argument to turn off this _is_a() calling.
        """
        GenericCorbaClient.__init__(self, initializer)
        
        if orb_implementation == 'omniORB':
            self.argv = ['place_holder']
            self.argv.extend(["-ORBverifyObjectExistsAndType", "0"])

class JavaCorbaClient(GenericCorbaClient):
    """Connect with a java implemented BioCorba server.
    """
    def __init__(self, initializer):
        """Create a client connected to a java BioCorba server.
        """
        GenericCorbaClient.__init__(self, initializer)
