"""Client interface to an Ensembl CORBA Translation object.
"""
# client corba stub code
import BioCorba.org.ensembl

# Biocorba classes
from BioCorba.Client.GnomeMemory.CorbaUnknown import CorbaUnknown

class CorbaTranslation(CorbaUnknown):
    """Translation interface.
    """
    def __init__(self, corba_object):
        """Confirm the Translation object and set up the local implementation.
        """
        CorbaUnknown.__init__(self, corba_object)

        assert corba_object is not None, "Nil object reference."
    
        self._object = corba_object._narrow\
                       (BioCorba.org.ensembl.Translation)
        assert self._object is not None, "Could not narrow to Translation."

    def id(self):
        return self._object.id()

    def version(self):
        return self._object.version()

    def start_exon_id(self):
        return self._object.start_exon_id()

    def end_exon_id(self):
        return self._object.end_exon_id()

    def start(self):
        return self._object.start()

    def end(self):
        return self._object.end()
