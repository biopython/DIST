"""Client interface to an Ensembl CORBA EnsemblFactory object.
"""
# client corba stub code
import BioCorba.org.ensembl

# other Ensembl Client classes
from BioCorba.Client.Ensembl.Gene import CorbaGeneFactory
from BioCorba.Client.Ensembl.VirtualContig import CorbaVirtualContigFactory

class CorbaEnsemblFactory:
    """EnsemblFactory interface.
    """
    def __init__(self, corba_object):
        """Confirm the EnsemblFactory object and set up a local implementation.
        """
        assert corba_object is not None, "Nil object reference."
    
        self._object = corba_object._narrow\
                       (BioCorba.org.ensembl.EnsemblFactory)
        assert self._object is not None, "Could not narrow to EnsemblFactory."

    def get_GeneFactory(self):
        remote_gene_factory = self._object.get_GeneFactory()

        return CorbaGeneFactory(remote_gene_factory)

    def get_VirtualContigFactory(self):
        remote_vc_factory = self._object.get_VirtualContigFactory()

        return CorbaVirtualContigFactory(remote_vc_factory)
