"""Client interface to an Ensembl CORBA Transcript object.
"""
# client corba stub code
import BioCorba.org.ensembl

# Biocorba classes
from BioCorba.Client.GnomeMemory.CorbaUnknown import CorbaUnknown
from BioCorba.Client.Seqcore.CorbaPrimarySeq import CorbaPrimarySeq

# other Ensembl client code
from BioCorba.Client.Ensembl.Exon import CorbaExon
from BioCorba.Client.Ensembl.Translation import CorbaTranslation

class CorbaTranscript(CorbaUnknown):
    """Transcript interface.
    """
    def __init__(self, corba_object):
        """Confirm the Transcript object and set up the local implementation.
        """
        CorbaUnknown.__init__(self, corba_object)

        assert corba_object is not None, "Nil object reference."
    
        self._object = corba_object._narrow\
                       (BioCorba.org.ensembl.Transcript)
        assert self._object is not None, "Could not narrow to Transcript."

    def id(self):
        return self._object.id()

    def version(self):
        return self._object.version()

    def exons(self):
        # get the CORBA objects
        corba_exons = self._object.exons()

        # convert them into local implementation and verify the interfaces
        local_exons = []
        for corba_exon in corba_exons:
            local_exon = CorbaExon(corba_exon)

            local_exons.append(local_exon)

        return local_exons

    def translate(self):
        pseq_translation = self._object.translation()

        return CorbaPrimarySeq(pseq_translation)
    
    def get_translation(self):
        corba_translation = self._object.get_translation()

        return CorbaTranslation(corba_translation)
