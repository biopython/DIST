"""Client interface to an Ensembl Exon object.
"""
# client corba stub code
import BioCorba.org.ensembl

# Biocorba object
from BioCorba.Client.Seqcore.CorbaSeqFeature import CorbaSeqFeature
from BioCorba.Client.GnomeMemory.CorbaUnknown import CorbaUnknown

class CorbaExon(CorbaSeqFeature):
    """Exon interface.
    """
    def __init__(self, corba_object):
        """Confirm the Exon object and set up the local implementation.
        """
        CorbaUnknown.__init__(self, corba_object)

        assert corba_object is not None, "Nil object reference."
    
        self._object = corba_object._narrow\
                       (BioCorba.org.ensembl.Exon)
        assert self._object is not None, "Could not narrow to Exon."

    def id(self):
        return self._object.id()

    def version(self):
        return self._object.version()

    def phase(self):
        return self._object.phase()

    def end_phase(self):
        return self._object.end_phase()
