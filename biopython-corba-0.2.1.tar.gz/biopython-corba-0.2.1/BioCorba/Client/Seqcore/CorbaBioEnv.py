# Copyright 2000 by Brad Chapman.  All rights reserved.
# This code is part of the Biopython distribution and governed by its
# license.  Please see the LICENSE file that should have been included
# as part of this package.

# client corba stub code
import BioCorba.org.biocorba.seqcore

# local classes
from BioCorba.Client.GnomeMemory.CorbaUnknown import CorbaUnknown
from CorbaPrimarySeq import CorbaPrimarySeq
from CorbaPrimarySeq import CorbaPrimarySeqIterator
from CorbaPrimarySeq import CorbaPrimarySeqDB
from CorbaSeq import CorbaSeq
from CorbaSeq import CorbaSeqDB
import CorbaExceptions

class CorbaBioEnv(CorbaUnknown):
    def __init__(self, corba_object):
        """Confirm the BioEnv object and setup the local implementation.

        Arguments:
        o corba_object - A reference to a remote BioEnv object.
        """
        assert corba_object is not None, "Nil object reference."
    
        self._object = self._safe_narrow(corba_object,
                                         BioCorba.org.biocorba.seqcore.BioEnv)
        assert self._object is not None, "Could not narrow to BioEnv."

    def get_PrimarySeqIterator_from_file(self, format, filename):
        """Create a PrimarySeq iterator from the given file.
        """
        try:
            it_ref = self._object.get_PrimarySeqIterator_from_file(format,
                                                                   filename)
        except BioCorba.org.biocorba.seqcore.UnableToProcess, info:
            raise CorbaExceptions.UnableToProcess(info.reason)

        return CorbaPrimarySeqIterator(it_ref)
        
    def get_PrimarySeq_from_file(self, format, filename):
        try:
            p_seq = self._object.get_PrimarySeq_from_file(format, filename)
        except BioCorba.org.biocorba.seqcore.UnableToProcess, info:
            raise CorbaExceptions.UnableToProcess(info.reason)

        return CorbaPrimarySeq(p_seq)

    def get_Seq_from_file(self, format, filename):
        try:
            seq_ref = self._object.get_Seq_from_file(format, filename)
        except BioCorba.org.biocorba.seqcore.UnableToProcess, info:
            raise CorbaExceptions.UnableToProcess(info.reason)

        return CorbaSeq(seq_ref)

    def get_SeqDB_names(self):
        """Retrieve a listing of all available SeqDBs.
        """
        return self._object.get_SeqDB_names()

    def get_SeqDB_versions(self, name):
        """Retrieve all versions available for a given name.
        """
        try:
            return self._object.get_SeqDB_versions(name)
        except BioCorba.org.biocorba.seqcore.DoesNotExist, info:
            raise CorbaExceptions.DoesNotExist(info.reason)

    def get_SeqDB_by_name(self, db_name, version = 0):
        """Retrieve a SeqDB object by name and version.
        """
        try:
            seqdb_ref = self._object.get_SeqDB_by_name(db_name, version)
        except BioCorba.org.biocorba.seqcore.DoesNotExist, info:
            raise CorbaExceptions.DoesNotExist(info.reason)

        return CorbaSeqDB(seqdb_ref)
