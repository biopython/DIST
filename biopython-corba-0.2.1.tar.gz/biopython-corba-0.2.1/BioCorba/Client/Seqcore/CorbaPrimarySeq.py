# Copyright 2000 by Brad Chapman.  All rights reserved.
# This code is part of the Biopython distribution and governed by its
# license.  Please see the LICENSE file that should have been included
# as part of this package.
"""Module dealing with PrimarySeq objects

classes:
o CorbaPrimarySeq
o CorbaPrimarySeqIterator
o CorbaPrimarySeqVector
o CorbaPrimarySeqDB
"""
# client corba stub code
import BioCorba.org.biocorba.seqcore

# local classes
from BioCorba.Client.GnomeMemory.CorbaUnknown import CorbaUnknown
from CorbaAnonymousSeq import CorbaAnonymousSeq
from BioCorba.Client.GnomeMemory.CorbaUnknown import CorbaUnknown
from BioCorba.Client.Seqcore import CorbaExceptions

class CorbaPrimarySeq(CorbaAnonymousSeq):
    """PrimarySeq interface

    Represent a sequence which can be identified by ids and a version.
    This inherits from AnonymousSeq, so can also perform all operations on
    the sequence itself that are specified there.
    """
    def __init__(self, corba_object):
        """Confirm the PrimarySeq object and setup the local implementation.

        Arguments:
        o corba_object - A reference to a remote PrimarySeq object.
        """
        CorbaUnknown.__init__(self, corba_object)
        assert corba_object is not None, "Nil object reference."
    
        self._object = self._safe_narrow(corba_object,
                             BioCorba.org.biocorba.seqcore.PrimarySeq)
        assert self._object is not None, "Could not narrow to PrimarySeq."

    def display_id(self):
        return self._object.display_id()

    def primary_id(self):
        return self._object.primary_id()

    def accession_number(self):
        return self._object.accession_number()

    def version(self):
        return self._object.version()

class CorbaPrimarySeqIterator(CorbaUnknown):
    def __init__(self, corba_object):
        """Confirm the PrimarySeqIterator and setup the local implementation.

        Arguments:
        o corba_object - A reference to a remote PrimarySeqIterator object.
        """
        CorbaUnknown.__init__(self, corba_object)
        assert corba_object is not None, "Nil object reference."
    
        self._object = self._safe_narrow(corba_object,
                         BioCorba.org.biocorba.seqcore.PrimarySeqIterator)
        assert self._object is not None, \
               "Could not narrow to PrimarySeqIterator."

    def next(self):
        try:
            next_seq = self._object.next()
        except BioCorba.org.biocorba.seqcore.EndOfStream:
            raise CorbaExceptions.EndOfStream

        return CorbaPrimarySeq(next_seq)

    def has_more(self):
        return self._object.has_more()

class CorbaPrimarySeqVector(CorbaUnknown):
    """PrimarySeqVector interface

    Provide an interface to a vector of PrimarySeq objects.
    """
    def __init__(self, corba_object):
        """Confirm the PrimarySeqVector and setup the local implementation.

        Arguments:
        o corba_object - A reference to a remote PrimarySeqVector object.
        """
        CorbaUnknown.__init__(self, corba_object)
        assert corba_object is not None, "Nil object reference."
    
        self._object = self._safe_narrow(corba_object, 
                         BioCorba.org.biocorba.seqcore.PrimarySeqVector)
        assert self._object is not None, \
               "Could not narrow to PrimarySeqVector."

    def size(self):
        return self._object.size()

    def elementAt(self, index):
        try:
            pseq_ref = self._object.elementAt(index)
        except BioCorba.org.biocorba.seqcore.OutOfRange, info:
            raise CorbaExceptions.OutOfRange(info.reason)

        return CorbaPrimarySeq(pseq_ref)

    def iterator(self):
        pseqit_ref = self._object.iterator()

        return CorbaPrimarySeqIterator(pseqit_ref)

class CorbaPrimarySeqDB(CorbaUnknown):
    def __init__(self, corba_object):
        """Confirm the PrimarySeqDB object and setup the local implementation.

        Arguments:
        o corba_object - A reference to a remote PrimarySeqDB object.
        """
        CorbaUnknown.__init__(self, corba_object)
        assert corba_object is not None, "Nil object reference."
    
        self._object = self._safe_narrow(corba_object, 
                         BioCorba.org.biocorba.seqcore.PrimarySeqDB)
        assert self._object is not None, "Could not narrow to PrimarySeqDB."

    def name(self):
        return self._object.name()

    def version(self):
        return self._object.version()

    def max_sequence_length(self):
        return self._object.max_sequence_length()

    def get_PrimarySeq(self, primary_id, version = 0):
        try:
            pseq_ref = self._object.get_PrimarySeq(primary_id, version)
        except BioCorba.org.biocorba.seqcore.DoesNotExist, info:
            raise CorbaExceptions.DoesNotExist(info.reason)

        return CorbaPrimarySeq(pseq_ref)

    def get_PrimarySeqVector(self):
        pseqvector_ref = self._object.get_PrimarySeqVector()

        return CorbaPrimarySeqVector(pseqvector_ref)

