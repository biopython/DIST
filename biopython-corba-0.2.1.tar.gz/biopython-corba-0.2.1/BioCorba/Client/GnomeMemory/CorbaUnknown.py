class CorbaUnknown:
    """Memory Management interface for BioCorba.

    BioCorba classes inherit from this, which provides basic functionality
    to ensure efficient memory management. Clients call unref when objects
    are deleted, and can call ref to gain additional references to an object.
    """
    def __init__(self, corba_object):
        self._object = corba_object

    def __del__(self):
        if self._object:
            try:
                self.unref()
            # if we get a CORBA.COMM_ERROR the server died
            # and we just won't worry about unrefing
            except:
                pass

    def ref(self):
        self._object.ref()

    def unref(self):
        self._object.unref()

    def query_interface(self, repoid):
        return self._object.query_interface(repoid)

    # functions to be called by derived classes
    def _safe_narrow(self, object, interface):
        """Narrow an object to an interface, ignoring AttributeError.

        If narrow is not implemented in a python binding (ie. ORBit-python)
        than it won't be possible to narrow to a particular interface.
        In this case, we catch the AttributeError caused by the lack of
        the narrow, and just return the original object.

        This makes it possible to define narrow, even if all implementations
        do not.
        """
        try:
            return object._narrow(interface)
        except AttributeError:
            return object
