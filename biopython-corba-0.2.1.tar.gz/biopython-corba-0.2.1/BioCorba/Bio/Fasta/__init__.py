"""Biopython Fasta-like interface to BioCorba objects.
"""
# biopython-corba
from BioCorba.Bio.SeqRecord import SeqRecord
from BioCorba.Client.Seqcore.CorbaSeq import CorbaSeqDB
from BioCorba.Client.Seqcore.CorbaPrimarySeq import CorbaPrimarySeqDB
from BioCorba.Client.Seqcore.CorbaPrimarySeq import CorbaPrimarySeqIterator
from BioCorba.Client.Seqcore import CorbaExceptions

def dictionary_from_bioenv(bioenv_obj, db_name, db_version = 0, parser = None):
    """Load a Fasta dictionary from a BioEnv corba interface.

    This is a convenience function to make it easy to load a FASTA
    dictionary if you have a CORBA BioEnv object.

    Arguments:
    o bioenv_obj - The bioenv object we'll use to retrieve the sequence
    database from.
    o db_name - The name of the database we are retrieving.
    o db_version - The version of the database to retrieve (defaults to
    0, the most recent version.
    o parser - A parser object through which objects coming from the
    dictionary should be passed before returning them.

    This will raise an IOError if the dictionary cannot be located.
    """
    try:
        seq_db = bioenv_obj.get_SeqDB_by_name(db_name, db_version)
        return Dictionary(seq_db, parser)
    except CorbaExceptions.DoesNotExist, msg:
        raise IOError(msg)

class Dictionary:
    """Represent a biocorba PrimarySeqDB as a FASTA dictionary.
    """
    def __init__(self, remote_pseqdb, parser = None):
        """Initialize the dictionary like interface.

        Arguments:
        o remote_pseqdb -- an object reference to a CorbaPrimarySeqDB
        or SeqDB server.
        o parser - A parser which will convert the raw CorbaPrimarySeq or
        CorbaSeq object retrieved from BioCorba into a local object.
        """
        # determine if the object is already wrapped up inside a local client
        if isinstance(remote_pseqdb, CorbaSeqDB):
            self._seqdb_obj = remote_pseqdb
        elif isinstance(remote_pseqdb, CorbaPrimarySeqDB):
            self._db_obj = remote_pseqdb
        else:
            self._seqdb_obj = CorbaPrimarySeqDB(remote_pseqdb)
            
        self._parser = parser

    def __len__(self):
        return len(self.keys())

    def __getitem__(self, key):
        try:
            seq_obj = self._seqdb_obj.get_PrimarySeq(key, 0)
            if self._parser:
                return self._parser.parse(seq_obj)
            else:
                return seq_obj          
        except CorbaExceptions.DoesNotExist:
            raise KeyError("The key %s was not found." % key)  

    def __getattr__(self, name):
        raise NotImplementedError("Not on CORBA objects.")

    def keys(self):
        return self._seqdb_obj.accession_numbers()

def iterator_from_bioenv(bioenv_obj, filename, parser = None):
    """Convenience function to load an iterator from a CorbaBioEnv object.

    This just makes it easier to create a FASTA iterator if you start
    with a BioEnv object.

    Arguments:
    o bioenv_obj - A bioenv object (which must reference a server on the
    same machine) which we can retrieve an iterator from.
    o filename - The full path to the file to load.
    o parser - A parser object through which objects coming from the
    dictionary should be passed before returning them.

    This will raise an IOError if we can't load the file.
    """
    try:
        pseq_it = bioenv_obj.get_PrimarySeqIterator_from_file("FASTA",
                                                              filename)
        return Iterator(pseq_it, parser)
    except CorbaExceptions.UnableToProcess, msg:
        raise IOError(msg)
    
class Iterator:
    """Represent a biocorba PrimarySeqIterator as a FASTA Iterator.
    """
    def __init__(self, remote_iterator, parser = None):
        # determine if the object is already wrapped up inside a local client
        if isinstance(remote_iterator, CorbaPrimarySeqIterator):
            self._seqit_obj = remote_iterator
        else:
            self._seqit_obj = CorbaPrimarySeqIterator(remote_iterator)
            
        self._parser = parser

    def next(self):
        if self._seqit_obj.has_more():
            next_pseq = self._seqit_obj.next()
            
            if self._parser:
                return self._parser.parse(next_pseq)
            else:
                return next_pseq
        else:
            return None

class SequenceParser:
    """Convert CorbaPrimarySeq objects into BioCorba.Bio.SeqRecord objects.
    """
    def __init__(self):
        pass

    def parse(self, pseq):
        """Perform the conversion and return the new BioCorba.SeqRecord object.
        """
        return SeqRecord(pseq)
