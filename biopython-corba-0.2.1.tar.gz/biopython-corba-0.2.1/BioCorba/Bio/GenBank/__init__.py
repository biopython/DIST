"""Biopython-like GenBank interface to BioCorba objects.

This is meant to model the regular Bio.GenBank interfaces.
"""
# biopython-corba
from BioCorba.Bio.SeqRecord import SeqRecord
from BioCorba.Client.Seqcore.CorbaSeq import CorbaSeqDB
from BioCorba.Client.Seqcore import CorbaExceptions

def dictionary_from_bioenv(bioenv_obj, db_name, db_version = 0, parser = None):
    """Load a GenBank dictionary from a BioEnv corba interface.

    This is a convenience function to make it easy to load a GenBank
    dictionary if you have a CORBA BioEnv object.

    Arguments:
    o bioenv_obj - The bioenv object we'll use to retrieve the sequence
    database from.
    o db_name - The name of the database we are retrieving.
    o db_version - The version of the database to retrieve (defaults to
    0, the most recent version.
    o parser - A parser object through which objects coming from the
    dictionary should be passed before returning them.

    This will raise an IOError if the dictionary cannot be located.
    """
    try:
        seq_db = bioenv_obj.get_SeqDB_by_name(db_name, db_version)
        return Dictionary(seq_db, parser)
    except CorbaExceptions.DoesNotExist, msg:
        raise IOError(msg)
    
class Dictionary:
    """Represent a CorbaSeqDB as a GenBank dictionary.
    """
    def __init__(self, remote_seqdb, parser = None):
        """Initialize the dictionary to return information.

        Arguments:
        o remote_seqdb - An object reference to a BioCorba SeqDB
        server.
        o parser - A parser object which will determine the type of
        information returned from the dictionary (when __getitem__
        is called). This parser must implement the function parse(),
        which when given a CorbaSeq object, will return an appropriate
        Biopython object. If parser is None, then the unprocessed
        CorbaSeq object will be returned.
        """
        # determine if the object is already wrapped up inside a local client
        if isinstance(remote_seqdb, CorbaSeqDB):
            self._seqdb_obj = remote_seqdb
        else:
            self._seqdb_obj = CorbaSeqDB(remote_seqdb)
        self._parser = parser

    def __len__(self):
        return len(self.keys())

    def __getitem__(self, key):
        try:
            seq_obj = self._seqdb_obj.get_Seq(key, 0)
            if self._parser:
                return self._parser.parse(seq_obj)
            else:
                return seq_obj          
        except CorbaExceptions.DoesNotExist:
            raise KeyError("The key %s was not found." % key)      

    def __getattr__(self, name):
        raise NotImplementedError("Not on CORBA objects.")

    def keys(self):
        return self._seqdb_obj.accession_numbers()

class Iterator:
    def __init__(self, remote_iterator, parser = None):
        raise NotImplementedError("No access through BioCorba.")

    def next(self):
        raise NotImplementedError("No access through BioCorba.")

class FeatureParser:
    """Convert CorbaSeq objects into BioCorba.SeqRecord objects.
    """
    def __init__(self):
        pass

    def parse(self, seq):
        """Perform the conversion and return the new BioCorba.SeqRecord object.

        Returns the BioCorba.Bio object that mimics a Biopython SeqRecord.
        """
        return SeqRecord(seq)

