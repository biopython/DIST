# Copyright 2000 by Brad Chapman.  All rights reserved.
# This code is part of the Biopython distribution and governed by its
# license.  Please see the LICENSE file that should have been included
# as part of this package.

"""BioCorba.Bio.Seq

This is just a wrapper around corba to make dealing with sequence objects on
BioCorba work identical to dealing with them in the normal Biopython Seq
implementation. Basically, these are just calls to the appropriate BioCorba
functions.

There are some add-on functions not defined in the normal seq interface
which are defined here. Using these will make your code incompatible with
the standard Biopython library.
"""
# standard modules
import sys

# Biopython classes
import Bio.Seq
from Bio import Alphabet

# local biopython-corba stuff
from BioCorba.Client.Seqcore.CorbaAnonymousSeq import CorbaAnonymousSeq

class Seq:
    """Seq implementation class for use with the corba interface.

    Basically, this is a wrapper around the AnonymousSeq interface.
    """
    def __init__(self, remote_aseq, alphabet = None):
        """Initialize a sequence class to return just sequence info.

        Arguments:
        remote_aseq - A reference to a server implementing
        the AnonymousSeq interface functions. This will be used to
        initialize CorbaAnonymousSeq to get our local client implementation.
        """
        # determine if the object is already wrapped up inside a local client
        if isinstance(remote_aseq, CorbaAnonymousSeq):
            self._aseq_obj = remote_aseq
        else:
            self._aseq_obj = CorbaAnonymousSeq(remote_aseq)
        
        if alphabet is None:
            self.alphabet = self._get_alphabet()
        else:
            self.alphabet = alphabet

    def __getattr__(self, name):
        """Override get_attribute to provide attribute access to CORBA info.
        """
        if name == "data":
            return self.tostring()
        else:
            raise AttributeError("No attribute named %s" % name)

    def _get_alphabet(self):
        """Return a rational alphabet based on the type() of the aseq object.
        """
        # get the type to see what kind of data we have
        seq_type = self._aseq_obj.type()

        if seq_type == 'DNA':
            return Alphabet.generic_dna
        elif seq_type == 'RNA':
            return Alphabet.generic_rna
        elif seq_type == 'PROTEIN':
            return Alphabet.generic_protein
        elif seq_type == 'UNKNOWN':
            return Alphabet.generic_alphabet
        else:
            raise ValueError("Unexpected type() for alphabet %s" % seq_type)
        
    def __len__(self):
        """Wrapper around AnonymousSeq:length()"""
        return self._aseq_obj.length()

    def __getslice__(self, i, j):
        """Wrapper around AnonymousSeq:get_subseq()

        The slice returned is in the usual python fashion (as in the
        Seq interface). So 0 is the first element of the sequence, the
        first element of the slice is included in the slice returned, but
        the last element is not.

        Returns:
        A Biopython Sequence object.
        """
        # check for slices like [5:] -- set the high value equal to the end
        # of the sequence
        if j == sys.maxint:
            j = len(self)
            
        data = self._aseq_obj.subseq(i + 1, j)
        new_seq = Bio.Seq.Seq(data, self.alphabet)

        return new_seq

    def tostring(self):
        """Wrapper around AnonymousSeq:get_seq()"""
        return self._aseq_obj.seq()
