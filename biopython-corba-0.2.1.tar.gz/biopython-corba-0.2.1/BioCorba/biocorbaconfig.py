"""biocorbaconfig.py

Just a little configuration file for BioCorba.
"""

# orb_implementation
# The ORB implementation that you are using for BioCorba.
# Valid choices are:
#   o 'Fnorb'
#   o 'omniORB'
#   o 'ORBit'
orb_implementation = 'omniORB'

# The interfaces to install
# Valid options are:
#   o 'biocorba'
#   o 'ensembl'
supported_interfaces = ['biocorba', 'ensembl']

# the maximum sequence size that can be returned by a python implemented
# database.
# pick some random big size to be the maximum seqeuence to return -- 1Mb
MAX_SEQ_SIZE = 1000000

# check for incompatiblities in the options
if 'ensembl' in supported_interfaces:
    assert 'biocorba' in supported_interfaces, \
           "Ensembl support depends on BioCorba being installed."


