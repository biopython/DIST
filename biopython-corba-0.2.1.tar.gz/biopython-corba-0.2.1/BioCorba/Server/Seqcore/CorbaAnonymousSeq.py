# Copyright 2000 by Brad Chapman.  All rights reserved.
# This code is part of the Biopython distribution and governed by its
# license.  Please see the LICENSE file that should have been included
# as part of this package.

# stubs generated from the idl
import BioCorba.org__POA.biocorba.seqcore as seqcore__POA
import BioCorba.org.biocorba.seqcore as seqcore

# import the class to inheret from
from BioCorba.Server.GnomeMemory.CorbaUnknown import CorbaUnknown

# configuration variables
from BioCorba.biocorbaconfig import *

# biopython
from Bio import Alphabet

class CorbaAnonymousSeq(seqcore__POA.AnonymousSeq, CorbaUnknown):
    """Represent a sequence class that only knows sequence information.

    This class inherets from two different classes:
    * org__POA.biocorba.seqcore.AnonymousSeq - The skeleton code generated
    by the corba orb implementation defining the connection of this
    class with a corba server.
    * CorbaUnknown - The corba class from which
    this class derives in the idl. Unknown provides basic memory
    management features.
    """
    def __init__(self, sequence):
        """Initialize an AnonymousSeq object.

        Arguments:
        * seqeuence - A Bio.Seq object that we will use to get
        the information.
        """
        CorbaUnknown.__init__(self)
        self._seq = sequence

    def unref(self):
        """Use unref to get rid of unneeded references.
        """
        self._seq = None
        CorbaUnknown.unref(self)

    def type(self):
        """Return the type of sequence represented in the object.

        Uses the alphabet of the sequence to guess at what type it
        is.
        """
        if isinstance(self._seq.alphabet, Alphabet.ProteinAlphabet):
            seq_type = seqcore.SeqType.PROTEIN
        elif isinstance(self._seq.alphabet, Alphabet.DNAAlphabet):
            seq_type = seqcore.SeqType.DNA
        elif isinstance(self._seq.alphabet, Alphabet.RNAAlphabet):
            seq_type = seqcore.SeqType.RNA
        else:
            seq_type = seqcore.SeqType.UNKNOWN

        return seq_type

    def is_circular(self):
        """Define if a sequence is circular or not.

        XXX Right now always return zero, since I'm not sure how we will be
        able to know this with the Biopython setup.
        """
        return 0

    def length(self):
        """Return the length of the seqeuence.
        """
        return len(self._seq)

    def seq(self):
        """Return the actual sequence.

        Raises:
        * RequestTooLarge - If the sequence length is greater than
        the MAX_SEQ_SIZE
        """
        if self.length() > MAX_SEQ_SIZE:
            raise seqcore.RequestTooLarge \
              ('Exceeds maximum sequence size to return', MAX_SEQ_SIZE)

        return self._seq.data

    def subseq(self, start, end):
        """Retrieve a subsequence of the current sequence.

        Arguments:
        start - The first residue to get in the subsequence. This is
        in biological coordinates, so 1 is the first base.
        end - The last residue (inclusive) to get in the subsequence.

        Raises:
        * OutOfRange - If the call slices a region not in the sequence.
        * RequestTooLarge - If the slice requested is greater than
        MAX_SEQ_SIZE
        """
        # check the passed coordinates to make sure they are in the
        # sequence
        if start < 1:
            raise seqcore.OutOfRange('Start of subsequence is less then 1.')
        elif end > self.length():
            raise seqcore.OutOfRange('End of subsequence past sequence end.')
        # check the size of the request
        elif (end - start) > MAX_SEQ_SIZE:
            raise seqcore.RequestTooLarge\
                  ('Exceeds maximum sequence size to return', MAX_SEQ_SIZE)

        # Subtract one from the passed start and then get the slice to return
        # what the user is looking for.
        #
        # >>> s = Seq("ABCDEFG")
        # >>> s[1:4]
        # Seq('BCD', Alphabet())
        # >>> s[0:4]
        # Seq('ABCD', Alphabet())
        biopy_start = start - 1
        return self._seq[biopy_start:end].data
