"""Create a Server based on the current configuration settings.

Functions:
create_server

Classes:
_AbstractServer
_FnorbServer
_OmniORBServer
_ILUServer
"""
# configuration information
from BioCorba.biocorbaconfig import *

# the skeleton code
import BioCorba.org__POA.biocorba.seqcore

# the singleton server that create_server will return
global _current_server
_current_server = None

def create_server(argv = [], current_server = _current_server):
    """Generate a new server based on the configuration variables.

    This is the accessor function for getting a server object.
    XXX This function should return the same server everytime so that
    it is a singleton. I'm not positive if I've implemented this right.

    Arguments:
    argv - Command line arguments to pass to the CORBA server to be created.
    """
    if orb_implementation == 'Fnorb':
        server_class = _FnorbServer
    elif orb_implementation == 'omniORB':
        server_class = _OmniORBServer
    elif orb_implementation == 'ORBit':
        server_class = _ORBitServer
    else:
        raise NotImplementedError \
              ("Unsupported orb implementation %s in biocorbaconfig.py"
               % orb_implementation)

    # return the cached server if we've got one
    if current_server is not None:
        # sanity check for the right server type
        assert isinstance(current_server, server_class), \
               "Invalid server cached. We have %r and expected %r" \
               % (current_server, server_class)

    # create a new server if we don't have one
    else:
        current_server = server_class(argv)
        
    return current_server

class _AbstractServer:
    """Provides a general interface to the specific ORB servers.

    This must be subclassed to provide an implementation for a specific ORB.
    """
    def __init__(self):
        pass

    def run(self):
        raise NotImplementedError("Subclass must implement")

    def register_object(self, corba_object):
        raise NotImplementedError("Subclass must implement")

    def get_stringified_obj(self, object_ref):
        raise NotImplementedError("Subclass must implement")

    def deactivate_object(self, object_ref):
        raise NotImplementedError("Subclass must implement")

class _FnorbServer(_AbstractServer):
    """Provides a Fnorb specific interface to implement a BioCorba server.

    Provides functionality for initiliazing a server connection
    and creating object references.

    Fnorb is available from http://www.fnorb.org
    """    
    def __init__(self, argv):
        """Initialize a Fnorb server.
        """
        # import Fnorb
        from Fnorb.orb import CORBA
        from Fnorb.orb import BOA
        
        _AbstractServer.__init__(self)

        # get the ORB initialized
        self.orb = CORBA.ORB_init(argv, CORBA.ORB_ID)

        # initialize the BOA
        self.boa = BOA.BOA_init(argv, BOA.BOA_ID)

    def run(self):
        """Start the orb server waiting for events.
        """
        self.boa._fnorb_mainloop()

    def register_object(self, object_to_register):
        """Register a generic server object with the orb.
        """
        obj_ref = object_to_register._this()

        return obj_ref

    def get_stringified_obj(self, obj_ref):
        """Convert the passed object into a stringified IOR reference.
        """
        obj_string = self.orb.object_to_string(obj_ref)

        return obj_string

    def deactivate_object(self, obj_ref):
        """Get rid of an object held by the Fnorb BOA.
        """
        self.boa.deactivate_obj(obj_ref)

class _OmniORBServer(_AbstractServer):
    """An OmniORB specific interface to start up a Biopython server.

    OmniORBpy is available from:
        http://www.uk.research.att.com/omniORB/omniORBpy/
    """    
    def __init__(self, argv):
        """Initialize an omniORB server.
        """
        # omniORB
        from omniORB import CORBA, PortableServer
        _AbstractServer.__init__(self)

        # initialize the orb and poa
        self.orb = CORBA.ORB_init(argv, CORBA.ORB_ID)
        self.poa = self.orb.resolve_initial_references("RootPOA")

        # Activate the POA
        poaManager = self.poa._get_the_POAManager()
        poaManager.activate()

    def run(self):
        """Start the omniORB blocking loop.
        """
        self.orb.run()

    def register_object(self, object_to_register):
        """Register a generic server object and return the object ref.
        """
        obj_ref = object_to_register._this()

        return obj_ref

    def get_stringified_obj(self, obj_ref):
        """Convert the passed object into a stringified IOR reference.
        """
        obj_string = self.orb.object_to_string(obj_ref)

        return obj_string

    def deactivate_object(self, obj_ref):
        """Get rid of an object held by the POA.
        """
        self.poa.deactivate_object(self.orb.object_to_string(obj_ref))

class _ORBitServer(_AbstractServer):
    """An ORBit specific interface for a Biocorba server.

    This uses ORBit (http://orbit-resource.sourceforge.net/) and the
    ORBit-python bindings (http://sourceforge.net/projects/orbit-python/).
    """
    def __init__(self, argv):
        import CORBA
        _AbstractServer.__init__(self)

        print "Getting the server ready"
        self.orb = CORBA.ORB_init(argv, CORBA.ORB_ID)
        self.poa = self.orb.resolve_initial_references("RootPOA")

        print "got the orb"

    def run(self):
        """Start the ORBit blocking loop.
        """
        # Activate the POA
        poaManager = self.poa._get_the_POAManager()
        poaManager.activate()
        
        print "activated the poa"
        self.orb.run()

    def register_object(self, object_to_register):
        """Register a generic server object and return the object ref.
        """
        print "registering %s" % object_to_register
        obj_ref = object_to_register._this()
        print "registered"
        return obj_ref

    def get_stringified_obj(self, obj_ref):
        """Convert the passed object into a stringified IOR reference.
        """
        obj_string = self.orb.object_to_string(obj_ref)

        return obj_string

    def deactivate_object(self, obj_ref):
        """Get rid of an object held by the POA.
        """
        self.poa.deactivate_object(self.orb.object_to_string(obj_ref))
        
class _IluServer(_AbstractServer):
    """An ILU specific interface to start up a Biocorba server.

    ILU is available from:
    ftp://ftp.parc.xerox.com/pub/ilu/ilu.html

    WARNING: This doesn't actually work yet!
    """    
    def __init__(self, argv):
        """Initialize an ILU server.
        """
        # import ILU libraries
        import ilu
        
        _AbstractServer.__init__(self)
        # create the server
        self.server = ilu.CreateServer('BaseServer')

    def run(self):
        """Start the ILU servers main loop and wait for incoming calls.
        """
        # import ILU libraries
        import ilu
        
        handle = ilu.CreateLoopHandle()
        ilu.RunMainLoop(handle)

    def register_object(self, object_to_register):
        """Register a generic object with the server and return the object ref.
        """
        object_to_register.set_ilu('BaseServer', self.server)

        return object_to_register

    def get_stringified_obj(self, obj_ref):
        """Convert the passed object into a stringified IOR reference.
        """
        obj_string = self.server.IOROfObject(obj_ref)

        return obj_string

    def deactivate_object(self, obj_ref):
        """Get rid of an object.
        """
        raise NotImplementedError("Not sure how to do this yet.")
