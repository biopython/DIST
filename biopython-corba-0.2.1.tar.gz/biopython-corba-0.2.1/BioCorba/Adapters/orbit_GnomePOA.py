"""Wrappers around ORBit dynamic loading so it behaves like skeletons.
"""
# import the General Adapter code
from BioCorba.Adapters.Generic import GenericORBitAdapter

# find and import the biocorba.idl file
import os

current_dir = os.path.dirname(__file__)
import CORBA
CORBA._load_idl(os.path.join(current_dir, os.pardir, 'biocorba.idl'))
from BioCorba.Adapters.Generic import GenericORBitAdapter

# the actual skeleton code
import GNOME__POA

class Unknown(GNOME__POA.Unknown, GenericORBitAdapter):
    pass
