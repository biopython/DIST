"""Wrappers around ORBit dynamic loading so it behaves like skeletons.
"""
# find and import the biocorba.idl file
import os
import sys

current_dir = os.path.dirname(__file__)
import CORBA
CORBA._load_idl(os.path.join(current_dir, os.pardir, 'biocorba.idl'))

# the actual skeleton code
import GNOME

# hack borrowed from omniORB to make it seem like the code is here
sys.modules["BioCorba.GNOME"] = GNOME

