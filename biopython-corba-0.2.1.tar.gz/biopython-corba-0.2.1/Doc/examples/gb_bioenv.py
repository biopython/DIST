#!/usr/bin/env python
"""Demonstrate how to use a BioEnv object through the raw CORBA interfaces.
"""
from BioCorba.Client.Seqcore.CorbaBioEnv import CorbaBioEnv
from BioCorba.Client.BiocorbaConnect import PerlCorbaClient

bioenv_connector = PerlCorbaClient(CorbaBioEnv)
bioenv_server = bioenv_connector.from_file_ior("/tmp/my_server.ior")

import os

GB_FILE = os.path.join(os.getcwd(), "a_drought.gb")
pseq_iterator = bioenv_server.get_PrimarySeqIterator_from_file('GenBank',
                                                               GB_FILE)

import string

SEARCH_STRING = "CAGAATG"

print "Searching for %s..." % SEARCH_STRING

while pseq_iterator.has_more():
    
    pseq = pseq_iterator.next()
    
    location = string.find(string.upper(pseq.seq()), SEARCH_STRING)
    if location != -1:
        print 'Id:', pseq.display_id()
    
