#!/usr/bin/env python
"""Demonstration of how to iterate over a file using straight Biopython.

This uses no CORBA, and is just meant for comparison with the fasta_bioenv.py
example.
"""
from Bio import Fasta
import os

FASTA_FILE = os.path.join(os.getcwd(), "a_drought.fasta")
fasta_handle = open(FASTA_FILE, 'r')

seq_parser = Fasta.SequenceParser()
fasta_iterator = Fasta.Iterator(fasta_handle, seq_parser)

import string

SEARCH_STRING = "CAGAATG"

print "Searching for %s..." % SEARCH_STRING

while 1:
    seq_record = fasta_iterator.next()

    if seq_record is None:
        break
    
    my_seq = seq_record.seq
    location = string.find(string.upper(my_seq.data), SEARCH_STRING)
    if location != -1:
        print 'Id:', seq_record.description
    
