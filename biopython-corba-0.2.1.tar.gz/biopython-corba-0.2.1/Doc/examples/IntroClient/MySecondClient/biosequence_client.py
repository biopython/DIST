#!/usr/bin/env python
"""Client to retrieve Biological sequences from the EMBL database.

This is the second demonstration client, and shows how to get sequences
from the EMBL database and demonstrates catching exceptions from CORBA.

Usage:
python biosequence_client.py <Identifier>

where <Identifier> is the name of an accession number to retrieve the sequence
for.
"""
# standard modules
import urllib
import sys

# omniORB
from omniORB import CORBA

# generated stubs
import servers

# check to make sure we've got good arguments
if len(sys.argv) != 2:
    print "Usage:"
    print "python biosequence_client.py <Identifier>"
    print "<Identifier> is an accession number to retrieve the sequence for."
    sys.exit()

# First grab the sting IOR
BIOSEQUENCE_URL = "http://industry.ebi.ac.uk/~alan/IOR/" + \
                  "servers.BioSequenceServer-Server.ior"

ior_handle = urllib.urlopen(BIOSEQUENCE_URL)
biosequence_ior = ior_handle.read()
ior_handle.close()

# Now start up the ORB and get the server
orb = CORBA.ORB_init([], CORBA.ORB_ID)
biosequence_server = orb.string_to_object(biosequence_ior)

# Try to query the accession, and catch errors if they occur
try:
    seq = biosequence_server.get_biosequence(sys.argv[1])
    print "Query:", sys.argv[1]
    print "Sequence:", seq
except servers.DoesNotExist:
    print "The identifier %s does not exist in the database." % sys.argv[1]

