#!/usr/bin/env python
"""Biopython-corba based server to connect with the EMBL biocorba database.

This is just a quick demonstration/test of the EMBL biocorba server.
"""

# biopython interface to biocorba
from BioCorba.Client.BiocorbaConnect import GenericCorbaClient
from BioCorba.Client.Seqcore.CorbaBioEnv import CorbaBioEnv

# --- constants
# just a temporary IOR for now
EMBL_IOR = "http://industry.ebi.ac.uk/~alan/IOR/" + \
           "org.Biocorba.Seqcore.BioEnvPOAImpl-Server.ior"

# some accession numbers we want to check out
acc_nums = ['AF191658', 'AF191659', 'AF191660', 'AF191661', 'AF191663',
            'AF191664', 'AF191665', 'AF191665']

# get a bioenv object from the IOR
bioenv_retriever = GenericCorbaClient(CorbaBioEnv)
bioenv_server = bioenv_retriever.from_url_ior(EMBL_IOR)

# use the BioEnv interface to get the EMBL database
embl_db = bioenv_server.SeqDB_by_name("EMBL", "")

# let's print out a little report
print 'Database name:', embl_db.database_name()
print 'Database version:', embl_db.database_version()

for acc_num in acc_nums:
    # get the Seq object
    cur_seq = embl_db.get_Seq(acc_num)

    print '****'
    print 'Display ID:', cur_seq.display_id()
    print 'Primary ID:', cur_seq.primary_id()
    print 'Accession Number:', cur_seq.accession_number()
    print 'Type:', cur_seq.type()
    print 'Length:', cur_seq.length()
    print 'Version:', cur_seq.version()

    # lets look at the features
    seq_feature_it = cur_seq.all_features_iterator()

    while seq_feature_it.has_more():
        cur_feature = seq_feature_it.next()
        print '---feature'
        print 'type:', cur_feature.type()
        # oops, crashed the server with the next call
        print 'source:', cur_feature.source()
        print 'start:', cur_feature.start()
        print 'end:', cur_feature.end()
        print 'stand:', cur_feature.strand()
        quals = cur_feature.qualifiers()
        for qual in quals:
            print 'qualifier name:', qual.name
            print 'qualifier values:', qual.values
