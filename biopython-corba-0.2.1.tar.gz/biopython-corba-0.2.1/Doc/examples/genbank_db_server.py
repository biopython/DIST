#!/usr/bin/env python
"""Demonstrate how to make a SeqDB server available for a GenBank file.

This uses the Dictionary and indexing functions of the GenBank module
to create a GenBank dictionary that returns SeqRecords, and then makes
this module available through as a Biocorba SeqDB.
"""
# create the biopython GenBank dictionary, which will do all of the work
from Bio import GenBank

import os
gb_file = os.path.join(os.getcwd(), "a_drought.gb")
index_file = os.path.join(os.getcwd(), "a_drought.idx")

# now index the file
GenBank.index_file(gb_file, index_file)

# now get the parser and set up the dictionary
seqfeat_parser = GenBank.FeatureParser()
gb_dict = GenBank.Dictionary(index_file, seqfeat_parser)

# now create the BioCorba SeqDB
from BioCorba.Server.Seqcore.Database import CorbaSeqDB

db_server = CorbaSeqDB(gb_dict)
db_server.string_ior_to_file("/tmp/my_server.ior")
  
print "Server is up and running..."
db_server.run()
