# This is a Python module
"""Collections of various bits of useful biological data.
"""
