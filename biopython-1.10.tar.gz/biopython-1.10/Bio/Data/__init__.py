# This is a Python module

__all__ = [
    'CodonTable',
    'IUPACData'
    ]
