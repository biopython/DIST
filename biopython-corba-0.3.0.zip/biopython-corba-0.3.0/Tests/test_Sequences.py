#!/usr/bin/env python
"""Tests for Sequence classes.

This module provides basic in-place tests for the various Sequence
classes. These are meant to be simple and straightforward tests of the
functionality, and not integrated tests of how everything functions 
together.
"""
# standard library
import sys
import os

# PyUnit
import unittest

# biopython
from Bio.Seq import Seq
from Bio.SeqRecord import SeqRecord
from Bio.Alphabet import IUPAC

# biocorba stuff we are testing
import BioCorba.Server.Seqcore.CorbaSequence as SequenceServer
from BioCorba.Client.BiocorbaConnect import PythonCorbaClient
import BioCorba.Client.Seqcore.CorbaSequence as SequenceClient
from BioCorba.Client.Bsane import CorbaExceptions

def run_tests(argv):
    test_suite = testing_suite()
    runner = unittest.TextTestRunner(sys.stdout, verbosity = 2)
    runner.run(test_suite)

def testing_suite():
    """Generate the suite of tests.
    """
    test_suite = unittest.TestSuite()

    test_loader = unittest.TestLoader()
    test_loader.testMethodPrefix = 't_'
    tests = [AnonymousSequenceTest, BioSequenceTest]
    
    for test in tests:
        cur_suite = test_loader.loadTestsFromTestCase(test)
        test_suite.addTest(cur_suite)

    return test_suite

class AnonymousSequenceTest(unittest.TestCase):
    """Tests for the AnonymousSequence server and client implementations.
    """
    def setUp(self):
        """Start an AnonymousSequence server and client to use in testing.

        We cache the server so we don't have to create it over and over
        again.
        """
        # get the server
        #if self.__class__.server is None:
        test_seq = Seq("GATCGATC", IUPAC.unambiguous_dna)
        server = SequenceServer.AnonymousSequence(test_seq)
    
        server_obj = server.get_object()

        # now set up a client connected to the server
        client_generator = \
                   PythonCorbaClient(SequenceClient.AnonymousSequence)

        self.client = client_generator.from_object(server_obj)

    def t_get_length(self):
        """Retrieve the length of the sequence.
        """
        length = self.client.get_length()
        assert length == 8, "Got unexpected length %s" % length

    def t_get_type(self):
        """Retrieve the type of the sequence.
        """
        type = self.client.get_type()
        assert type == "DNA", "Got unexpected type: %s" % type

    def t_is_circular(self):
        """Determine if a sequence is circular.
        """
        is_circle = self.client.is_circular()
        assert is_circle == 0, \
               "Got unexpected value for circular: %s" % is_circle

    def t_seq(self):
        """Retrieve the string sequence.
        """
        seq = self.client.seq()
        assert seq == "GATCGATC", "Got unexpected sequence %s" % seq

    def t_sub_seq(self):
        """Retrieve a subsequence string.
        """
        sub_seq = self.client.sub_seq(1, 3)
        assert sub_seq == "GAT", "Expected GAT subseq, got %s" % sub_seq

        sub_seq = self.client.sub_seq(1, 8)
        assert sub_seq == "GATCGATC", "Expected GATCGATC, got %s" % sub_seq

        try:
            sub_seq = self.client.sub_seq(0, 3)
            raise AssertionError("Didn't get expected OutOfBounds Error.")
        except CorbaExceptions.OutOfBounds:
            pass

        try:
            sub_seq = self.client.sub_seq(1, 200000)
            raise AssertionError("Didn't get expected OutOfBounds Error.")
        except CorbaExceptions.OutOfBounds:
            pass
       
class BioSequenceTest(unittest.TestCase):
    """Tests for the BioSequence object, which has identifiers and features.
    
    This does not test any of the duplicated functionality inherited from
    AnonymousSequence, but just the new stuff.
    """
    def setUp(self):
        """Create a BioSequence server and client to perform the tests with.
        """
        test_seq = Seq("GATCGATC", IUPAC.unambiguous_dna)
        test_seqrecord = SeqRecord(test_seq, "FAKEID", "Test Sequence",
                                   "This is just a little test sequence.")
        server = SequenceServer.BioSequence(test_seqrecord)
        server_obj = server.get_object()

        # now set up a client connected to the server
        client_generator = \
                   PythonCorbaClient(SequenceClient.BioSequence)
        self.client = client_generator.from_object(server_obj)

    def t_retrieve_identifiers(self):
        """Test identifiable derived functionality for retrieving ids.
        """
        id = self.client.get_id()
        assert id == "FAKEID", "Got unexpected ID %s" % id

        name = self.client.get_name()
        assert name == "Test Sequence", "Got unexpected name %s" % name

        descr = self.client.get_description()
        assert descr == "This is just a little test sequence.", \
          "Got unexpected description: %s" % descr

        basis = self.client.get_basis()
        assert basis == "not known", "Got unexpected basis: %s" % basis

    def t_get_anonymous_sequence(self):
        """Test retrieving an AnonymousSequence and removing the BioSequence.
        """
        # get some info from the current sequence to test with later
        expect_length = self.client.get_length()
        expect_type = self.client.get_type()
        expect_sub_seq = self.client.sub_seq(1, 3)
        
        # get the anonymous sequence
        anon_seq = self.client.get_anonymous_sequence()
        # get rid of our current BioSequence
        self.client.remove()

        # make sure the anonymous sequence works as expected
        new_length = anon_seq.get_length()
        assert new_length == expect_length, \
          "Unexpectd length %s, expected %s" % (new_length, expected_length)
        new_type = anon_seq.get_type()
        assert new_type == expect_type, \
          "Unexpected type %s, expected %s" % (new_type, expect_type)
        new_sub_seq = anon_seq.sub_seq(1, 3)
        assert new_sub_seq == expect_sub_seq, \
          "Unexpected sub_seq %s, expected %s" % (new_sub_seq, expect_sub_seq)

if __name__ == "__main__":
    sys.exit(run_tests(sys.argv))





