#!/usr/bin/env python
"""Provide tests for Features and Annotations of Sequences.
"""
# standard library
import sys
import os

# PyUnit
import unittest

# biopython
from Bio.Seq import Seq
from Bio.SeqRecord import SeqRecord
from Bio.Alphabet import IUPAC
from Bio.SeqFeature import SeqFeature, FeatureLocation, WithinPosition

# biocorba stuff we are testing
import BioCorba.Client.Seqcore.CorbaCollection as CollectionClient
import BioCorba.Server.Seqcore.CorbaCollection as CollectionServer
from BioCorba.Client.BiocorbaConnect import PythonCorbaClient
from BioCorba.Client.Bsane import CorbaExceptions
from BioCorba.Client.Bsane.Base import StopIteration

def run_tests(argv):
    test_suite = testing_suite()
    runner = unittest.TextTestRunner(sys.stdout, verbosity = 2)
    runner.run(test_suite)

def testing_suite():
    """Generate the suite of tests.
    """
    test_suite = unittest.TestSuite()

    test_loader = unittest.TestLoader()
    test_loader.testMethodPrefix = 't_'
    tests = [BioSequenceCollectionTest]
    
    for test in tests:
        cur_suite = test_loader.loadTestsFromTestCase(test)
        test_suite.addTest(cur_suite)

    return test_suite

class BioSequenceCollectionTest(unittest.TestCase):
    """Tests for a retrieving a collection of BioSequence objects.
    """
    def setUp(self):
        """Create a small server database and connected client.
        """
        seq_dictionary = {}
        test_seq = Seq("GATCGATC", IUPAC.unambiguous_dna)
        test_seqrecord = SeqRecord(test_seq, "FAKEID", "Test Sequence",
                                   "This is just a little test sequence.")
        seq_dictionary["Test1"] = test_seqrecord
        
        test_seq_2 = Seq("AAAAAAAAA", IUPAC.unambiguous_dna)
        test_seqrecord_2 = SeqRecord(test_seq, "FAKEID2", "Test Sequence 2",
                                     "This is just a big test sequence.")
        seq_dictionary["Test2"] = test_seqrecord_2
        
        server = CollectionServer.BioSequenceCollection(seq_dictionary, 
          "Test Database", 1.0, "This is a little test database.")
        server_obj = server.get_object()

        # now set up a client connected to the server
        client_generator = \
                   PythonCorbaClient(CollectionClient.BioSequenceCollection)
        self.client = client_generator.from_object(server_obj)

    def t_id_resolve(self):
        """Get BioSequence objects based on their ids.
        """
        first_seq = self.client.resolve("Test1")
        seq_id = first_seq.get_id()
        seq_name = first_seq.get_name()
        assert seq_id == "FAKEID" and seq_name == "Test Sequence", \
          "Got unexpected Id and name: %s, %s" % (seq_id, seq_name)

        second_seq = self.client.resolve("Test2")
        seq_id = second_seq.get_id()
        seq_name = second_seq.get_name()
        assert seq_id == "FAKEID2" and seq_name == "Test Sequence 2", \
          "Got unexpected Id and name: %s, %s" % (seq_id, seq_name)

        try:
            fake_seq = self.client.resolve("NotARealId")
            raise AssertionError("Did not raise error on a fake id.")
        except CorbaExceptions.IdentifierDoesNotExist:
            pass

    def t_database_id(self):
        """Test retrieving id and description information for the database.
        """
        db_id = self.client.get_id()
        assert db_id == "Test Database-1.0", "Got unexpected id: %s" % db_id
        db_name = self.client.get_name()
        assert db_name == "Test Database", "Got unexpected name: %s" % db_name
        db_description = self.client.get_description()
        assert db_description == "This is a little test database.", \
          "Got unexpected description: %s" % db_description
        
    def t_database_annotations(self):
        """Retrieve annotations about the database.
        """
        ann_collection = self.client.get_annotations()

        version_info = ann_collection.get_annotations_by_name("version")
        assert len(version_info) == 1, \
          "Got unexpected number of versions: %s" % version_info
        version_name = version_info[0].get_name()
        version_value = version_info[0].get_value()
        assert version_name == "version" and version_value == 1.0, \
          "Got unexpected version: %s, %s" % (version_name, version_value)
          
        all_ids = ann_collection.get_annotations_by_name("ids")
        assert len(all_ids) == 2, \
          "Got unexpected id information: %s" % all_ids
        id_name = all_ids[0].get_name()
        id_values = []
        id_values.append(all_ids[0].get_value())
        id_values.append(all_ids[1].get_value())
        assert id_name == "ids" and id_values == ["Test1", "Test2"], \
          "Got unexpected id info: %s, %s" % (id_name, id_values)

        try:
            no_annotation = ann_collection.get_annotations_by_name("name")
            raise AssertionError("Did not get error with bad annotation.")
        except CorbaExceptions.IdentifierNotResolvable:
            pass

    def t_get_seq_list(self):
        """Retrieve BioSequence objects as a list.
        """
        seq_list, iterator = self.client.get_seqs(1)
        assert len(seq_list) == 1, "Got unexpected sequences: %s" % seq_list
        seq_id = seq_list[0].get_id()
        seq_name = seq_list[0].get_name()
        assert seq_id == "FAKEID" and seq_name == "Test Sequence", \
          "Got unexpected Id and name: %s, %s" % (seq_id, seq_name)

        seq_list, iterator = self.client.get_seqs(2)
        assert len(seq_list) == 2, "Got unexpected sequences: %s" % seq_list
        try:
            iterator.next()
            raise AssertionError("Did not get error with empty iterator.")
        except StopIteration:
            pass

        seq_id = seq_list[1].get_id()
        seq_name = seq_list[1].get_name()
        assert seq_id == "FAKEID2" and seq_name == "Test Sequence 2", \
          "Got unexpected Id and name: %s, %s" % (seq_id, seq_name)

    def t_get_seq_iterator(self):
        """Retrieve BioSequence objects through an iterator.
        """
        seq_list, iterator = self.client.get_seqs(0)
        assert len(seq_list) == 0, "Got non-empty sequences: %s" % seq_list

        first_seq = iterator.next()
        second_seq = iterator.next()
        seq_id = second_seq.get_id()
        seq_name = second_seq.get_name()
        assert seq_id == "FAKEID2" and seq_name == "Test Sequence 2", \
          "Got unexpected Id and name: %s, %s" % (seq_id, seq_name)

        try:
            iterator.next()
            raise AssertionError("Did not get error with empty iterator.")
        except StopIteration:
            pass

if __name__ == "__main__":
    sys.exit(run_tests(sys.argv))
