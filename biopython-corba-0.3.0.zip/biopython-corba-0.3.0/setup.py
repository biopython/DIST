#!/usr/bin/env python
"""Setup script for python implementation of BioCorba.
"""
# standard modules
import os
import sys
import shutil

# distutils stuff
try:
    from distutils.core import setup
    from distutils.command.build import build
    from distutils.command.install import install
except ImportError:
    print "biopython-corba installation requires distutils, avaiable with "
    print "python 2.0 or better, or from:"
    print "http://python.org/sigs/distutils-sig/download.html"
    sys.exit(0)

# local stuff
from BioCorba.biocorbaconfig import *
from build_helper import *

# --- constants
IDL_DIRECTORY = os.path.join(os.getcwd(), 'idl')
STUBS_DIRECTORY = os.path.join(os.getcwd(), 'BioCorba')
BIOCORBA_IDL_FILE = "seqcore.idl"
BSANE_IDL_FILE = "bsane.idl"
COLLECTION_IDL_FILE = "collection.idl"
COMPARISON_IDL_FILE = "comparison.idl"
TYPES_IDL_FILE = "types.idl"
# ENSEMBL_IDL_FILE = "ensembl.idl"

IDL_FILES = [BIOCORBA_IDL_FILE, BSANE_IDL_FILE, TYPES_IDL_FILE, 
             COLLECTION_IDL_FILE]

# Determine which packages we need to install based on the biocorbaconfig.py
# configuration file.

# basic stuff you need for both omniORB and Fnorb
basic = ['BioCorba',
         'BioCorba/Adapters',
         'BioCorba/Bio',
         'BioCorba/Bio/Fasta',
         'BioCorba/Bio/GenBank',
         'BioCorba/Client',
         'BioCorba/Client/Bsane',
         'BioCorba/Client/Seqcore',
         #'BioCorba/Client/Ensembl',
         'BioCorba/Server',
         'BioCorba/Server/Bsane',
         'BioCorba/Server/Seqcore',
         'BioCorba/Share']

# idl generated stubs and skeletons which need to be installed
corba_pkgs = []
# --- BioCorba base stuff
if 'biocorba' in supported_interfaces:
    # ORBit doesn't have inner directories due to import hacks
    if orb_implementation != 'ORBit':
        corba_pkgs += ['BioCorba/bsane',
                       'BioCorba/bsane/seqcore',
                       'BioCorba/bsane__POA',
                       'BioCorba/bsane__POA/seqcore',
                       'BioCorba/Types',
                       'BioCorba/Types__POA',
                       'BioCorba/bsane__POA/collection',
                       'BioCorba/bsane/collection',
                       'BioCorba/bsane__POA/comparison',
                       'BioCorba/bsane/comparison']

    # extra corba stuff that we need for Fnorb to make it act like it
    # obeys the standard python CORBA interface
    if orb_implementation == 'Fnorb':
        corba_pkgs = corba_pkgs + \
                     ['BioCorba/bsane_skel',
                      'BioCorba/bsane_skel/seqcore_skel',
                      'BioCorba/bsane_skel/collection_skel',
                      'BioCorba/bsane_skel/comparison_skel',
                      'BioCorba/Types_skel']
        # we don't need these *__POAs for anything and this prevents having
        # to patch it for Fnorb
        corba_pkgs.remove('BioCorba/Types__POA')
        corba_pkgs.remove('BioCorba/bsane__POA/comparison')

# -- ensembl
if 'ensembl' in supported_interfaces:
    raise NotImplementedError("Ensembl doesn't work yet for the new IDL.")
    #corba_pkgs += ['BioCorba/org/ensembl',
    #               'BioCorba/org__POA/ensembl']

    #if orb_implementation == 'Fnorb':
    #    corba_pkgs = corba_pkgs + \
    #                 ['BioCorba/org_skel/ensembl_skel']

# build up the list of packages to install
install_pkgs = []
install_pkgs = basic + corba_pkgs

class my_build(build):
    """Override the standard build to compile idl files.
    """
    def run(self):
        # run the right idl compiler depending on the orb being used
        if 'biocorba' in supported_interfaces:
            if orb_implementation == 'omniORB':
                generate_omniorb_stubs(BIOCORBA_IDL_FILE)
                generate_omniorb_stubs(BSANE_IDL_FILE, remove_old = 0)
                generate_omniorb_stubs(TYPES_IDL_FILE, remove_old = 0)
                generate_omniorb_stubs(COLLECTION_IDL_FILE, remove_old = 0)
                generate_omniorb_stubs(COMPARISON_IDL_FILE, remove_old = 0)
            elif orb_implementation == 'Fnorb':
                generate_fnorb_stubs(BIOCORBA_IDL_FILE)
                generate_fnorb_stubs(BSANE_IDL_FILE, remove_old = 0)
                generate_fnorb_stubs(TYPES_IDL_FILE, remove_old = 0)
                generate_fnorb_stubs(COLLECTION_IDL_FILE, remove_old = 0)
                generate_fnorb_stubs(COMPARISON_IDL_FILE, remove_old = 0)
            elif orb_implementation == 'ORBit':
                generate_orbit_stubs(BIOCORBA_IDL_FILE)
        if 'ensembl' in supported_interfaces:
            raise NotImplementedError("Ensembl doesn't work for the new IDL.")
            #if orb_implementation == 'omniORB':
            #    generate_omniorb_stubs(ENSEMBL_IDL_FILE, remove_old = 0)
            #elif orb_implementation == 'Fnorb':
            #    generate_fnorb_stubs(ENSEMBL_IDL_FILE, remove_old = 0)
            #elif orb_implementation == 'ORBit':
            #    generate_orbit_stubs(ENSEMBL_IDL_FILE, remove_old = 0)
                
        build.run(self)

class my_install(install):
    """Override the default install to copy over the IDL files.

    This is probably an awful abuse of distutils, but I can't figure out
    a better way right now to make the IDL files availabe so that
    ORBit-python can use them.
    """
    def run(self):
        install.run(self)
        idl_dir = os.path.join(self.install_purelib, 'BioCorba')

        for idl_file in IDL_FILES:
            shutil.copy(os.path.join(IDL_DIRECTORY, idl_file), idl_dir)

setup (name = "biopython-corba",
       version = "0.3.0",
       description = "Python implementation of the BioCorba interfaces",
       author = "The Biopython Consortium",
       author_email = "biopython@biopython.org",
       url = "http://www.biopython.org",

       cmdclass = {'build': my_build, 'install': my_install},
       packages = install_pkgs)
