"""Module file for BioCorba.

This __init__.py file provides 'magical' handling for ORBit-python, so
that it's dynamic loading mechanism can appear like it actually has
stubs.
"""
from biocorbaconfig import orb_implementation

if orb_implementation == "ORBit":
    import os
    this_dir = os.path.dirname(__file__)

    # only load if we are in the install directory with the IDL file
    # this basically just prevents us from loading all of this junk
    # (and getting an error) when installing everything.
    seqcore_file = os.path.join(this_dir, "seqcore.idl")
    collection_file = os.path.join(this_dir, "collection.idl")
    if os.path.exists(seqcore_file) and os.path.exists(collection_file):
        import CORBA
        # CORBA._load_idl(seqcore_file)
        CORBA._load_idl(collection_file)

        import bsane
        import bsane__POA
        import sys
        sys.modules["BioCorba.bsane"] = bsane

        import sys
        sys.modules["BioCorba.bsane.seqcore"] = bsane.seqcore

        import sys
        sys.modules["BioCorba.bsane__POA"] = bsane__POA

        import sys
        sys.modules["BioCorba.bsane__POA.seqcore"] = bsane__POA.seqcore

        import sys
        sys.modules["BioCorba.bsane__POA.collection"] = bsane__POA.collection

        import sys
        sys.modules["BioCorba.bsane.collection"] = bsane.collection
        
        # don't pollute the namespace
        del sys
        del CORBA
        
    del os
    del this_dir
    
