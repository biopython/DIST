"""Adapters around actual Fnorb stubs so they behave like the python
 mapping.

Each class does two things:
1. Inherets from the actual skel, so that the inheritence in the main code
can be uniform.

2. Defines a _this() function which creates a unique object ref for a
class object, and registers it with the boa.
"""
# import the General Adapter code
from BioCorba.Adapters.Generic import GenericFnorbAdapter

# import the actual skeleton code
import BioCorba.bsane_skel as skel_base
       
class Removable(skel_base.Removable_skel, GenericFnorbAdapter):
    unique_name = 'Removable'

class AnnotationCollection(skel_base.AnnotationCollection_skel,
                           GenericFnorbAdapter):
    unique_name = 'AnnotationCollection'

class Annotatable(skel_base.Annotatable_skel, GenericFnorbAdapter):
    unique_name = 'Annotatable'

class Identifiable(skel_base.Identifiable_skel, GenericFnorbAdapter):
    unique_name = 'Identifiable'

class Annotation(skel_base.Annotation_skel, GenericFnorbAdapter):
    unique_name = 'Annotation'

class Iterator(skel_base.Iterator_skel, GenericFnorbAdapter):
    unique_name = 'Iterator'
