"""Module providing basic functionality for Bsane derived classes.

This implements classes which are widely used throughout the interfaces
and that don't really fit anywhere else.
"""
import sys

import BioCorba.bsane__POA as bsane__POA
import BioCorba.bsane as bsane

from BioCorba.Server import ServerFactory
from BioCorba.biocorbaconfig import orb_implementation

# define a StopIteration exception for older python versions
if sys.version_info < (2, 2):
    class StopIteration(Exception):
        pass

class Base:
    """Base class providing functions to help a server implementor.

    This class should be derived from by those classes which don't
    user Removable. It provides functionality to deal with server 
    issues.
    """
    def __init__(self):
        """Initialize an ORB independent server object.

        This class helps try to avoid ORB-specific impementation objects
        by abstracting out the creation of a 'server' object to a
        separate factory which is ORB-specific and is defined by the user
        in a configuration file.
        """
        self._server = ServerFactory.create_server()
        self._corba_object = self._server.register_object(self)

        # a flag indicating whether or not the CORBA object can be
        # removed (ie. via a remove() call). By default, everything 
        # gets removed, except things that are run()ing
        self.do_not_remove = 0

    def run(self):
        """Run the server and wait for client calls.

        This function causes the server to tie up the thread it is called
        in as the server will sit and block waiting for client calls.
        """
        # don't remove running servers -- their memory will be freed
        # up when they are stopped
        self.do_not_remove = 1
        self._server.run()
        
    def get_object(self):
        """Return the CORBA object corresponding to this class.
        """
        return self._corba_object
    
    def get_string_ior(self):
        """Return the string IOR of the object.
        """
        return self._server.get_stringified_obj(self._corba_object)

    def string_ior_to_file(self, file):
        """Convenience function to write the IOR to a file.
        """
        ior_file = open(file, 'w')
        ior_file.write(self.get_string_ior())
        ior_file.close()

class Removable(bsane__POA.Removable, Base):
    """Base class that provides memory management and ORB abstraction.

    This is the class most major interfaces derive from and makes
    an object able to identify that it should be destroyed; this helps
    handle memory issues.
    """
    def __init__(self):
        Base.__init__(self)

    def remove(self):
        """Remove the object, and clear all memory associated with it.

        This is called by the client, and once called it will no longer
        be able to call methods on the object.
        """
        if not(self.do_not_remove):
            self._server.deactivate_object(self)
            self._corba_object = None

class Identifiable(Removable):
    """Add the ability to resolve identifiers to an object.

    This class is implemented in a way that relies on having an underlying
    object which provides id, name, description and basis attributes. 
    This probably handicaps the class quite a bit, but makes it work 
    readily with the Biopython SeqRecord object.
    """
    def __init__(self, id_resolver):
        """Intialize with a class containing identifier attributes.
        """
        Removable.__init__(self)
        self._id_resolver = id_resolver

    def remove(self):
        """Get rid of referenes to our resolver when destroying.
        """
        self._id_resolver = None
        Removable.remove(self)

    def get_id(self):
        """Retrieve a unique id for the object.
        """
        try:
            return self._id_resolver.id
        except AttributeError:
            return "<unknown id>"

    def get_name(self):
        """Retrieve a descriptive name for the object.
        """
        try:
            return self._id_resolver.name
        except AttributeError:
            return "<unknown name>"

    def get_description(self):
        """Retrieve a description of the object.
        """
        try:
            return self._id_resolver.description
        except AttributeError:
            return "<unknown description>"

    def get_basis(self):
        """Retrieve the experimental basis for the object.

        This currently assumes the basis is a number for one of the
        possible basis types defined in bsane.idl. This should change to
        be more friendly to native biopython types once there is support
        for it in biopython.
        """
        possible_values = [bsane.Basis.NOT_KNOWN, bsane.Basis.EXPERIMENTAL,
                           bsane.Basis.COMPUTATIONAL, bsane.Basis.BOTH,
                           bsane.Basis.NOT_APPLICABLE]

        try:
            basis = self._id_resolver.basis
            assert basis in possible_values, \
              "Unexpected basis value %s" % basis
            return basis
        except AttributeError:
            return bsane.Basis.NOT_KNOWN

class _DictionaryIterator:
    """Represent a set of dictionary items as an iterator.

    This class is meant to work like the iterator interface in python2.2,
    and in fact uses it if we have that python version. Eventually this
    will go away in favor of using that.
    """
    def __init__(self, dictionary, keys = None, item_converter = None):
        """Iniitalize an iterator over a dictionary.

        item_converter is a function which will be called before each item
        is returned. It could be used to make an item CORBA-ready. The 
        function will be passed the item that comes off the dictionary.
        """
        self._converter = item_converter
        # use standard value iterators in python2.2
        if sys.version_info >= (2, 2):
            self._item_iterator = itervalues(dictionary)
        else:
            self._index = 0
            if keys is None:
                self._keys = dictionary.keys()
            else:
                self._keys = keys
            self._keys.sort()
            self._dictionary = dictionary

    def next(self):
        """Return the next dictionary item in the list.
        """
        # if we have python 2.2 or greater, our iterator is all set.
        if sys.version_info >= (2, 2):
            item = self._item_iterator.next()
        else:
            try:
                cur_key = self._keys[self._index]
            except IndexError:
                raise StopIteration
            self._index += 1
            item = self._dictionary[cur_key]
        if self._converter is not None:
            return self._converter(item)
        else:
            return item

class _ListIterator:
    """Represent a list of items as an iterator.

    This class takes a list as an argument, and turns it into an 
    iterator-like object that can be fed into the generic Iterator class.

    Note: eventually this should completely go away in favor of the
    standard iterator interface being introduced in Python2.2. For right
    now, we'll use python2.2 under the covers, and provide back-support
    for older pythons.
    """
    def __init__(self, item_list):
        # use the standard iterators in python2.2
        if sys.version_info >= (2, 2):
            self._item_iterator = iter(item_list)
        else:
            self._index = 0
            self._item_list = item_list

    def next(self):
        """Provide the next item in the list.
        """
        # if we have python 2.2 or greater, our iterator is all set.
        if sys.version_info >= (2, 2):
            return self._item_iterator.next()
        else:
            try:
                next_item = self._item_list[self._index]
            except IndexError:
                raise StopIteration
            self._index += 1
            return next_item

class Iterator(bsane__POA.Iterator, Removable):
    """Generic Iterator class to retrieve items.

    This class is initiated with an iterator-like object that will return
    an item when next is called and raise a StopIteration error when
    we are out of items to return. This iterator-like object will than
    be served out through CORBA.

    This iterator does not do any work to objectify the items for return
    by CORBA, and in fact assumes that the items it is getting are all
    ready to be returned.
    """
    def __init__(self, iterator):
        Removable.__init__(self)
        self._iterator = iterator

    def remove(self):
        """Remove hook to free our iterator object.
        """
        self._iterator = None
        Removable.remove(self)

    def next(self):
        """Retrieve the next object and a flag indicating if we are at the end.

        This returns a flag (1 if we haven't reached the end, 0 if we have)
        and the next item (which will be None if we are out of items.
        """
        try:
            next_item = self._iterator.next()
        except StopIteration:
            return 0, None
    
        # if the item is None, we are done iterating as well   
        if next_item is None:
            return 0, None

        # if we get here, everything is good, and we return the item
        return 1, next_item

    def next_n(self, how_many):
        """Return the next how_many objects as a list.

        This behaves exactly like next, except allows retrieval of a 
        specified number of objects at once.
        """
        return_items = []
        while 1:
            status, cur_item = self.next()
            
            if cur_item is not None:
                return_items.append(cur_item)
           
            # if we are out of item or have them all, stop looping
            if status == 0 or len(return_items) >= how_many:
                break

        # if we don't have anything to return, return a fail flag and None
        if len(return_items) == 0:
            return 0, None
        # otherwise return what we've got
        else:
            assert len(return_items) <= how_many, \
              "Got more items than we expected."
            return 1, return_items

            

    def reset(self):
        """Reset the iterator to the beginning -- not supported now.
        """
        raise NotImplementedError("We don't do resets.")
        
    
