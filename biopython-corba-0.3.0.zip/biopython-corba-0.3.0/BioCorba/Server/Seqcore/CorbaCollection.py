"""Represent databases holding biological information.

Database type interfaces are represented in biocorba as collections.
These collections allow retrieval of information by ids (as opposed
to just simple retrieval by an iterator or list). Collections are
analagous to Dictionaries (ie. GenBank.Dictionary) in biopython.
"""
# stubs generated from the idl
import BioCorba.bsane__POA.collection as collection__POA
import BioCorba.bsane.seqcore as seqcore
import BioCorba.bsane as bsane

# other biopython-corba stuff
from BioCorba.Server.Bsane.Base import Iterator, _DictionaryIterator
from BioCorba.Server.Bsane.Base import Identifiable
from BioCorba.Server.Bsane.Annotation import Annotatable
from BioCorba.Server.Seqcore.CorbaSequence import BioSequence
from BioCorba.Share.SeqFeature import _safe_give_keywords

class BioSequenceIdentifierResolver(\
        collection__POA.BioSequenceIdentifierResolver):
    """Mix-in class to provide the ability to resolve sequences from ids.
    """
    def resolve(self, seq_id):
        """Return a BioSequence object corresponding to the given id.
        """
        try:
            seq_record_item = self._database[seq_id]
        except KeyError, msg:
            exception = _safe_give_keywords(bsane.IdentifierDoesNotExist,
                         [("id", seq_id)])
            raise exception

        seq_item = BioSequence(seq_record_item)
        return seq_item.get_object()

class BioSequenceCollection(collection__POA.BioSequenceCollection,
                            BioSequenceIdentifierResolver, Identifiable,
                            Annotatable):
    """Full-scale collection object which allows database-like access.

    This is the big-daddy collection object for BioSequences, and is the
    class that should be used when you have a Biopython-style dictionary
    object to make available through CORBA.
    """
    def __init__(self, seq_dict, db_name = 'Generic Database',
                 db_version = 0.0, db_description = "No description"):
        """Initialize a database to return PrimarySeq objects.

        seq_dict is a dictionary-like object that returns SeqRecord
        objects. The object must implement __getitem__ (by name) and
        keys().
        """
        # Initialize Identifier with the database information
        class NameResolver:
            """Small class to make information available for the identifier.
            """
            def __init__(self, name, id, description):
                self.name = name
                self.id = id
                self.description = description

        resolver = NameResolver(str(db_name), "%s-%s" % (db_name, db_version), 
                                str(db_description))
        Identifiable.__init__(self, resolver)

        # make annotation on the database available
        all_keys = seq_dict.keys()
        all_keys.sort()
        self._record = {"version" : db_version,
                        "ids" : all_keys}

        # finally set up for ourselves and IdResolver
        self._database = seq_dict

    def get_seqs(self, how_many):
        """Retrieve a list of sequences from the database.

        This returns how_many sequences from the database, and returns
        an iterator that allows getting at everything else in the database.
        """
        all_keys = self._database.keys()
        all_keys.sort()

        # split the keys into items to return and the rest of the keys
        return_keys = all_keys[:how_many]
        iterator_keys = all_keys[how_many:]

        # get the list of items to return
        seq_list =[]
        for key in return_keys:
            seq_record = self._database[key]
            bioseq = BioSequence(seq_record)
            seq_list.append(bioseq.get_object())

        # set up the iterator
        def converter(item):
            seq = BioSequence(item)
            return seq.get_object()
        
        dict_iterator = _DictionaryIterator(self._database, iterator_keys,
                                            converter)
        iterator = Iterator(dict_iterator)
        
        return seq_list, iterator.get_object()
