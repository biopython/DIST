# Copyright 2000 by Brad Chapman.  All rights reserved.
# This code is part of the Biopython distribution and governed by its
# license.  Please see the LICENSE file that should have been included
# as part of this package.

# stubs generated from the idl
import BioCorba.bsane__POA.seqcore as seqcore__POA
import BioCorba.bsane.seqcore as seqcore
import BioCorba.bsane as bsane

# other local classes
from BioCorba.Server.Bsane.Base import Iterator, _ListIterator
from BioCorba.Server.Bsane.Annotation import Annotation, Annotatable
from BioCorba.Server.Bsane.Annotation import AnnotationCollection
from BioCorba.Share.SeqFeature \
  import _CorbaLocationConverter, _safe_give_keywords

# biopython
from Bio import SeqFeature

class SeqFeature(seqcore__POA.SeqFeature, Annotation, Annotatable):
    """Represent features on a sequence.

    These are semi-analagous to GenBank features, so looking at a GenBank
    feature table might give some clues about how this works.
    """
    def __init__(self, seq_feature):
        """Initialize with a biopython SeqFeature object.
        """
        # XXX I'm not sure if I'm using Annotation properly -- right
        # now I'm just giving it the feature type
        Annotation.__init__(self, "type", seq_feature.type)
        # store the seq_feature as _record to be consistent with how
        # Annotatable works as a mix-in class
        self._record = seq_feature

    def remove(self):
        """Hook to get rid of our SeqFeature before deleting.
        """
        self._record = None
        Annotation.remove(self)

    def get_start(self):
        """Return the non-fuzzy start position of the feature.
        """
        start_pos = self._record.location.start
        return int(start_pos.position)

    def get_end(self):
        """Return the non-fuzzy end position of the feature.
        """
        end_pos = self._record.location.end
        return int(end_pos.position)

    def get_locations(self):
        """Retrieve the full-blown fuzzy locations of the SeqFeature.
        """
        # convert the biopython locations into CORBA location objects
        location_converter = _CorbaLocationConverter()
        corba_locations = \
          location_converter.from_biopython_feature(self._record)

        return [corba_locations]

    def get_owner_sequence(self):
        """We never hold on to the owner sequence.
        """
        exception = _safe_give_keywords(bsane.DoesNotExist, 
          [("reason", "We don't supply the owner sequence. Sorry.")])
        raise exception

class SeqFeatureCollection(seqcore__POA.SeqFeatureCollection, 
                           AnnotationCollection):
    """Supply out a list of SeqFeatures.
    """
    def __init__(self, feature_list):
        """Initialize with a list of biopython SeqFeature objects.
        """
        # initialize an empty AnnotationCollection -- right now biopython
        # doesn't deal with annotations on SeqFeature collections
        AnnotationCollection.__init__(self, {})

        self._features = feature_list

    def get_features_on_region(self, num_features, seq_region):
        """Return the specified number of features within a sequence region.

        This provides a mechanism to readily retrieve features. This will
        return the specified number of features in the region as a list,
        and the rest of the features as an Iterator object that can
        be used to get features one at a time.
        """
        location_converter = _CorbaLocationConverter()
        region_feature = location_converter.to_biopython_feature(seq_region)

        features_in_region = \
          self._locate_features(region_feature.location.start,
                                region_feature.location.end)

        # convert the features into CORBA features for returning
        corba_features = []
        for biopy_feature in features_in_region:
            new_feature = SeqFeature(biopy_feature)
            corba_features.append(new_feature.get_object())

        # split the features into those to return as a list and
        # those to return as an iterator
        feature_list = corba_features[:num_features]
        iterator_list = corba_features[num_features:]
        iterator = Iterator(_ListIterator(iterator_list))

        return feature_list, iterator.get_object()

    def num_features_on_region(self, seq_region):
        """Find the number of features in a given sequence region.
        """
        location_converter = _CorbaLocationConverter()
        region_feature = location_converter.to_biopython_feature(seq_region)
       
        features_in_region = \
          self._locate_features(region_feature.location.start,
                                region_feature.location.end)
        return len(features_in_region)

    def _locate_features(self, start, end):
        """Return all features that fall between the given start and end.
        """
        region_features = []
        for feature in self._features:
            if feature.location.start >= start and \
               feature.location.end <= end:
                region_features.append(feature)

        return region_features

