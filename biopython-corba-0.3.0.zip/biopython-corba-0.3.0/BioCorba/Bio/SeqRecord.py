# Copyright 2000 by Brad Chapman.  All rights reserved.
# This code is part of the Biopython distribution and governed by its
# license.  Please see the LICENSE file that should have been included
# as part of this package.

# biopython
from Bio.SeqFeature import FeatureLocation

# BioCorba.Bio classes we return instances of
from BioCorba.Bio.Seq import Seq
from BioCorba.Bio.SeqFeature import SeqFeature

# other biopython-corba stuff
from BioCorba.Client.Seqcore.CorbaSequence import BioSequence
from BioCorba.Client.Bsane.Base import StopIteration
from BioCorba.Share.SeqFeature import _get_annotations

class SeqRecord:
    """SeqRecord implementation class for use with the corba interface.

    Basically, this is a wrapper around the BioSequence interface.
    """
    def __init__(self, remote_seq):
        """Intialize a SeqRecord class that can return basic sequence info.

        Arguments:
        remote_seq - A BioSequence object obtained from a BioCorba
        server. This will be used to send requests through corba
        to the other interfaces.
        """
        # determine if the seq object has already been wrapped around
        # a local client object
        if isinstance(remote_seq, BioSequence):
            self._corba_seq = remote_seq
        else:
            self._corba_seq = BioSequence(remote_seq)

        self._features = None
        self._annotations = None

    def __getattr__(self, name):
        """Override get attribute to provide attributes through CORBA.
        """
        if name == "seq":
            return Seq(self._corba_seq)
        elif name == "id":
            return self._corba_seq.get_id()
        elif name == "name":
            return self._corba_seq.get_name()
        elif name == "description":
            return self._corba_seq.get_description()
        # We keep an internal cache for features and annotations, and only
        # fetch them once from the server. This assumes that the underlying
        # server isn't changing while the client is alive, which (I think)
        # is a fairly reasonable assumption.
        elif name == "features":
            if self._features is None:
                self._features = self._get_features()
            return self._features
        elif name == "annotations":
            if self._annotations is None:
                self._annotations = _get_annotations(self._corba_seq)
            return self._annotations
        else:
            raise AttributeError("No attribute named %s" % name)

    def _get_features(self):
        """Retrieve SeqFeature objects for all features of this object.

        Returns:
        o A list of BioCorba.Bio.SeqFeature objects.
        """
        # the list of seqfeatures to return
        bio_seqfeatures = []

        # get a list of SeqFeatures through an iterator interface
        feature_collection = self._corba_seq.get_seq_features()
        entire_seq_loc = FeatureLocation(0, self._corba_seq.get_length())
        empty_list, iterator = \
          feature_collection.get_features_on_region(0, entire_seq_loc)
        assert len(empty_list) == 0, "Got unexpected features."

        while 1:
            try:
                cur_feature = iterator.next()
            except StopIteration:
                break
    
            bio_seqfeatures.append(SeqFeature(cur_feature))

        return bio_seqfeatures

