"""Biopython Fasta-like interface to BioCorba objects.
"""
# import the GenBank stuff we'll be using
from BioCorba.Bio import GenBank


# we just use the GenBank functionality to do all the work, but leave
# the interface here for compatibility with old stuff and with Biopython
# Since there is no split between Seq and PrimarySeq objects like there
# was in previous BioCorba implementations, this and GenBank are identical
# except for the amount of information you'll be getting back from objects.
Dictionary = GenBank.Dictionary
Iterator = GenBank.Iterator
SequenceParser = GenBank.FeatureParser
