"""Biopython-like GenBank interface to BioCorba objects.

This is meant to model the regular Bio.GenBank interfaces.
"""
# biopython-corba
from BioCorba.Bio.SeqRecord import SeqRecord
from BioCorba.Client.Seqcore.CorbaCollection import BioSequenceCollection
from BioCorba.Client.Bsane import CorbaExceptions
from BioCorba.Client.Bsane.Base import StopIteration

class Dictionary:
    """Represent a CorbaSeqDB as a GenBank dictionary.
    """
    def __init__(self, remote_collection, parser = None):
        """Initialize the dictionary to return information.

        Arguments:
        o remote_collection - An object reference to a remote
        BioSequenceCollection that will be used to retrieve everything.
        o parser - A parser object which will determine the type of
        information returned from the dictionary (when __getitem__
        is called). This parser must implement the function parse(),
        which when given a BioSequence object, will return an appropriate
        Biopython object. If parser is None, then the unprocessed
        BioSequence object will be returned.
        """
        # determine if the object is already wrapped up inside a local client
        if isinstance(remote_collection, BioSequenceCollection):
            self._collection = remote_collection
        else:
            self._collection = BioSequenceCollection(remote_collection)
        self._parser = parser

        self._keys = None

    def __len__(self):
        return len(self.keys())

    def __getitem__(self, key):
        try:
            seq_obj = self._collection.resolve(key)
            if self._parser:
                return self._parser.parse(seq_obj)
            else:
                return seq_obj          
        except (CorbaExceptions.IdentifierDoesNotExist,
                CorbaExceptions.IdentifierNotResolvable,
                CorbaExceptions.IdentifierNotUnique):
            raise KeyError("The key %s was not found." % key)      

    def __getattr__(self, name):
        raise NotImplementedError("Not on CORBA objects.")

    def keys(self):
        if self._keys is None:
            ann_collection = self._collection.get_annotations()
            ann_info = ann_collection.get_annotations_by_name("ids")
            self._keys = []
            for ann in ann_info:
                assert ann.get_name() == "ids", \
                  "Unexpected annotation name %s" % ann.get_name()
                self._keys.append(ann.get_value())
           
        return self._keys

class Iterator:
    """Access CORBA BioSequence-like objects through an iterator interface.
    """
    def __init__(self, remote_collection, parser = None):
        """Initialize with a CORBA collection and optional parser.

        o remote_collection - A BioSequenceCollection object which can
        be used to retrieve sequences.
        
        o parser - An optional argument which specifies a parser to pass
        any returned objects from the iterator through. This parser object
        must implement the parse() function, which takes a BioSequence object
        returned by the iterator. If not specified, the raw BioSequence object
        will be returned.
        """
        # determine if the object is already wrapped up inside a local client
        if isinstance(remote_collection, BioSequenceCollection):
            self._collection = remote_collection
        else:
            self._collection = BioSequenceCollection(remote_collection)
        self._parser = parser

        # set up our iterator by retrieving all seqs into an iterator
        seq_list, self._iterator = self._collection.get_seqs(0)
        assert len(seq_list) == 0, \
          "Unexpected items in the sequence list: %s" % seq_list

    def next(self):
        """Return the next item from the iterator.
        """
        try:
            next_seq = self._iterator.next()
        except StopIteration:
            return None

        if self._parser:
            return self._parser.parse(next_seq)
        else:
            return None

class FeatureParser:
    """Convert CorbaSeq objects into BioCorba.SeqRecord objects.
    """
    def __init__(self):
        pass

    def parse(self, seq):
        """Perform the conversion and return the new BioCorba.SeqRecord object.

        Returns the BioCorba.Bio object that mimics a Biopython SeqRecord.
        """
        return SeqRecord(seq)

