"""Biopython-like interface to Biocorba derived SeqFeatures.
"""
# biopython
import Bio.SeqFeature

# biopython-corba stuff
from BioCorba.Client.Seqcore.CorbaSeqFeature \
  import SeqFeature as CorbaSeqFeature
from BioCorba.Share.SeqFeature import _get_annotations

class SeqFeature:
    """Imitate a Biopython SeqFeature object using a BioCorba object.

    This is basically a wrapper around CorbaSeqFeature which makes
    it behave like the Biopython SeqFeature object.
    """
    def __init__(self, remote_seq_feature):
        """Initialize the SeqFeature object.

        Arguments:
        o remote_seq_feature - A reference to a server implementing
        the BioCorba SeqFeature interface.
        """
        # determine if the object is already wrapped up inside a local client
        if isinstance(remote_seq_feature, CorbaSeqFeature):
            self._seqfeat_obj = remote_seq_feature
        else:
            self._seqfeat_obj = CorbaSeqFeature(remote_seq_feature)

        # attributes we don't handle
        self.ref = None
        self.ref_db = None

        # internal attributes so we can save calling CORBA
        self._location = None
        self._type = None
        self._location_operator = None
        self._strand = None
        self._id = None
        self._qualifiers = None
        self._sub_features = None

        self._primary_location = None

    def __getattr__(self, name):
        """Override get_attribute to grab necessary info from the remote object
        """
        if name == "location":
            if self._location is None:
                self._location = self._get_location()
            return self._location
        elif name == "type":
            if self._type is None:  
                self._type = self._get_type()
            return self._type
        elif name == "strand":
            if self._strand is None:
                self._strand = self._get_strand()
            return self._strand
        elif name == "id":
            if self._id is None:
                self._id = self._get_id()
            return self._id
        elif name == "location_operator":
            if self._location_operator is None:
                self._location_operator = self._get_location_operator()
            return self._location_operator
        elif name == "qualifiers":
            if self._qualifiers is None:
                self._qualifiers = _get_annotations(self._seqfeat_obj)
            return self._qualifiers
        elif name == "sub_features":
            if self._sub_features is None:
                self._sub_features = self._get_subfeatures()
            return self._sub_features
        else:
            raise AttributeError("No attribute named %s" % name)

    def _get_primary_location(self):
        """Retrieve the primary location to use for this SeqFeature.

        This uses the CORBA SeqFeature object to retrieve what we 
        consider "the location" for this feature. We presume that
        the location we are interested in the first location returned
        from get_locations() and that all sub_locations are inside of
        that.

        This will need modifications if my thinking about how the spec
        works is not correct (which is always a distinct possibility :-).
        """
        # keep a cache so we can go across the network less
        if self._primary_location is not None:
            return self._primary_location

        seq_feat_locations = self._seqfeat_obj.get_locations()

        if len(seq_feat_locations) > 1:
            try:
                import warnings
                warnings.warn("Bad! Throwing away location information.")
            # if you don't use python 2.1, you don't get warned
            except ImportError:
                pass

        self._primary_location = seq_feat_locations[0]
        return self._primary_location

    def _get_location(self):
        """Return the location of this seqfeature from the BioCorba info.
        """
        seq_feature_location = self._get_primary_location()
        # The locations are converted into seq feature objects already
        # so we just need to return the location information from them
        return seq_feature_location.location

    def _get_location_operator(self):
        """Return the location_operator from the BioCorba info.
        """
        seq_feature_location = self._get_primary_location()
        return seq_feature_location.location_operator

    def _get_id(self):
        """Retrieve the id for this SeqFeature from CORBA location info.

        The location information will already have been converted into
        a SeqFeature object, so we just need to grab the ID from it.
        """
        seq_feature_location = self._get_primary_location()
        return seq_feature_location.id

    def _get_strand(self):
        """Retrieve the strand info on this SeqFeature.

        The strand info will be available from an already converted 
        SeqFeature object.
        """
        seq_feature_location = self._get_primary_location()
        return seq_feature_location.strand

    def _get_type(self):
        """Retrieve the SeqFeature type from a type annotation.

        We presume that the server sets the type information as an
        annotation on the SeqFeature object. I'm not positive if this
        is the right behavior. We'll see when we start testing with
        other peoples servers.
        """
        ann_name = self._seqfeat_obj.get_name()
        if ann_name == "type":
            return str(self._seqfeat_obj.get_value())
        else:
            try:
                import warnings
                warnings.warn("No type information found as annotation.")
            except ImportError:
                pass
            return ""

    def _get_subfeatures(self):
        """Retrieve the sequence features contained under this feature.
        
        The primary location should already have this converted information
        in it, so we only need to grab it out of there.
        """
        primary_seq_feature = self._get_primary_location()
        return primary_seq_feature.sub_features
