"""Local exceptions analagous to those raised in the CORBA interface.

This module contains local equivalents of the different exceptions that
are defined in the CORBA interface. This way, we can raise these
exceptions and people implementing clients don't need to deal with CORBA
exceptions, and know where the IDL files are that they come from.

See the idl files for more documentation about the conditions
that cause these exceptions to be raised.
"""
class RequestTooLarge(Exception):
    def __init__(self, reason, suggested_size):
        Exception.__init__(self, "Reason: %s; Suggested Size %s" %
                           (reason, suggested_size))
        
        self.reason = reason
        self.suggested_size = suggested_size

class IteratorInvalid(Exception):
    def __inti__(self, reason):
        Exception.__init__(self, "Reason: %s" % (reason))
        self.reason = reason

class DoesNotExist(Exception):
    def __init__(self, reason):
        Exception.__init__(self,
                           "Reason: %s" % reason)
        self.reason = reason

class IdentifierDoesNotExist(Exception):
    def __init__(self, id):
        Exception.__init__(self,
                           "ID: %s" % (id))

        self.id = id

class IdentifierNotResolvable(Exception):
    def __init__(self, id, reason):
        Exception.__init__(self,
                           "ID: %s, reason: %s" % (id, reason))
        self.id = id
        self.reason = reason

class IdentifierNotUnique(Exception):
    def __init__(self, id, ids):
        Exception.__init__(self,
                           "ID: %s, valid IDs: %s" % (id, ids))

        self.id = id
        self.ids = ids

class OutOfBounds(Exception):
    def __init__(self, reason):
        Exception.__init__(self, "Reason: %s" % reason)

        self.reason = reason

class IllegalSymbolException(Exception):
    def __init__(self, reason):
        Exception.__init__(self, "Reason: %s" % (reason))

        self.reason = reason

# -- seqcore exceptions
class SeqFeatureLocationOutOfBounds(Exception):
    def __init__(self, invalid, valid):
        # convert the regions to Biopython locations
        from BioCorba.Share import SeqFeature
        location_converter = SeqFeature._CorbaLocationConverter()
        biopy_invalid = location_converter.to_biopython_location(invalid)
        biopy_valid = location_converter.to_biopython_location(valid)
        Exception.__init__(self, "Invalid: %s, Valid: %s" 
                           % (biopy_invalid, biopy_valid))

        self.invalid = biopy_invalid
        self.valid = biopy_valid

class SeqFeatureLocationInvalid(Exception):
    def __init__(self, reason):
        Exception.__init__(self, "Reason: %s" % reason)
        self.reason = reason
        
