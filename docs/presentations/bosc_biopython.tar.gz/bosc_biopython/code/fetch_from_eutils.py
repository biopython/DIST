#!/usr/bin/env python
"""Demonstration code from Biopython talk about fetching data using EUtils.
"""
search_string = "Myb AND txid3702[ORGN] AND 0:6000[SLEN]"

from Bio.EUtils import HistoryClient

client = HistoryClient.HistoryClient()
results = client.search(search_string, db = "nucleotide")
print "Number of Results:", len(results)

gb_handle = results.efetch(retmode = "text", rettype = "gb")

from Bio import GenBank

parser = GenBank.FeatureParser()
iterator = GenBank.Iterator(gb_handle, parser)

arabidopsis_names = []

while 1:
    record = iterator.next()
    if not(record):
        break
    
    if record.name[:2] == "At" and record.name not in arabidopsis_names:
        arabidopsis_names.append(record.name)

from Bio import Cluster

data_parts = Cluster.readdatafile("chitin_data.txt")
values = data_parts[0]
geneids = data_parts[2]
experiments = data_parts[6]

myb_values = []
myb_geneids = []
for cur_name in arabidopsis_names:
    try:
        cur_index = geneids.index(cur_name)
        myb_values.append(values[cur_index])
        myb_geneids.append(cur_name)
    except ValueError:
        pass
        
gene_clusters, gene_linkdist = Cluster.treecluster(myb_values)
exp_clusters, exp_linkdist = Cluster.treecluster(myb_values, transpose = 1)
Cluster.writeclusterfiles("myb_chitin", myb_values,
                          myb_geneids, experiments,
                          geneclusters = gene_clusters,
                          genelinkdist = gene_linkdist,
                          expclusters = exp_clusters,
                          explinkdist = exp_linkdist)
