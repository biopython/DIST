import random
class LotteryNumber:
    """Play LOTTO SOUTH, y'all. It's a Southern thing.
    """
    def __str__(self):
        numbers = self.pick_numbers()
        return "-".join(numbers)
    def pick_numbers(self, number = 6, low = 1, high = 49):
        values = []
        for num in range(number):
            values.append(str(random.randrange(low, high)))
        return values

winning_number = LotteryNumber()
print winning_number
