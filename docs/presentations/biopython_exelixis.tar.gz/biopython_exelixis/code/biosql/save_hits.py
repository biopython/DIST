input_handle = open("input.fasta")

from Bio import Fasta
parser = Fasta.RecordParser()
iterator = Fasta.Iterator(input_handle, parser)
rec = iterator.next()

from Bio.Blast import NCBIWWW
results_handle = NCBIWWW.blast('blastp', 'swissprot',
                               str(rec), expect=1e-10)
"""
save_file = open("input.blast", 'w')
save_file.write(results_handle.read())
save_file.close()
results_handle = open("input.blast")
"""

blast_parser = NCBIWWW.BlastParser()
record = blast_parser.parse(results_handle)

swissprot_ids = []
for description in record.descriptions:
    swissprot_id = description.title.split("|")[1]
    swissprot_ids.append(swissprot_id)

from Bio.EUtils import DBIds
from Bio.EUtils import DBIdsClient
db_ids = DBIds("protein", swissprot_ids)
eutils_client = DBIdsClient.from_dbids(db_ids)
genbank_handle = eutils_client.efetch(retmode="text", rettype="gp")
"""
genbank_handle = open("hits.gb", "w")
genbank_handle.write(eutils_handle.read())
genbank_handle.close()
"""

from Bio import GenBank
parser = GenBank.FeatureParser()
iterator = GenBank.Iterator(genbank_handle, parser)

from BioSQL import BioSeqDatabase
server = BioSeqDatabase.open_database(driver = "MySQLdb", user = "chapmanb",
            passwd = "biopython", host = "localhost", db = "oncogene")
db = server.new_database("swissprot_hits")

db.load(iterator)
