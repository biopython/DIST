import Martel

title = Martel.Str("psLayout version") + Martel.Spaces() + \
        Martel.Integer("blat_version") + Martel.Rep(Martel.AnyEol())

header_lines = Martel.RepN(Martel.ToEol(), 3)

hit_line = Martel.Group("hit_line",
  # read the query information
  Martel.UntilSep("query_name", "\t") + Martel.Str("\t") +
  Martel.Integer("query_start") + Martel.ToSep(sep = "\t") +
  Martel.Integer("query_end") + Martel.ToSep(sep = "\t") +

  # read the target information
  Martel.UntilSep("target_name", "\t") + Martel.Str("\t") +
  Martel.Integer("target_start") + Martel.ToSep(sep = "\t") +
  Martel.Integer("target_end"))


from Martel import RecordReader
from Bio import Std

record = Std.record(hit_line + Martel.AnyEol())

format = Martel.HeaderFooter("blat", {"format" : "blat"},
            title + header_lines, RecordReader.CountLines, (5,),
            record, RecordReader.CountLines, (1,),
            None, None, None)
