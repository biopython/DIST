import blat

input_handle = open("blat_ex.psl")
iterator_builder = blat.format.make_iterator("record")

from Martel.LAX import LAX
handler = LAX(fields = ["query_name", "query_start", "query_end",
                     "target_name", "target_start", "target_end"])

#from xml.sax import saxutils
#handler = saxutils.XMLGenerator()

iterator = iterator_builder.iterateFile(input_handle, handler)

for result in iterator:
    print result
