import sys

i = open(sys.argv[1])
o = open(sys.argv[2], "w")
o.write(i.readline())
o.write(i.readline())

good_parts = [9, 11, 12, 13, 15, 16]

# header lines
for index in range(2):
    parts = i.readline().split('\t')
    good = []
    for i_good in good_parts:
        good.append(parts[i_good])
    o.write("\t".join(good) + "\n")
o.write(i.readline())

for line in i.xreadlines():
    parts = line.split('\t')
    good = []
    for i_good in good_parts:
        good.append(parts[i_good])
    o.write("\t".join(good) + "\n")
