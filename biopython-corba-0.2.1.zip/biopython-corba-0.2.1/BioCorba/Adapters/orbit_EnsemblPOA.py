"""Wrappers around ORBit dynamic loading so it behaves like skeletons.
"""
# import the General Adapter code
from BioCorba.Adapters.Generic import GenericORBitAdapter

# import the actual skeleton code
import os
current_dir = os.path.dirname(__file__)
import CORBA
CORBA._load_idl(os.path.join(current_dir, os.pardir, os.pardir, os.pardir,
                             'ensembl.idl'))
import org__POA.ensembl as ensembl__POA

class Exon(ensembl__POA.Exon, GenericORBitAdapter):
    unique_name = 'Exon'

class Translation(ensembl__POA.Translation, GenericORBitAdapter):
    unique_name = 'Translation'

class Transcript(ensembl__POA.Transcript, GenericORBitAdapter):
    unique_name = 'Transcipt'
        
class Gene(ensembl__POA.Gene, GenericORBitAdapter):
    unique_name = 'Gene'

class GeneIterator(ensembl__POA.GeneIterator, GenericORBitAdapter):
    unique_name = 'GeneIterator'

class VirtualContig(ensembl__POA.VirtualContig, GenericORBitAdapter):
    unique_name = 'VirtualContig'

class GeneFactory(ensembl__POA.GeneFactory, GenericORBitAdapter):
    unique_name = 'GeneFactory'

class VirtualContigFactory(ensembl__POA.VirtualContigFactory,
                           GenericORBitAdapter):
    unique_name = 'VirtualContigFactory'

class EnsemblFactory(ensembl__POA.EnsemblFactory, GenericORBitAdapter):
    unique_name = 'EnsemblFactory'


        
