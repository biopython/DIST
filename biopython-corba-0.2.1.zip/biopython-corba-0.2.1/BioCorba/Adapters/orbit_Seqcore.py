"""Wrappers around ORBit dynamic loading so it behaves like skeletons.
"""
# import the actual skeleton code
import os
current_dir = os.path.dirname(__file__)
import CORBA
CORBA._load_idl(os.path.join(current_dir, os.pardir, os.pardir, os.pardir,
                             'biocorba.idl'))
import org.biocorba.seqcore

# hack borrowed from omniORB to make it seem like the code is here
import sys
sys.modules["BioCorba.org.biocorba.seqcore"] = org.biocorba.seqcore
