"""Wrappers around actual Fnorb stubs so they behave like the python
 mapping.

Each class does two things:
1. Inherets from the actual skel, so that the inheritence in the main code
can be uniform.

2. Defines a _this() function which creates a unique object ref for a
class object, and registers it with the boa.
"""
# import the General Adapter code
from BioCorba.Adapters.Generic import GenericFnorbAdapter

# the actual skeleton code
import BioCorba.GNOME_skel as skel_base

class Unknown(skel_base.Unknown_skel, GenericFnorbAdapter):
    unique_name = 'Unknown'
