"""Generic Adapters for use with different ORB implementations.

classes:
GenericFnorbAdapter
"""
class GenericFnorbAdapter:
    """Define functions which can be utilized across multiple adapters.

    Adapters for specific classes should multiply inherit from this adapter
    and define attributes specific for their class.
    """
    unique_key = 0
    unique_name = None
    
    def _this(self):
        from Fnorb.orb import BOA
        boa = BOA.BOA_init([], BOA.BOA_ID)       
        assert self.__class__.unique_name is not None, \
               "Need to define a unique adapter name"
        self.__class__.unique_key += 1
        
        obj_ref = boa.create(self.__class__.unique_name +
                             str(self.__class__.unique_key),
                             self._FNORB_ID)
        boa.obj_is_ready(obj_ref, self)

        return obj_ref

class GenericORBitAdapter:
    """Define functions usable for all of the ORBit adapaters.

    ORBit-python doesn't define _narrow, yet, so we override it here to
    be a no-op.
    """
    def _narrow(self, obj_interface):
        return self
