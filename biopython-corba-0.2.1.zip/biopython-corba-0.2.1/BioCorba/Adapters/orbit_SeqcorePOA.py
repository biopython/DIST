"""Wrappers around ORBit dynamic loading so it behaves like skeletons.
"""
# import the General Adapter code
from BioCorba.Adapters.Generic import GenericORBitAdapter

# import the actual skeleton code
import os
current_dir = os.path.dirname(__file__)
import CORBA
CORBA._load_idl(os.path.join(current_dir, os.pardir, os.pardir, os.pardir,
                             'biocorba.idl'))
import org__POA.biocorba.seqcore as seqcore__POA
        
class AnonymousSeq(seqcore__POA.AnonymousSeq, GenericORBitAdapter):
    unique_name = 'AnonymousSeq'

class BioEnv(seqcore__POA.BioEnv, GenericORBitAdapter):
    unique_name = 'BioEnv'

class PrimarySeq(seqcore__POA.PrimarySeq, GenericORBitAdapter):
    unique_name = 'PrimarySeq'

class PrimarySeqDB(seqcore__POA.PrimarySeqDB, GenericORBitAdapter):
    unique_name = 'PrimarySeqDB'

class PrimarySeqIterator(seqcore__POA.PrimarySeqIterator,
                         GenericORBitAdapter):
    unique_name = 'PrimarySeqIterator'

class PrimarySeqVector(seqcore__POA.PrimarySeqVector, GenericORBitAdapter):
    unique_name = 'PrimarySeqVector'

class Seq(seqcore__POA.Seq, GenericORBitAdapter):
    unique_name = 'Seq'

class SeqDB(seqcore__POA.SeqDB, GenericORBitAdapter):
    unique_name = 'SeqDB'

class SeqFeature(seqcore__POA.SeqFeature, GenericORBitAdapter):
    unique_name = 'SeqFeature'

class SeqFeatureIterator(seqcore__POA.SeqFeatureIterator,
                         GenericORBitAdapter):
    unique_name = 'SeqFeatureIterator'

class SeqFeatureVector(seqcore__POA.SeqFeatureVector, GenericORBitAdapter):
    unique_name = 'SeqFeatureVector'

class UpdateableSeqDB(seqcore__POA.UpdateableSeqDB, GenericORBitAdapter):
    unique_name = 'UpdateableSeqDB'
