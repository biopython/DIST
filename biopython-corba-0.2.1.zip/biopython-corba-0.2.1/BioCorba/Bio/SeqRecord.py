# Copyright 2000 by Brad Chapman.  All rights reserved.
# This code is part of the Biopython distribution and governed by its
# license.  Please see the LICENSE file that should have been included
# as part of this package.

# BioCorba.Bio classes we return instances of
from BioCorba.Bio.Seq import Seq
from BioCorba.Bio.SeqFeature import SeqFeature

# other biopython-corba stuff
from BioCorba.Client.Seqcore.CorbaPrimarySeq import CorbaPrimarySeq
from BioCorba.Client.Seqcore.CorbaSeq import CorbaSeq

class SeqRecord:
    """SeqRecord implementation class for use with the corba interface.

    Basically, this is a wrapper around the PrimarySeq interface.
    """
    def __init__(self, remote_seq):
        """Intialize a SeqRecord class that can return basic sequence info.

        Arguments:
        remote_pseq - A Seq object obtained from a BioCorba
        server. This will be used to send requests through corba
        to the other interfaces.
        """
        # determine if the seq object has already been wrapped around
        # a local client object
        if isinstance(remote_seq, CorbaSeq):
            self._corba_seq = remote_seq
        # we can also handle a PrimarySeq and make it look like a Seq
        # without any features
        elif isinstance(remote_seq, CorbaPrimarySeq):
            self._corba_seq = remote_seq
            self.features = []
        else:
            self._corba_seq = CorbaSeq(remote_seq)

        self.annotations = {}

    def __getattr__(self, name):
        """Override get attribute to provide attributes through CORBA.
        """
        if name == "seq":
            return Seq(self._corba_seq)
        elif name == "id":
            return self._corba_seq.primary_id()
        elif name == "name":
            return self._corba_seq.accession_number()
        elif name == "description":
            return self._corba_seq.display_id()
        elif name == "features":
            return self._get_features()
        else:
            raise AttributeError("No attribute named %s" % name)

    def _get_features(self):
        """Retrieve SeqFeature objects for all seqfeatures of this object.

        Returns:
        o A list of BioCorba.Bio.SeqFeature objects.
        """
        # the list of seqfeatures to return
        bio_seqfeatures = []

        # get the vector of corba SeqFeatures and convert them over
        seqfeat_vector = self._corba_seq.all_SeqFeatures(1)

        for vector_item in range(seqfeat_vector.size()):
            # elementAt retrieves elements starting at 1, not zero, so
            # add one to the vector_item number
            cur_seqfeat = seqfeat_vector.elementAt(vector_item + 1)

            bio_seqfeat = SeqFeature(cur_seqfeat)
            bio_seqfeatures.append(bio_seqfeat)

        return bio_seqfeatures
            
        
