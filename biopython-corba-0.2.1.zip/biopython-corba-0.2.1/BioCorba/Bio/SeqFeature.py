"""Biopython-like interface to Biocorba derived SeqFeatures.
"""
# biopython
import Bio.SeqFeature

# biopython-corba stuff
from BioCorba.Client.Seqcore.CorbaSeqFeature import CorbaSeqFeature

class SeqFeature:
    """Imitate a Biopyhon SeqFeature object using a BioCorba object.

    This is basically a wrapper around CorbaSeqFeature which makes
    it behave like the Biopython SeqFeature object.
    """
    def __init__(self, remote_seq_feature):
        """Initialize the SeqFeature object.

        Arguments:
        o remote_seq_feature - A reference to a server implementing
        the BioCorba SeqFeature interface.
        """
        # determine if the object is already wrapped up inside a local client
        if isinstance(remote_seq_feature, CorbaSeqFeature):
            self._seqfeat_obj = remote_seq_feature
        else:
            self._seqfeat_obj = CorbaSeqFeature(remote_seq_feature)

        # attributes we don't handle
        self.ref = None
        self.ref_db = None

    def __getattr__(self, name):
        """Override get_attribute to grab necessary info from the remote object
        """
        if name == "location":
            return self._get_location()
        if name == "type":
            return self._seqfeat_obj.type()
        elif name == "strand":
            return self._seqfeat_obj.strand()
        elif name == "qualifiers":
            return self._seqfeat_obj.qualifiers()
        elif name == "sub_features":
            return self._get_subfeatures()
        else:
            raise AttributeError("No attribute named %s" % name)

    def _get_location(self):
        """Return the location of this seqfeature from the BioCorba info.

        BioCorba returns all locations of subfeatures (ie. the equivalent
        of an entire GenBank/EMBL location line) while Biopython only
        returns the first and last (ie. the overall location of the whole
        feature). So we need to extract the second information and
        return it.

        Additionally the list returned from BioCorba also has strand
        info that we can ignore.
        """
        # all_location_info[x][0] - location info (this is what we want)
        # all_location_info[x][1] - strand info (we don't need this)
        all_location_info = self._seqfeat_obj.locations()
        start_pos = all_location_info[0][0].start
        end_pos = all_location_info[-1][0].end

        return Bio.SeqFeature.FeatureLocation(start_pos, end_pos)

    def _get_subfeatures(self):
        """Retrieve the sequence features contained under this feature.

        Returns:
        o A list of BioCorba.Bio.SeqFeature objects.
        """
        # the list of seqfeatures to return
        bio_seqfeatures = []

        # get the vector of corba SeqFeatures and convert them over
        seqfeat_vector = self._seqfeat_obj.sub_SeqFeatures(1)

        for vector_item in range(seqfeat_vector.size()):
            # elementAt retrieves elements starting at 1, not zero, so
            # add one to the vector_item number
            cur_seqfeat = seqfeat_vector.elementAt(vector_item + 1)

            bio_seqfeat = SeqFeature(cur_seqfeat)
            bio_seqfeatures.append(bio_seqfeat)

        return bio_seqfeatures
        
        
