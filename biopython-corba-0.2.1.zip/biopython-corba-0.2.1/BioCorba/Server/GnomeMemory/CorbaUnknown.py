# stubs generated from the idl
import BioCorba.GNOME__POA
import BioCorba.GNOME

# factory class to make a server object
from BioCorba.Server import ServerFactory

class CorbaUnknown(BioCorba.GNOME__POA.Unknown):
    """Base class for BioCorba objects that provides memory management.
    """
    def __init__(self):
        # create a server based on the server type defined in the config file
        self._server = ServerFactory.create_server()

        # register ourselves with the server
        self._corba_object = self._server.register_object(self)

    # Biocorba functions to be called by a CORBA client
    def ref(self):
        pass

    def unref(self):
        self._server.deactivate_object(self._corba_object)
        self._corba_object = None

    def query_interface(self, repoid):
        return self._corba_object

    # server functions which will be called by the server implementor
    def run(self):
        """Run the server and wait for client calls.

        This function causes the server to tie up the thread it is called
        in as the server will sit and block waiting for client calls.
        """
        self._server.run()
        
    def get_object(self):
        """Return the CORBA object corresponding to this class.
        """
        return self._corba_object
    
    def get_string_ior(self):
        """Return the string IOR of the object.
        """
        return self._server.get_stringified_obj(self._corba_object)

    def string_ior_to_file(self, file):
        """Convenience function to write the IOR to a file.
        """
        ior_file = open(file, 'w')
        ior_file.write(self.get_string_ior())
        ior_file.close()
