"""Module holding servers for biological iterators.

classes:
o AbstractCorbaIterator - Abstract base class for iterators
o CorbaPrimarySeqIterator - Iterate over PrimarySeq objects
o CorbaSeqFeatureIterator - Iterator over SeqFeature objects
"""
# stubs generated from the idl
import BioCorba.org__POA.biocorba.seqcore as seqcore__POA
import BioCorba.org.biocorba.seqcore as seqcore

# the class we inheret from
from BioCorba.Server.GnomeMemory.CorbaUnknown import CorbaUnknown

# classes we'll be returning instances of
from CorbaPrimarySeq import CorbaPrimarySeq
from CorbaSeqFeature import CorbaSeqFeature

class AbstractCorbaIterator:
    """Provide base funcitonality for a CORBA iterator.

    This just implements functionality which can be reused across
    multiple iterators.
    """
    def __init__(self, iterator):
        """Initialize with the iterator object.

        Arguments:
        o iterator -  Assumed to return a new object when next() is called
        and None when there are no objects left.
        """
        self._iterator = iterator

        # a cached sequence which may be filled if has_more() is called
        self._cached_object = None
        # a flag that indicates we are at the end of the stream
        self._end_of_stream = 0
        # a flag to indicate we should raise a UnableToProcess error
        # holds the message to return
        self._unable_to_process = ""

    def _get_next_object(self):
        """Returns the next object from the iterator

        This returns the next object or None, if we can't get another object.
        If we have any processing errors, the flag _unable_to_process
        will be set with the error message.
        """
        # check if we are unable to process more sequences
        if self._unable_to_process:
            return None
        if self._cached_object is not None:
            next_object = self._cached_object
            self._cached_object = None
        elif self._end_of_stream == 0:
            try:
                next_object = self._iterator.next()
            except IOError:
                next_object = None
                self._unable_to_process = 'The file to process was not found.'
        else:
            next_object = None

        return next_object

    def next(self):
        raise NotImplementedError("Derived classes must define.")

    def has_more(self):
        """Check if the iterator has more sequences to spit out.

        Returns 0 if there is nothing left to be called, and 1 if
        there are more sequences.

        This implements a has_more with only the requirement that the
        iterator returns None when it has nothing left. This uses
        """
        # check if we've already come to the end
        if self._end_of_stream:
            return 0
        else:
            # if we already have a good cached seq, then we've got something
            # to return
            if self._cached_object is not None:
                return 1
            else:
                try:
                    # try to get the next sequence, and if we can't do
                    # it, interpret this as the end
                    self._cached_object = self._iterator.next()
                    if self._cached_object is not None:
                        return 1
                    else:
                        self._end_of_stream = 1
                        return 0
                # catch IOErrors and interpret these as being unable to process
                except IOError:
                    self._unable_to_process = "File to process was not found."
                    self._end_of_stream = 1
                    return 0

class CorbaPrimarySeqIterator(seqcore__POA.PrimarySeqIterator, CorbaUnknown,
                              AbstractCorbaIterator):
    """BioCorba implementation of a PrimarySeqIterator class.

    This class implements an iterator to move (forward only) over a list
    of sequence data (ie. a fasta file).

    This class inherets from:
    * org__POA.Biocorba.Seqcore.PrimarySeqIterator - The corba stub
    code defining the corba connection.
    * CorbaUnknown - The corba class from which
    this derives in the idl. CorbaUnknown provides basic memory management
    functions.
    * AbstractCorbaIterator - A CorbaIterator that provides most of the
    necessary iterator functionality.
    """
    def __init__(self, iterator):
        """Initialize a PrimarySeqIterator object.

        Arguments:
        iterator - The iterator is assumed to be a reference to a
        pre-initialized file/db reader which implements a next()
        function and returns SeqRecords appropriate for feeding
        into CorbaPrimarySeq
        """
        CorbaUnknown.__init__(self)
        AbstractCorbaIterator.__init__(self, iterator)

    def unref(self):
        """Get rid of our local iterator object when unreffing.
        """
        self._iterator = None
        CorbaUnknown.unref(self)

    def next(self):
        """Return the next primary sequence in the series.

        Calls the next() function on the iterator and returns a
        PrimarySeq object with the results.

        Raises:
        * EndOfStream - If there are no more sequences to process
        (ie. the next() function returns None).
        * UnableToProcess - If there is some kind of other problem.
        Right now this is called if the iterator raises an IOError.
        """
        next_seq = self._get_next_object()

        # check if we were unable to process the next object
        if self._unable_to_process:
            raise seqcore.UnableToProcess(self._unable_to_process)

        # see if we are at the end of the file.
        if next_seq is None:
            self._end_of_stream = 1
            raise seqcore.EndOfStream

        # Otherwise get a primary sequence object to return.
        pseq_obj = CorbaPrimarySeq(next_seq)
        return pseq_obj.get_object()

class CorbaSeqFeatureIterator(seqcore__POA.SeqFeatureIterator, CorbaUnknown,
                              AbstractCorbaIterator):
    """SeqFeatureIterator BioCorba implementation.

    This class inherits from:
    * org__POA.biocorba.seqcore.SeqFeatureIterator - The corba stub code
    implementing code for connecting through corba (this is
    generated by the orb implementation.)
    * CorbaUnknown - The memory management class from which this
    inherets in the idl.
    * AbstractCorbaIterator - A CorbaIterator that provides most of the
    necessary iterator functionality.
    """
    def __init__(self, iterator):
        """Initialize a PrimarySeqIterator object.

        Arguments:
        iterator - The iterator is assumed to be a reference to a
        pre-initialized file/db reader which implements a next()
        function and returns SeqRecords appropriate for feeding
        into CorbaPrimarySeq
        """
        CorbaUnknown.__init__(self)
        AbstractCorbaIterator.__init__(self, iterator)

    def unref(self):
        """Get rid of our local iterator object when unreffing.
        """
        self._iterator = None
        CorbaUnknown.unref(self)

    def next(self):
        """Return the next primary sequence in the series.

        Calls the next() function on the iterator and returns a
        PrimarySeq object with the results.

        Raises:
        * EndOfStream - If there are no more sequences to process
        (ie. the next() function returns None).
        * UnableToProcess - If there is some kind of other problem.
        Right now this is called if the iterator raises an IOError.
        """
        next_feature = self._get_next_object()

        # check if we were unable to process the next object
        if self._unable_to_process:
            raise seqcore.UnableToProcess(self._unable_to_process)

        # see if we are at the end of the file.
        if next_feature is None:
            self._end_of_stream = 1
            raise seqcore.EndOfStream

        # Otherwise get a primary sequence object to return.
        seqfeat_obj = CorbaSeqFeature(next_feature)
        return seqfeat_obj.get_object()
