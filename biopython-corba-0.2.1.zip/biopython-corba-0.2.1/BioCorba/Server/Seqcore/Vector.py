"""Vector (list-like) objects of biological information.

These are slightly more advanced then iterators, since objects can be
accessed by index instead of iteration.

classes:
o ListIterator - provides a mechanism for converting Vector lists into
iterators.
o CorbaPrimarySeqVector - A vector of PrimarySeq objects.
o CorbaSeqFeatureVector - A Vector of SeqFeature objects.
o CorbaRestrictedSeqFeatureVector - A vector of SeqFeature objects which
can be restricted in size by different criterion.
"""
# stubs generated from the idl
import BioCorba.org__POA.biocorba.seqcore as seqcore__POA
import BioCorba.org.biocorba.seqcore as seqcore

# the class we inheret from
from BioCorba.Server.GnomeMemory.CorbaUnknown import CorbaUnknown

# classes we'll be returning instances of
from CorbaPrimarySeq import CorbaPrimarySeq
from CorbaSeqFeature import CorbaSeqFeature
from Iterator import CorbaPrimarySeqIterator, CorbaSeqFeatureIterator

class CorbaPrimarySeqVector(seqcore__POA.PrimarySeqVector, CorbaUnknown):
    """Vector (list-like) object holding PrimarySeq objects.

    This inherits from:
    o org__POA.biocorba.seqcore.PrimarySeqVector - The stubs generated
    by the IDL compiler which allow the class to plug into CORBA.
    o CorbaUnknown - The memory management class from which this inherits
    in the IDL definitions.
    """
    def __init__(self, pseq_list, provide_vector = 1):
        """Initialize with a list-like object to provide the information.

        The Vector interface supports two kind of objects:
        1. A list like object (must implement __getitem__ and __len__)
        which can be accessed using indexing. In this case, pseq_list is
        this list object and provide_vector (ie. provide vector capabilities)
        should be set at 1.
        2. A iterator only object, which implements next() only and not
        subscripting. In this case, pseq_list should be this iterator, and
        provide_vector should be set at 0.

        In both cases, ever item gotten from the list or iterator object
        should be a Biopython SeqRecord object.
        """
        CorbaUnknown.__init__(self)
        self._provide_vector = provide_vector
        self._object_list = pseq_list

    def unref(self):
        self._object_list = None
        CorbaUnknown.unref(self)

    def size(self):
        if self._provide_vector:
            return len(self._object_list)
        else:
            return 0

    def elementAt(self, index):
        # BioCorba index numbers start at one (slice operations)
        # so we need to convert 'em to python index numbers
        py_index = index - 1
        if self._provide_vector:
            try:
                seq_record_item = self._object_list[py_index]
                pseq_item = CorbaPrimarySeq(seq_record_item)
                return pseq_item.get_object()
            except IndexError:
                raise seqcore.OutOfRange("List index %s out of range" % index)
        else:
            return None

    def iterator(self):
        if self._provide_vector:
            seq_record_it = ListIterator(self._object_list)
            pseq_it = CorbaPrimarySeqIterator(seq_record_it)
        else:
            pseq_it = CorbaPrimarySeqIterator(self._object_list)

        return pseq_it.get_object()

class CorbaSeqFeatureVector(seqcore__POA.SeqFeatureVector, CorbaUnknown):
    """Vector (list-like) object holding SeqFeature objects.

    This inherits from:
    o org__POA.biocorba.seqcore.SeqFeatureVector - The stubs generated
    by the IDL compiler which allow the class to plug into CORBA.
    o CorbaUnknown - The memory management class from which this inherits
    in the IDL definitions.
    """
    def __init__(self, seqfeat_list, provide_vector = 1):
        """Initialize with a list-like object to provide the information.

        The Vector interface supports two kind of objects:
        1. A list like object (must implement __getitem__ and __len__)
        which can be accessed using indexing. In this case, seqfeat_list is
        this list object and provide_vector (ie. provide vector capabilities)
        should be set at 1.
        2. A iterator only object, which implements next() only and not
        subscripting. In this case, seqfeat_list should be this iterator, and
        provide_vector should be set at 0.

        In both cases, ever item gotten from the list or iterator object
        should be a Biopython SeqFeature object.
        """
        CorbaUnknown.__init__(self)
        self._provide_vector = provide_vector
        self._object_list = seqfeat_list

    def unref(self):
        self._object_list = None
        CorbaUnknown.unref(self)

    def size(self):
        if self._provide_vector:
            return len(self._object_list)
        else:
            return 0

    def elementAt(self, index):
        # BioCorba index numbers start at one (slice operations)
        # so we need to convert 'em to python index numbers
        py_index = index - 1
        if self._provide_vector:
            try:
                biopy_feature_item = self._object_list[py_index]
                seq_feature_item = CorbaSeqFeature(biopy_feature_item)
                return seq_feature_item.get_object()
            except IndexError:
                raise seqcore.OutOfRange("List index %s out of range" % index)
        else:
            return None

    def iterator(self):
        if self._provide_vector:
            biopy_feature_it = ListIterator(self._object_list)
            seq_feature_it = CorbaSeqFeatureIterator(biopy_feature_it)
        else:
            seq_feature_it = CorbaSeqFeatureIterator(self._object_list)

        return seq_feature_it.get_object()

class CorbaRestrictedSeqFeatureVector(CorbaSeqFeatureVector):
    """Represent a SeqFeatureVector with items restricted by criterion.

    This is almost identical to a SeqFeatureVector, except that the
    passed seqfeat_list can be reduced by some kind of critereon. Right
    now the list can be reduced by range (ie. a region of a sequence)
    and type.
    """
    # Hmmm... This is a pretty restrictive implementation since the
    # restriction variables are passed in as arguments. Maybe I could make
    # it more general to handle more cases -- I need to think about it.
    
    def __init__(self, seqfeat_list, provide_vector = 1, use_subfeatures = 1,
                 start = None, end = None, type = None):
        """Initialize a seqfeat_list to be restricted.

        Arguments:
        o seqfeat_list - The list (or iterator -- see CorbaSeqFeatureVector)
        containing the information which will be restricted.
        o provide_vector - Whether or not seqfeat_list provides list
        capabilities.
        o use_subfeatures - A flag to indicate whether or not subfeatures
        should be returned if asked for.
        o start - The start site to restrict features to being after.
        o end - The end site to restrict features to being after.
        o type - A string indicating which type of features should be
        included (ie. 'exon', 'CDS', ...)
        """
        self._original_list = seqfeat_list
        # we don't want to mess with seqfeature_iterators right now
        # Will add this functionality if we need it.
        if provide_vector == 0:
            raise NotImplementedError("Cannot restrict iterator only objects.")
        
        new_list = seqfeat_list

        # restrict the list to only the items we are interested in
        if start is not None:
            new_list = self._restrict_by_start(new_list, start)
        if end is not None:
            new_list = self._restrict_by_end(new_list, end)
        if type is not None:
            new_list = self._restrict_by_type(new_list, type)

        # if the list shouldn't return sub_features, add this information
        # to all of the features
        if use_subfeatures == 0:
            for item_subs in range(len(new_list)):
                new_list[item_subs].return_subfeatures = 0

        # now we've got the list we are interested in, initialize
        # a SeqFeatureVector with it
        CorbaSeqFeatureVector.__init__(self, new_list, 1)

    def _restrict_by_start(self, orig_list, start_num):
        """Reduce the list to items with a start greater then start_num.
        """
        new_list = []
        for list_item in range(len(orig_list)):
            cur_seqfeat = orig_list[list_item]

            # check the start position
            # if it is bigger then our restriction number, add it
            if cur_seqfeat.location.start.position >= start_num:
                new_list.append(cur_seqfeat)

        return new_list

    def _restrict_by_end(self, orig_list, end_num):
        """Reduce the list to items with a end less then end_num.
        """
        new_list = []
        for list_item in range(len(orig_list)):
            cur_seqfeat = orig_list[list_item]

            # check the end position
            # if it is less then end_num, add it to the list to return
            if cur_seqfeat.location.end.position <= end_num:
                new_list.append(cur_seqfeat)

        return new_list

    def _restrict_by_type(self, orig_list, feat_type):
        """Reduce the list to items that have a type of feat_type.
        """
        new_list = []
        for list_item in range(len(orig_list)):
            cur_seqfeat = orig_list[list_item]

            if cur_seqfeat.type == feat_type:
                new_list.append(cur_seqfeat)

        return new_list
        
class ListIterator: 
    """Make a list behave as if it is a next-only iterator.

    This allows python lists to be plugged into the CORBA iterator interface.
    """
    def __init__(self, list):
        self._list = list
        self._current_index = 0

    def next(self):
        if self._current_index >= len(self._list):
            return None
        else:
            next_object = self._list[self._current_index]
            self._current_index += 1

            return next_object
