# Copyright 2000 by Brad Chapman.  All rights reserved.
# This code is part of the Biopython distribution and governed by its
# license.  Please see the LICENSE file that should have been included
# as part of this package.
"""BioEnv -- Biological Sequence Database Factory

classes:
o SeqIteratorFactory - A factory to generate iterators for the BioEnv object.
o CorbaBioEnv - The CORBA Factory object.
"""
# stubs generated from the idl
import BioCorba.org__POA.biocorba.seqcore as seqcore__POA
import BioCorba.org.biocorba.seqcore as seqcore

# standard modules
import os
import string

# classes we inherit from
from BioCorba.Server.GnomeMemory.CorbaUnknown import CorbaUnknown

# classes we'll be returning instances of
from CorbaPrimarySeq import CorbaPrimarySeq
from CorbaSeq import CorbaSeq
from Iterator import CorbaPrimarySeqIterator
from Database import CorbaSeqDB, CorbaPrimarySeqDB

# BioPython modules
from Bio import Fasta
from Bio import GenBank

class SeqIteratorFactory:
    """Generate Biopython Seq iterators from files.

    This is just meant to encapsulate the creation of iterators so
    that it can reused across multiple functions.

    This Factory generates iterators that return SeqRecord objects.
    """
    def __init__(self):
        self._type = 'seq'

        self.formats = {'fasta' : ['.fasta'],
                        'genbank' : ['.gb', '.genbank']}

    def get_iterator(self, filename, file_format = None):
        """Create an iterator from the given file.

        Arguments:
        o filename - The full path to the file of interest.
        o file_format - The format of the file. If this is not supplied, then
        we will try to guess the format of the file from the extension.
        The supported formats and extensions are given in the formats
        attribute of this class.
        """
        file_format = string.lower(file_format)
        
        # get the file extension
        file, ext = os.path.splitext(filename)

        # check all of the format types and call the correct one
        format_type_list = self.formats.keys()
        format_type_list.sort()
        for format_type in format_type_list:
            if file_format == format_type or ext in self.formats[format_type]:
                # create the function to call ("_formatname_iterator")
                format_fun_name = "_" + format_type + "_iterator"
                format_function = getattr(self.__class__, format_fun_name)

                try:
                    file_handle = open(filename, 'r')
                except IOError:
                    raise IOError("File not found.")

                return format_function(self, file_handle)

        # if we get here we couldn't determine the format or don't support it
        raise IOError("File format not recognized or supported.")

    def _fasta_iterator(self, fasta_handle):
        parser = Fasta.SequenceParser()

        return Fasta.Iterator(fasta_handle, parser)

    def _genbank_iterator(self, genbank_handle):
        parser = GenBank.FeatureParser()

        return GenBank.Iterator(genbank_handle, parser)
        
class CorbaBioEnv(seqcore__POA.BioEnv, CorbaUnknown):
    """Factory interface used to retrieve sequences, iterators and databases.

    The BioEnv interface is meant to be the main connection interface for
    working with BioCorba objects. 
    This interface is then used to get object references to other interfaces
    of interest including sequences, iterators and databases.

    This class inherets from:
    * org__POA.Biocorba.Seqcore.BioEnv - The corba skeleton code which
    defines the connection of this class
    * CorbaUnknown - Provides basic server functionality.
    """
    def __init__(self, initial_db_info = {}):
        """Initialize the BioEnv object.

        Arguments:
        o initial_db_info - A dictionary containing SeqDB databases that
        can be returned through the SeqDB retrieval functions. The
        dictionary has the following info:
        The keys are tuples of (name, version) and the values are
        dictionaries which return SeqRecord objects. See the SeqDB
        documentation for more information about what the SeqRecord
        dictionaries must implement.

        The add_seq_db function can be used to add additional databases
        to those initially specified.
        """
        CorbaUnknown.__init__(self)
        self._db_info = initial_db_info
        self._it_factory = SeqIteratorFactory()
        
    # --- corba functions
    def get_PrimarySeqIterator_from_file(self, format, filename):
        """Create a PrimarySeqIteratory interface object from the passed file.

        Parses the file with the appropriate parser and returns an iterator
        object which can be used to walk over the elements of the file.

        This determines the file type based on the passed format and
        attempts to call the correct reader. If the format is '' or None,
        then we attempt to guess the file based on the extension.
        Currently supported extensions and file types are:
        * '.fasta' - FASTA formatted files
        """
        try:
            record_it = self._it_factory.get_iterator(filename, format)
            pseq_it = CorbaPrimarySeqIterator(record_it)
            return pseq_it.get_object()
        except IOError, msg:
            raise seqcore.UnableToProcess(msg)

    def PrimarySeq_from_file(self, format, filename):
        """Create a PrimarySeq interface object from the passed file.

        Parses the file with an appropriate parser (based on the file type)
        and returns a primary sequence object (no features)
        for the first element of the file.

        This determines the file type based on the passed format and
        attempts to call the correct reader. If the format is '' or None,
        then we attempt to guess the file based on the extension.
        Currently supported extensions and file types are:
        * '.fasta' - FASTA formatted files

        Exceptions:
        * File not found
        * File extension/type not recognized.
        """
        try:
            record_it = self._it_factory.get_iterator(filename, format)
        except IOError, msg:
            raise seqcore.UnableToProcess(msg)

        # return the first sequence in the file
        next_seqrec = file_reader.next()

        # get the PrimarySeq implementation and return it
        pseq_obj = CorbaPrimarySeq(next_seqrec)
        return pseq_obj.get_object()

    def get_Seq_from_file(self, format, filename):
        """Create a Seq interface object from the passed file.
        """
        try:
            record_it = self._it_factory.get_iterator(filename, format)
        except IOError, msg:
            raise seqcore.UnableToProcess(msg)

        # return the first sequence in the file
        next_seqrec = file_reader.next()

        # get the sequence implementation and return it
        seq_obj = CorbaSeq(next_seqrec)
        return seq_obj.get_object()

    def get_SeqDB_names(self):
        seqdb_names = []
        for stored_dbs in self._db_info.keys():
            # if the name of the database is unique, add it to the list
            # of seqdb_names
            if stored_dbs[0] not in seqdb_names:
                seqdb_names.append(stored_dbs[0])

        return seqdb_names
                
    def get_SeqDB_versions(self, name):
        seqdb_versions = []
        for stored_dbs in self._db_info.keys():
            # if the db name matches the name we are looking for
            # append the version
            if stored_dbs[0] == name:
                seqdb_versions.append(int(stored_dbs[1]))

        # if we don't have anything to return, the passed name is bad
        if len(seqdb_versions) == 0:
            raise seqcore.DoesNotExist("No database with name %s" % name)

        return seqdb_versions

    def get_SeqDB_by_name(self, db_name, version):
        """Get a SeqDB object with the given name and version.
        """
        # if the version is zero, get the most recent version
        # this will raise a DoesNotExist error if there is no database.
        all_versions = self.get_SeqDB_versions(db_name)
        version = max(all_versions)
        
        try:
            # grab the dictionary, convert to a SeqDB and return
            seq_record_dict = self._db_info[(db_name, version)]
            seq_db = CorbaSeqDB(seq_record_dict, db_name, version)
            return seq_db.get_object()
        # if we get a KeyError we don't have the specified object
        except KeyError:            
            raise seqcore.DoesNotExist("No database with name %s, version %s"
                                       % (db_name, version))

    # --- local functions for server implementors
    def add_seq_db(self, db_name, db_version, seqrecord_dict):
        """Convenience function to add a new database to the BioEnv databases.

        Arguments:
        o db_name - The name of the database.
        o db_version - The version of the database.
        o seqrecord_dict - A dictionary-like object that returns SeqRecord
        objects. See the SeqDB module documentation for more information
        about the structue of this dictionary.
        """
        # make sure the key is unique
        if self._db_info.has_key((db_name, int(db_version))):
            raise ValueError("Database key (%s, %s) already exists" %
                             (db_name, int(db_version)))
        # add the information
        self._db_info[(db_name, int(db_version))] = seqrecord_dict
            
        
