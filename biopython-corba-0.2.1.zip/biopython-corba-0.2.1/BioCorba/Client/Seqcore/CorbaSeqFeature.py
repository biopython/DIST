# Copyright 2000 by Brad Chapman.  All rights reserved.
# This code is part of the Biopython distribution and governed by its
# license.  Please see the LICENSE file that should have been included
# as part of this package.
"""Module dealing with SeqFeature objects

classes:
o CorbaSeqFeature
o CorbaSeqFeatureIterator
o CorbaSeqFeatureVector
"""
# client corba stub code
import BioCorba.org.biocorba.seqcore

# local stuff
from BioCorba.Client.GnomeMemory.CorbaUnknown import CorbaUnknown
from CorbaPrimarySeq import CorbaPrimarySeq
from BioCorba.Client.Seqcore import CorbaExceptions

# Biopython
from Bio import SeqFeature

class CorbaSeqFeature(CorbaUnknown):
    def __init__(self, corba_object):
        """Confirm the SeqFeature object and setup the local implementation.

        Arguments:
        o corba_object - A reference to a remote SeqFeature object.
        """
        CorbaUnknown.__init__(self, corba_object)
        assert corba_object is not None, "Nil object reference."
    
        self._object = self._safe_narrow(corba_object,
                         BioCorba.org.biocorba.seqcore.SeqFeature)
        assert self._object is not None, "Could not narrow to SeqFeature."

    def type(self):
        return self._object.type()

    def source(self):
        return self._object.source()

    def seq_primary_id(self):
        return self._object.seq_primary_id()

    def start(self):
        return self._object.start()

    def end(self):
        return self._object.end()

    def strand(self):
        return self._object.strand()

    def qualifiers(self):
        name_value_list = self._object.qualifiers()

        # convert the name value list to an equivalent python dictionary
        qual_dict = {}
        all_names = []

        for name_value in name_value_list:
            qual_dict[name_value.name] = name_value.values
            all_names.append(name_value.name)

        # make sure we are properly getting all of the name and values
        assert len(qual_dict.keys()) == len(all_names), \
               "Lost qualifier names. From %s to %s" % (all_names,
                                                        qual_dict.keys())

        return qual_dict
        
    def sub_SeqFeatures(self, is_recursive = 1):        
        seqfeat_vector = self._object.sub_SeqFeatures(is_recursive)
        return CorbaSeqFeatureVector(seqfeat_vector)

    def _position_class(self, type_code):
        """Return a position class for a specific BioCorba FuzzyTypeCode.

        This maps the FuzzyTypeCodes of BioCorba to the Biopython
        position classes which represent the same information. This
        allows us to take care of fuzzy representations of locations.
        """
        if type_code == 1:
            return SeqFeature.ExactPosition
        elif type_code == 2:
            return SeqFeature.WithinPosition
        elif type_code == 3:
            return SeqFeature.BetweenPosition
        elif type_code == 4:
            return SeqFeature.BeforePosition
        elif type_code == 5:
            return SeqFeature.AfterPosition
        else:
            return ValueError("Unexpected FuzzyTypeCode value %s" % type_code)

    def _get_position(self, pos_class, position, extension):
        """Get the position object for a given class and position information.

        This handles checking for bad arguments (non-zero extensions where
        we shouldn't have any) and raises an error in these situations.
        """
        try:
            return pos_class(position, extension)
        except AttributeError:
            raise ValueError("Non-zero extension %s not accepted by %s"
                             % (extension, pos_class))
        
    def locations(self):
        """Retrieve the location of SeqFeatures on the Sequence.

        Instead of returning the BioCorba structs, this returns Biopython
        location objects specifying the (potentially fuzzy) locations of
        the features. The returned list is a 2D list:
        return_list[0] - A Biopython location object specifying the location.
        return_list[1] - The strand the location specifies. This is an
        integer with -1 = reverse; 1 = forward; 0 = either.
        """
        try:
            location_list = self._object.locations()
        except BioCorba.org.biocorba.seqcore.UnableToProcess, info:
            raise CorbaExceptions.UnableToProcess(info.reason)

        # convert the CORBA location structs into Biopython objects
        location_info = []
        for location in location_list:
            start_position_class = self._position_class(location.start.fuzzy)
            start_pos = self._get_position(start_position_class,
                                           location.start.position,
                                           location.start.extension)

            end_position_class = self._position_class(location.end.fuzzy)
            end_pos = self._get_position(end_position_class,
                                         location.end.position,
                                         location.end.extension)

            biopy_location = SeqFeature.FeatureLocation(start_pos, end_pos)

            location_info.append((biopy_location, location.strand))

        return location_info

    def PrimarySeq_is_available(self):
        return self._object.PrimarySeq_is_available()

    def get_PrimarySeq(self):
        try:
            pseq_obj = self._object.get_PrimarySeq()
        except BioCorba.org.biocorba.seqcore.UnableToProcess, msg:
            raise CorbaExceptions.UnableToProcess(msg.reason)

        return CorbaPrimarySeq(pseq_obj)

class CorbaSeqFeatureIterator(CorbaUnknown):
    def __init__(self, corba_object):
        """Confirm the SeqFeatureIterator and setup the local implementation.

        Arguments:
        o corba_object - A reference to a remote SeqFeatureIterator object.
        """
        CorbaUnknown.__init__(self, corba_object)
        assert corba_object is not None, "Nil object reference."
    
        self._object = self._safe_narrow(corba_object,
                         BioCorba.org.biocorba.seqcore.SeqFeatureIterator)
        assert self._object is not None, \
               "Could not narrow to SeqFeatureIterator."

    def next(self):
        try:
            next_feature = self._object.next()
        except BioCorba.org.biocorba.seqcore.EndOfStream:
            raise CorbaExceptions.EndOfStream
        
        return CorbaSeqFeature(next_feature)

    def has_more(self):
        return self._object.has_more()

class CorbaSeqFeatureVector(CorbaUnknown):
    """SeqFeatureVector interface

    Provide an interface to a vector of SeqFeature objects.
    """
    def __init__(self, corba_object):
        """Confirm the SeqFeatureVector and setup the local implementation.

        Arguments:
        o corba_object - A reference to a remote SeqFeatureVector object.
        """
        CorbaUnknown.__init__(self, corba_object)
        assert corba_object is not None, "Nil object reference."
    
        self._object = self._safe_narrow(corba_object,
                         BioCorba.org.biocorba.seqcore.SeqFeatureVector)
        assert self._object is not None, \
               "Could not narrow to SeqFeatureVector."

    def size(self):
        return self._object.size()

    def elementAt(self, index):
        try:
            sfeat_ref = self._object.elementAt(index)
        except BioCorba.org.biocorba.seqcore.OutOfRange, info:
            raise CorbaExceptions.OutOfRange(info.reason)

        return CorbaSeqFeature(sfeat_ref)

    def iterator(self):
        sfeatit_ref = self._object.iterator()

        return CorbaSeqFeatureIterator(sfeatit_ref)
