# Copyright 2000 by Brad Chapman.  All rights reserved.
# This code is part of the Biopython distribution and governed by its
# license.  Please see the LICENSE file that should have been included
# as part of this package.
"""Module dealing with Seq objects.

classes:
o CorbaSeq
o CorbaSeqDB
"""
# client corba stub code
import BioCorba.org.biocorba.seqcore

# local classes
from BioCorba.Client.GnomeMemory.CorbaUnknown import CorbaUnknown
from CorbaPrimarySeq import CorbaPrimarySeq
from CorbaPrimarySeq import CorbaPrimarySeqDB
from CorbaSeqFeature import CorbaSeqFeatureVector
from BioCorba.Client.Seqcore import CorbaExceptions

class CorbaSeq(CorbaPrimarySeq):
    """Seq interface

    This is the major interface specifying a biological sequence object.
    The object inherits from PrimarySeq (and thus AnonymousSeq) and therefore
    has their properties. In addition, the sequence may also have features.
    """
    def __init__(self, corba_object):
        """Confirm the Seq object and setup the local implementation.

        Arguments:
        o corba_object - A reference to a remote Seq object.
        """
        CorbaUnknown.__init__(self, corba_object)
        assert corba_object is not None, "Nil object reference."
    
        self._object = self._safe_narrow(corba_object, 
                         BioCorba.org.biocorba.seqcore.Seq)
        assert self._object is not None, "Could not narrow to Seq."
        
    def all_SeqFeatures(self, sub_seqfeatures = 1):
        assert (sub_seqfeatures == 0 or sub_seqfeatures == 1), \
               "Expected a boolean (0 or 1) value for sub_seqfeatures"
        
        feature_vector = self._object.all_SeqFeatures(sub_seqfeatures)
        return CorbaSeqFeatureVector(feature_vector)

    def get_SeqFeatures_by_type(self, sub_seqfeatures = 1, type = 'exon'):
        assert (sub_seqfeatures == 0 or sub_seqfeatures == 1), \
               "Expected a boolean (0 or 1) value for sub_seqfeatures"

        feature_vector = self._object.get_SeqFeatures_by_type(sub_seqfeatures,
                                                              type)
        return CorbaSeqFeatureVector(feature_vector)

    def get_SeqFeatures_in_region(self, start, end, sub_seqfeatures = 1):
        assert (sub_seqfeatures == 0 or sub_seqfeatures == 1), \
               "Expected a boolean (0 or 1) value for sub_seqfeatures"

        try:
            feature_vector = \
              self._object.get_SeqFeatures_in_region(start, end,
                                                     sub_seqfeatures)
        except BioCorba.org.biocorba.seqcore.OutOfRange, info:
            raise CorbaExceptions.OutOfRange(info.reason)

        return CorbaSeqFeatureVector(feature_vector)

    def get_SeqFeatures_in_region_by_type(self, start, end,
                                          sub_seqfeatures = 1, type = 'exon'):
        assert (sub_seqfeatures == 0 or sub_seqfeatures == 1), \
               "Expected a boolean (0 or 1) value for sub_seqfeatures"

        try:
            feature_vector = \
              self._object.get_SeqFeatures_in_region_by_type(start, end,
                                                             sub_seqfeatures,
                                                             type)
        except BioCorba.org.biocorba.seqcore.OutOfRange, info:
            raise CorbaExceptions.OutOfRange(info.reason)

        return CorbaSeqFeatureVector(feature_vector)

    def get_PrimarySeq(self):
        pseq_ref = self._object.get_PrimarySeq()

        return CorbaPrimarySeq(pseq_ref)

class CorbaSeqDB(CorbaPrimarySeqDB):
    def __init__(self, corba_object):
        """Confirm the SeqDB object and setup the local implementation.

        Arguments:
        o corba_object - A reference to a remote SeqDB object.
        """
        CorbaUnknown.__init__(self, corba_object)
        assert corba_object is not None, "Nil object reference."
    
        self._object = self._safe_narrow(corba_object,
                         BioCorba.org.biocorba.seqcore.SeqDB)
        assert self._object is not None, "Could not narrow to SeqDB."

    def get_Seq(self, primary_id, version = 0):
        try:
            seq_obj = self._object.get_Seq(primary_id, version)
        except BioCorba.org.biocorba.seqcore.DoesNotExist, info:
            raise CorbaExceptions.DoesNotExist(info.reason)
    
        return CorbaSeq(seq_obj)

    def accession_numbers(self):
        return self._object.accession_numbers()
