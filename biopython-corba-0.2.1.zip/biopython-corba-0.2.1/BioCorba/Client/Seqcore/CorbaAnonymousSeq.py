# Copyright 2000-2001 by Brad Chapman.  All rights reserved.
# This code is part of the Biopython distribution and governed by its
# license.  Please see the LICENSE file that should have been included
# as part of this package.
"""AnonymousSeq interface

Holds a sequence object representation with sequence information only (no
names or features on the sequence).
"""
# corba stubs
import BioCorba.org.biocorba.seqcore

# local classes
from BioCorba.Client.GnomeMemory.CorbaUnknown import CorbaUnknown
from BioCorba.Client import BiocorbaConnect
from BioCorba.Client.Seqcore import CorbaExceptions

class CorbaAnonymousSeq(CorbaUnknown):
    def __init__(self, corba_object):
        """Confirm the AnonymousSeq object and setup the local implementation.

        Arguments:
        o corba_object - A reference to a remote AnonymousSeq object.
        """
        CorbaUnknown.__init__(self, corba_object)
        
        assert corba_object is not None, "Nil object reference."
    
        self._object = self._safe_narrow(corba_object,
                         BioCorba.org.biocorba.seqcore.AnonymousSeq)
        assert self._object is not None, "Could not narrow to AnonymousSeq."

    def type(self):
        seq_type = self._object.type()

        if seq_type == BioCorba.org.biocorba.seqcore.SeqType.PROTEIN:
            return_type = 'PROTEIN'
        elif seq_type == BioCorba.org.biocorba.seqcore.SeqType.DNA:
            return_type = 'DNA'
        elif seq_type == BioCorba.org.biocorba.seqcore.SeqType.RNA:
            return_type = 'RNA'
        elif seq_type == BioCorba.org.biocorba.seqcore.SeqType.UNKNOWN:
            return_type = 'UNKNOWN'
        else:
            raise ValueError("Unexpected sequence type %s" % seq_type)

        return return_type

    def is_circular(self):
        return self._object.is_circular()

    def length(self):
        return self._object.length()

    def seq(self):
        try:
            return self._object.seq()
        except BioCorba.org.biocorba.seqcore.RequestTooLarge, info:
            raise CorbaExceptions.RequestTooLarge(info.reason,
                                                  info.suggested_size)

    def subseq(self, start, end):
        try:
            return self._object.subseq(start, end)
        except BioCorba.org.biocorba.seqcore.RequestTooLarge, info:
            raise CorbaExceptions.RequestTooLarge(info.reason,
                                                  info.suggested_size)
        except BioCorba.org.biocorba.seqcore.OutOfRange, info:
            raise CorbaExceptions.OutOfRange(info.reason)
