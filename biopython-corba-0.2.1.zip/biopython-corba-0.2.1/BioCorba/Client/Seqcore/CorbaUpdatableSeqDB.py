# Copyright 2000 by Brad Chapman.  All rights reserved.
# This code is part of the Biopython distribution and governed by its
# license.  Please see the LICENSE file that should have been included
# as part of this package.

# client corba stub classes
import BioCorba.org.biocorba.seqcore

# local classes
from BioCorba.Client.GnomeMemory.CorbaUnknown import CorbaUnknown
from CorbaSeqDB import CorbaSeqDB
from BioCorba.Client.Seqcore import CorbaExceptions

class CorbaUpdateableSeqDB(CorbaSeqDB):
    """UpdateableSeqDB interface.

    Represent a mutable biological sequence database where sequence objects
    can be updated.
    
    XXX Need to think of a way to implement this to make it easy for clients
    to define sequences to change. They shouldn't really have to pass CORBA
    objects, but I'm not sure how else to do it.
    """
    def __init__(self, corba_object):
        """Confirm the UpdateableSeqDB and setup the local implementation.

        Arguments:
        o corba_object - A reference to a remote UpdateableSeqDB object.
        """
        CorbaUnknown.__init__(self, corba_object)
        assert corba_object is not None, "Nil object reference."
    
        self._object = self._safe_narrow(corba_object, 
                         BioCorba.org.biocorba.seqcore.UpdateableSeqDB)
        assert self._object is not None, "Could not narrow to UpdateableSeqDB."

    def write_Seq(self, updated_seqs, added_seqs, dead_seqs):
        raise NotImplementedError
        
    def write_PrimarySeq(self, updated_seqs, added_seqs, dead_seqs):
        raise NotImplementedError
