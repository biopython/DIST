"""Local exceptions analagous to those raised in the BioCorba interface.

This module contains local equivalents of the different exceptions that
are defined in the BioCorba interface. This way, we can raise these
exceptions and people implementing clients don't need to deal with CORBA
exceptions.

See the biocorba idl file for more documentation about the conditions
that cause these exceptions to be raised.
"""
class RequestTooLarge(Exception):
    def __init__(self, reason, suggested_size):
        Exception.__init__(self, "Reason: %s; Suggested Size %s" %
                           (reason, suggested_size))
        
        self.reason = reason
        self.suggested_size = suggested_size

class OutOfRange(Exception):
    def __init__(self, reason):
        Exception.__init__(self, "Reason: %s" % reason)

        self.reason = reason

class EndOfStream(Exception):
    def __init__(self):
        Exception.__init__(self, "End of stream reached")

class NeedsUpdate(Exception):
    def __init__(self, reason):
        Exception.__init__(self,
                           "Reason: %s" % reason)

        self.reason = reason

class DoesNotExist(Exception):
    def __init__(self, reason):
        Exception.__init__(self,
                           "Reason: %s" % reason)

        self.reason = reason

class UnableToProcess(Exception):
    def __init__(self, reason):
        Exception.__init__(self, "Reason: %s" % reason)

        self.reason = reason
        
