"""Client interface to Ensembl CORBA VirtualContig objects.
"""
# client corba stub code
import BioCorba.org.ensembl

# BioCorba Client classes
from BioCorba.Client.GnomeMemory.CorbaUnknown import CorbaUnknown
from BioCorba.Client.Seqcore.CorbaSeq import CorbaSeq

# other Ensembl Client classes
from BioCorba.Client.Ensembl.Gene import CorbaGeneIterator

class CorbaVirtualContig(CorbaSeq):
    """VirtualContig interface.
    """
    def __init__(self, corba_object):
        """Confirm the VirtualContig object and set up a local implementation.
        """
        CorbaUnknown.__init__(self, corba_object)
        
        assert corba_object is not None, "Nil object reference."
    
        self._object = corba_object._narrow\
                       (BioCorba.org.ensembl.VirtualContig)
        assert self._object is not None, "Could not narrow to VirtualContig."

    def get_GeneIterator(self):
        remote_iterator = self._object.get_GeneIterator()

        return CorbaGeneIterator(remote_iterator)

class CorbaVirtualContigFactory:
    """VirtualContigFactory interface.
    """
    def __init__(self, corba_object):
        """Confirm the VirtualContigFactory object; set up local implementation
        """
        assert corba_object is not None, "Nil object reference."
    
        self._object = corba_object._narrow\
                       (BioCorba.org.ensembl.VirtualContigFactory)
        assert self._object is not None, \
               "Could not narrow to VirtualContigFactory."

    def fetch_VirtualContig_by_chr_start_end(self, chromosome, start, end):
        remote_contig = \
          self._object.fetch_VirtualContig_by_chr_start_end(chromosome,
                                                            start, end)

        return CorbaVirtualContig(remote_contig)

    def fetch_VirtualContig_by_chr(self, chromosome):
        remote_contig = self._object.fetch_VirtualContig_by_chr(chromosome)

        return CorbaVirtualContig(remote_contig)

    def list_all_chr(self):
        return self._object.list_all_chr()

    def length_of_chr(self, chromosome):
        return self._object.length_of_chr(chromosome)
