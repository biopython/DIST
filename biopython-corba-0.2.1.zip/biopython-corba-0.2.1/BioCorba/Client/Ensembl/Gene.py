"""Client interface to Ensembl Gene objects.
"""
# client corba stub code
import BioCorba.org.ensembl

# Biocorba classes
from BioCorba.Client.GnomeMemory.CorbaUnknown import CorbaUnknown
from BioCorba.Client.Seqcore import CorbaExceptions

# other Ensembl client code
from BioCorba.Client.Ensembl.Exon import CorbaExon
from BioCorba.Client.Ensembl.Transcript import CorbaTranscript

class CorbaGene(CorbaUnknown):
    """Gene interface.
    """
    def __init__(self, corba_object):
        """Confirm the Gene object and set up the local implementation.
        """
        CorbaUnknown.__init__(self, corba_object)

        assert corba_object is not None, "Nil object reference."
    
        self._object = corba_object._narrow\
                       (BioCorba.org.ensembl.Gene)
        assert self._object is not None, "Could not narrow to Gene."

    def id(self):
        return self._object.id()

    def version(self):
        return self._object.version()

    def transcripts(self):
        # get the CORBA objects
        corba_transcripts = self._object.transcripts()

        # convert them into local implementation and verify the interfaces
        local_transcripts = []
        for corba_tc in corba_transcripts:
            local_tc = CorbaTranscript(corba_tc)

            local_transcripts.append(local_tc)

        return local_transcripts

    def unique_Exons(self):
        # get the CORBA objects
        corba_exons = self._object.unique_Exons()

        # convert them into local implementation and verify the interfaces
        local_exons = []
        for corba_exon in corba_exons:
            local_exon = CorbaExon(corba_exon)

            local_exons.append(local_exon)

        return local_exons

class CorbaGeneIterator(CorbaUnknown):
    """GeneIterator interface.
    """
    def __init__(self, corba_object):
        """Confirm the GeneIterator object and set up the local implementation.
        """
        CorbaUnknown.__init__(self, corba_object)

        assert corba_object is not None, "Nil object reference."
    
        self._object = corba_object._narrow\
                       (BioCorba.org.ensembl.GeneIterator)
        assert self._object is not None, "Could not narrow to GeneIterator."

    def next(self):
        try:
            remote_gene = self._object.next()
        except BioCorba.org.biocorba.seqcore.EndOfStream:
            raise CorbaExtensions.EndOfStream

        return CorbaGene(remote_gene)

    def has_more(self):
        return self._object.has_more()

class CorbaGeneFactory:
    """GeneFactory interface.
    """
    def __init__(self, corba_object):
        """Confirm the GeneFactory object and set up the local implementation.
        """
        assert corba_object is not None, "Nil object reference."
    
        self._object = corba_object._narrow\
                       (BioCorba.org.ensembl.GeneFactory)
        assert self._object is not None, "Could not narrow to GeneFactory."

    def fetch_Gene_by_id(self, id):
        remote_gene = self._object.fetch_Gene_by_id(id)

        return CorbaGene(remote_gene)

    def fetch_GeneIterator(self):
        remote_iterator = self._object.fetch_GeneIterator()

        return CorbaGeneIterator(remote_iterator)

    def list_all_Gene_ids(self):
        return self._object.list_all_Gene_ids()
    
            
