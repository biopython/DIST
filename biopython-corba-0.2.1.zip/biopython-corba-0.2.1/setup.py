#!/usr/bin/env python
"""Setup script for python implementation of BioCorba.
"""
# standard modules
import os
import sys
import shutil

# distutils stuff
try:
    from distutils.core import setup
    from distutils.command.build import build
    from distutils.command.install import install
except ImportError:
    print "biopython-corba installation requires distutils, avaiable with "
    print "python 2.0 or from:"
    print "http://python.org/sigs/distutils-sig/download.html"
    sys.exit(0)

# local stuff
from BioCorba.biocorbaconfig import *
from build_helper import *

# --- constants
BIOCORBA_IDL_FILE = "biocorba.idl"
ENSEMBL_IDL_FILE = "ensembl.idl"

IDL_FILES = [BIOCORBA_IDL_FILE, ENSEMBL_IDL_FILE]

# Determine which packages we need to install based on the biocorbaconfig.py
# configuration file.

# basic stuff you need for both omniORB and Fnorb
basic = ['BioCorba',
         'BioCorba/Adapters',
         'BioCorba/Bio',
         'BioCorba/Bio/Fasta',
         'BioCorba/Bio/GenBank',
         'BioCorba/Client',
         'BioCorba/Client/GnomeMemory',
         'BioCorba/Client/Seqcore',
         'BioCorba/Client/Ensembl',
         'BioCorba/Server',
         'BioCorba/Server/GnomeMemory',
         'BioCorba/Server/Seqcore']

# idl generated stubs and skeletons which need to be installed
corba_pkgs = []
# --- BioCorba base stuff
if 'biocorba' in supported_interfaces:
    corba_pkgs += ['BioCorba/org',
                   'BioCorba/org/biocorba',
                   'BioCorba/org/biocorba/seqcore',
                   'BioCorba/org__POA',
                   'BioCorba/org__POA/biocorba',
                   'BioCorba/org__POA/biocorba/seqcore',
                   'BioCorba/GNOME',
                   'BioCorba/GNOME__POA']

    # extra corba stuff that we need for Fnorb to make it act like it
    # obeys the standard python CORBA interface
    if orb_implementation == 'Fnorb':
        corba_pkgs = corba_pkgs + \
                     ['BioCorba/org_skel',
                      'BioCorba/org_skel/biocorba_skel',
                      'BioCorba/org_skel/biocorba_skel/seqcore_skel',
                      'BioCorba/GNOME_skel']

# -- ensembl
if 'ensembl' in supported_interfaces:
    corba_pkgs += ['BioCorba/org/ensembl',
                   'BioCorba/org__POA/ensembl']

    if orb_implementation == 'Fnorb':
        corba_pkgs = corba_pkgs + \
                     ['BioCorba/org_skel/ensembl_skel']

# build up the list of packages to install
install_pkgs = []
install_pkgs = basic + corba_pkgs

class my_build(build):
    """Override the standard build to compile idl files.
    """
    def run(self):
        # run the right idl compiler depending on the orb being used
        if 'biocorba' in supported_interfaces:
            if orb_implementation == 'omniORB':
                generate_omniorb_stubs(BIOCORBA_IDL_FILE)
            elif orb_implementation == 'Fnorb':
                generate_fnorb_stubs(BIOCORBA_IDL_FILE)
            elif orb_implementation == 'ORBit':
                generate_orbit_stubs(BIOCORBA_IDL_FILE)
        if 'ensembl' in supported_interfaces:
            if orb_implementation == 'omniORB':
                generate_omniorb_stubs(ENSEMBL_IDL_FILE, remove_old = 0)
            elif orb_implementation == 'Fnorb':
                generate_fnorb_stubs(ENSEMBL_IDL_FILE, remove_old = 0)
            elif orb_implementation == 'ORBit':
                generate_orbit_stubs(ENSEMBL_IDL_FILE, remove_old = 0)
                
        build.run(self)

class my_install(install):
    """Override the default install to copy over the IDL files.

    This is probably an awful abuse of distutils, but I can't figure out
    a better way right now to make the IDL files availabe so that
    ORBit-python can use them.
    """
    def run(self):
        install.run(self)
        idl_dir = os.path.join(self.install_purelib, 'BioCorba')

        for idl_file in IDL_FILES:
            shutil.copy(os.path.join('BioCorba', idl_file), idl_dir)

setup (name = "biopython-corba",
       version = "0.2.1",
       description = "Python implementation of the BioCorba interfaces",
       author = "The Biopython Consortium",
       author_email = "biopython@biopython.org",
       url = "http://www.biopython.org",

       cmdclass = {'build': my_build, 'install': my_install},
       packages = install_pkgs)
