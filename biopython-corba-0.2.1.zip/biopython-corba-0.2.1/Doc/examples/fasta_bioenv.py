#!/usr/bin/env python
"""Demonstrating how to load a Fasta iterator using the BioEnv interface.

This utilizes the Bio-like interface to make working with BioCorba objects
be similar to working with standard Biopython objects.
"""
# first load up the BioEnv object
from BioCorba.Client.BiocorbaConnect import GenericCorbaClient
from BioCorba.Client.Seqcore.CorbaBioEnv import CorbaBioEnv

server_retriever = GenericCorbaClient(CorbaBioEnv)
bioenv_server = server_retriever.from_file_ior("/tmp/my_server.ior")

# now load up the Fasta object using this bioenv_server
from BioCorba.Bio import Fasta

import os

FASTA_FILE = os.path.join(os.getcwd(), "a_drought.fasta")

seq_parser = Fasta.SequenceParser()
fasta_iterator = Fasta.iterator_from_bioenv(bioenv_server, FASTA_FILE,
                                            seq_parser)

import string

SEARCH_STRING = "CAGAATG"

print "Searching for %s..." % SEARCH_STRING

while 1:
    seq_record = fasta_iterator.next()

    if seq_record is None:
        break
    
    my_seq = seq_record.seq
    location = string.find(string.upper(my_seq.data), SEARCH_STRING)
    if location != -1:
        print 'Id:', seq_record.description

        
