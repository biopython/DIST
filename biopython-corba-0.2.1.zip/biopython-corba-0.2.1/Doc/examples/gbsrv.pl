#!/usr/bin/env perl
"""Bioperl-corba GenBank server for Tutorial demonstration.

XXX This isn't updated yet to the 0.2 version!
"""

# biocorba modules
use Bio::CorbaServer::SeqDB;

# bioperl modules
use Bio::Index::GenBank;
use Bio::Index::EMBL;

# --- Make an index file that will serve as the database
my $dir = `pwd`;
chomp($dir);

my $gb_file = "$dir/a_drought.gb";
#my $gb_file = "$dir/a_drought.swiss";

my $index_file = "$dir/gb_index.dbm";

#my $ind = Bio::Index::EMBL->new(-filename => $index_file, 
#				 -write_flag => 1, 
#				 -verbose => 1);

my $ind = Bio::Index::GenBank->new($index_file, 'WRITE');

#my $ind = Bio::Index::EMBL->new($index_file, 'WRITE');

$ind->make_index($gb_file);
# make sure we are done before doing ahead
$ind = undef;

# --- Initialize the CORBA ORB and get the Portable Object Adapter (POA)

# CORBA::ORBit doesn't use a idl compiler, and instead imports the idl file
# containing the interfaces.
use CORBA::ORBit idl => [ 'biocorba.idl' ];

$orb = CORBA::ORB_init("orbit-local-orb");
$root_poa = $orb->resolve_initial_references("RootPOA");


# --- Load up a GenBank index object to server as the database

#my $gb_database = Bio::Index::EMBL->new(-filename => $index_file, 
#                     -write_flag => 0,
#					 -verbose => 1);

my $gb_database = Bio::Index::GenBank->new($index_file);
#my $gb_database = Bio::Index::EMBL->new($index_file);

# --- Feed the GenBank object into Biocorba to get a biocorba object

$servant = Bio::CorbaServer::SeqDB->new($root_poa, 'gb_db', $gb_database);

my $servant_id = $root_poa->activate_object($servant);

# --- Publish a stringified IOR so that another computer can get it
$object_id = $root_poa->id_to_reference($servant_id);
my $string_ior = $orb->object_to_string($object_id);

$ior_file = "/var/ftp/pub/my_gb_db.ior";
open (OUT, ">$ior_file") || die "Cannot open file for ior: $!";
print OUT "$string_ior";
close OUT;

# tell everyone we are ready for it
print STDERR "Activating the ORB. IOR written to $ior_file\n";

# --- Start the orb running to wait for requests

$root_poa->_get_the_POAManager->activate;
$orb->run;








