#!/usr/bin/env python
"""Demonstration genbank client for the Tutorial.

XXX This is not yet updated to Biocorba-0.2 since the bioperl-corba stuff
isn't ready yet.
"""
# Biocorba modules
from BioCorba.Biopython.Client.Seqcore import CorbaSeqDB

IOR_URL = "ftp://24.9.210.117/pub/my_gb_db.ior"

# --- Get the server object and initialize all of the necessary corba stuff
gb_server = CorbaSeqDB.from_url(IOR_URL, 'perl')

# --- Call methods on the object you have, just as if it was local. 

# get the ids available in the sequence database
primary_ids = gb_server.get_primaryidList()

print 'primary_ids', primary_ids

#for id in primary_ids:
#	seq = gb_server.get_Seq(id)

my_seq = gb_server.get_Seq('U73781')

print my_seq.get_seq()

print my_seq.type()

print my_seq.all_features()

iterator = my_seq.all_features_iterator()

feature_one = iterator.next()

quals = feature_one.qualifiers()

print quals


	









