#!/usr/bin/env python
"""Demonstrate how to set up a PrimarySeqIterator server using Biopython.

This sets up an iterator over a fasta file, and makes it available via
BioCorba.
"""
# get the biopython Fasta iterator, which will do all of the underlying work
from Bio import Fasta
from Bio.Alphabet import IUPAC

import os
FASTA_FILE = os.path.join(os.getcwd(), "a_drought.fasta")
fasta_handle = open(FASTA_FILE, 'r')

seq_parser = Fasta.SequenceParser(alphabet = IUPAC.unambiguous_dna)
fasta_iterator = Fasta.Iterator(fasta_handle, seq_parser)

# now create the BioCorba PrimarySeqIterator
from BioCorba.Server.Seqcore.Iterator import CorbaPrimarySeqIterator

pseq_server = CorbaPrimarySeqIterator(fasta_iterator)
pseq_server.string_ior_to_file("/tmp/my_server.ior")
  
print "Server is up and running..."
pseq_server.run()
