#!/usr/bin/env python
"""Demo client that shows getting different CORBA types through python.
"""
# standard modules
import urllib

# omniORB
from omniORB import CORBA

# generated stubs
import idl_demo

# First grab the sting IOR
IDL_DEMO_URL = "http://industry.ebi.ac.uk/~alan/IOR/" + \
              "idl_demo.DemoFactory.ior"

ior_handle = urllib.urlopen(IDL_DEMO_URL)
idl_demo_ior = ior_handle.read()
ior_handle.close()

# Now start up the ORB and get the server
orb = CORBA.ORB_init([], CORBA.ORB_ID)
demo_factory = orb.string_to_object(idl_demo_ior)

# --- BasicDataTypes demo
print "BasicDataTypes demo:"

# get a reference to the BasicTypes object from the factory
basic_types = demo_factory.get_basic_data_types_demo()

# now get all of the different types
print "An IDL short:", basic_types.get_short()
print "An IDL long:", basic_types.get_long()
print "An IDL longlong:", basic_types.get_longlong()
print "An IDL char:", basic_types.get_char()

# wide chars aren't supported by python ORBs yet
# print "An IDL wchar:", basic_types.get_wchar()

print "An IDL string:", basic_types.get_string()
print "An IDL boolean (true):", basic_types.get_true()
print "An IDL boolean (false):", basic_types.get_false()

# --- Constants demo
print "\nConstants demo:"

# constants inside an interface are available as class variables of the
# Constants class, so we do not need a reference to a class object
# to get a constant
print "PI is:", idl_demo.Constants.PI
print "ZERO is:", idl_demo.Constants.ZERO

# --- enum demo
print "\nenum demo:"

# get a reference to the MultipleChoice object from the factory
multiple_choice = demo_factory.get_enum_demo()

# get back 5 different enum objects by calling get_answer on 5 different
# question numbers
for question_number in range(1, 6):
    answer = multiple_choice.get_answer(question_number)
    print "The answer to question number %s is %s" % (question_number, answer)

# --- struct demo
print "\nstruct demo:"

# get a reference to the TestStruct object from the factory
test_struct = demo_factory.get_struct_demo()

# send data to the TestStruct object, and we'll get back a struct with the
# given info
personal_info = test_struct.get_struct(2, 0.80, "Mary")

# the returned "struct" is a python class with the items as attributes
# of the class
print "Name is:", personal_info.name
print "Height is:", personal_info.height
print "Age is:", personal_info.age

# --- Collections demo
print "\nCollections demo:"

# get a reference to the Collections object from the factory
collections = demo_factory.get_collection_demo()

# get the IDL sequence, which is returned as a python list
# (in this case, it is a list of doubles)
double_seq_list = collections.get_double_sequence()

# we can deal with this just like a regular ol' python list
print "Sequence length:", len(double_seq_list)

for item in double_seq_list:
    print "Item:", item

# get the IDL array, which also is returned as a python list
double_seq_array = collections.get_double_array()

print "Array length:", len(double_seq_array)

for item in double_seq_array:
    print "Item:", item
