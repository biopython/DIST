#!/usr/bin/env python
"""Demonstrate how to get a Fasta Iterator using a PrimarySeqIterator interface

This is similar to the 'fasta_bioenv.py' example, except that it resolves
an Iterator from a PrimarySeqIterator server instead of a BioEnv server.
"""
# first load up the PrimarySeqIterator
from BioCorba.Client.BiocorbaConnect import GenericCorbaClient
from BioCorba.Client.Seqcore.CorbaPrimarySeq import CorbaPrimarySeqIterator

server_retriever = GenericCorbaClient(CorbaPrimarySeqIterator)
pseqit_server = server_retriever.from_file_ior("/tmp/my_server.ior")

# now load up the Fasta object using this pseqit_server
from BioCorba.Bio import Fasta

seq_parser = Fasta.SequenceParser()
fasta_iterator = Fasta.Iterator(pseqit_server, seq_parser)

import string

SEARCH_STRING = "CAGAATG"

print "Searching for %s..." % SEARCH_STRING

while 1:
    seq_record = fasta_iterator.next()

    if seq_record is None:
        break
    
    my_seq = seq_record.seq
    location = string.find(string.upper(my_seq.data), SEARCH_STRING)
    if location != -1:
        print 'Id:', seq_record.description
    
    
