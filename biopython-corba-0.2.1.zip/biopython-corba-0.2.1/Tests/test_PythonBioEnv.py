#!/usr/bin/env python
"""Test the python implemented BioEnv server.

This tests the server which can be started by running
Scripts/bioenv_server.py. It gets the IOR for this server
from ../ior/bioenv.ior.
"""
# standard modules
import os
import sys

# PyUnit testing framework
import unittest

# local testing stuff
import InterfaceTests

# local modules
from BioCorba.Client.Seqcore.CorbaBioEnv import CorbaBioEnv
from BioCorba.Client.BiocorbaConnect import GenericCorbaClient

# --- constants
IOR_FILE = os.path.join(os.getcwd(), os.pardir, 'ior', 'bioenv.ior')

# get the bioenv server
print "Retrieving BioEnv server..."
server_retriever = GenericCorbaClient(CorbaBioEnv)
bioenv_server = server_retriever.from_file_ior(IOR_FILE)

# test out the databases
# all_test_dbs = [('opuntia_fasta', ('AF191665', 'AF191659'))]
# all_test_dbs = [('cor_genbank', ('X62281', 'X55053'))]

all_test_dbs = [('opuntia_fasta', ('AF191659',)),
                ('cor_genbank', ('X62281',))]

for test_info in all_test_dbs:
    print "Running tests on %s..." % test_info[0]

    try:
        seq_db = bioenv_server.get_SeqDB_by_name(test_info[0])
    # we will get a CORBA.COMM_FAILURE here if the server is not started
    except:
        print "You must start up the bioenv_server in the Scripts"
        print "directory, by running 'python bioenv_server.py"
        sys.exit()
    # now test the accession numbers we are interested in
    for acc_num in test_info[1]:
        test_suite = unittest.makeSuite(InterfaceTests.SeqDBPrint, 't_',
                                        args = [seq_db, acc_num])
        runner = unittest.NoTimeTextTestRunner(sys.stdout)
        runner.run(test_suite)


