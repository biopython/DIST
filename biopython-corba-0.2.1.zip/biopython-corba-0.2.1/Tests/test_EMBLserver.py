#!/usr/bin/env python
"""Test against the EMBL BioCorba server.

This tests clients against Alan Robinson's BioCorba EMBL server. Docs
and code for this server can be found at:

http://industry.ebi.ac.uk/~alan/BioCorba-0.2.0/
"""
# standard mdoules
import sys

# PyUnit testing framework
import unittest

# local testing stuff
import InterfaceTests

# local modules
from BioCorba.Client.Seqcore.CorbaBioEnv import CorbaBioEnv
from BioCorba.Client.BiocorbaConnect import GenericCorbaClient

# XXX Don't do any testing at all right now since EMBL is broken
# raise SystemExit("EMBL locks up on the test right now. Sorry.")

# --- constants
IOR_DIR = "http://industry.ebi.ac.uk/~alan/IOR/"
IOR_NAME = "org.biocorba.seqcore.BioEnvPOAImpl-Biocorba-0.2.ior"
IOR_URL = IOR_DIR + IOR_NAME

EMBL_NAME = "EMBL-BANK"
ACC_NUMS = ['X55053', 'M81224']
ACC_NUMS = ['X55053']

# get the BioEnv object
print "Retrieving BioEnv server..."
server_retriever = GenericCorbaClient(CorbaBioEnv)
bioenv_server = server_retriever.from_url_ior(IOR_URL)

# get our Sequence DB
print "Getting the EMBL database..."
db_names = bioenv_server.get_SeqDB_names()
assert EMBL_NAME in db_names, "Database name %s is not valid: %s" \
       % (EMBL_NAME, db_names)

seq_db = bioenv_server.get_SeqDB_by_name(EMBL_NAME)


# now test out our SeqDB for all of the specified accession numbers
for acc_num in ACC_NUMS:
    test_suite = unittest.makeSuite(InterfaceTests.SeqDBPrint, 't_',
                                    args = [seq_db, acc_num])
    runner = unittest.NoTimeTextTestRunner(sys.stdout)
    runner.run(test_suite)
