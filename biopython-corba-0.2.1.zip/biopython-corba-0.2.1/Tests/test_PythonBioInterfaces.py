#!/usr/bin/env python
"""Test the Bio-like interfaces to BioCorba using the python BioEnv server.

To test the interfaces, you need to start the BioEnv server in
Scripts/bioenv_server.py.

The IOR for this server will be retrieved from ../ior/bioenv.ior.
"""
# standard modules
import os
import sys

# PyUnit testing framework
import unittest

# local modules
from BioCorba.Client.Seqcore.CorbaBioEnv import CorbaBioEnv
from BioCorba.Client.BiocorbaConnect import GenericCorbaClient

# bio-interface
from BioCorba.Bio import Fasta
from BioCorba.Bio import GenBank

# --- constants
IOR_FILE = os.path.join(os.getcwd(), os.pardir, 'ior', 'bioenv.ior')
IT_TEST_FILE = os.path.join(os.getcwd(), 'files', 'saccharum.fasta')

# set up a Retriever to resolve references to servers
server_retriever = GenericCorbaClient(CorbaBioEnv)

# --- first set up the UnitTests we are going to be running
# Dictionary tests
class GenericDictionaryTest(unittest.TestCase):
    """Provide useful functions for testing a Dictionary.
    """
    def setUp(self):
        raise NotImplementedError("Subclasses must define")

    def t_len(self):
        print "Length:", len(self.test_dict)

    def t_getattr(self):
        try:
            getattr(self.test_dict, 'random')
            raise "Got here and didn't expect to!"
        except NotImplementedError:
            print "Expected and got a NotImplementedError"

    def t_keys(self):
        print "Keys:", self.test_dict.keys()

    def t_getitem(self):
        # test retrieving a real item
        for key in self.test_dict.keys():
            key_item = self.test_dict[key]
            print "Successfully retrieved key %s" % key

        # test the key error on a fake item
        try:
            self.test_dict["fake_key"]
            raise "Got here and didn't expect to!"
        except KeyError:
            print "Expected and got a KeyError"

class GenBankDictionaryTest(GenericDictionaryTest):
    """Test the GenBank dictionary interface.
    """
    def setUp(self):
        # print "Retrieving BioEnv server..."
        bioenv_server = server_retriever.from_file_ior(IOR_FILE)

        # print "Setting up a GenBank dictionary..."
        feat_parser = GenBank.FeatureParser()
        self.test_dict = GenBank.dictionary_from_bioenv(bioenv_server,
                                                        'cor_genbank',
                                                        parser = feat_parser)

class FastaDictionaryTest(GenericDictionaryTest):
    """Test the Fasta dictionary interface
    """
    def setUp(self):
        # print "Retrieving BioEnv server..."
        bioenv_server = server_retriever.from_file_ior(IOR_FILE)

        # print "Setting up a Fasta Dictionary..."
        seq_parser = Fasta.SequenceParser()
        self.test_dict = Fasta.dictionary_from_bioenv(bioenv_server,
                                                      'opuntia_fasta',
                                                      parser = seq_parser)

# Iterator Tests
class FastaIteratorTest(unittest.TestCase):
    """Test the Bio.Fasta Iterator interface.
    """
    def setUp(self):
        # print "Retrieving BioEnv server..."
        bioenv_server = server_retriever.from_file_ior(IOR_FILE)

        seq_parser = Fasta.SequenceParser()
        self.test_it = Fasta.iterator_from_bioenv(bioenv_server, IT_TEST_FILE,
                                                  parser = seq_parser)

    def t_next(self):
        while 1:
            cur_record = self.test_it.next()

            if cur_record is None:
                break

            print "Successfully retrieved the record %s" % cur_record.name

        print "Exited loop successfully..."

# SeqRecord and Seq Tests
class SeqRecordTest(unittest.TestCase):
    """Test the SeqRecord, Seq and SeqFeature interfaces.
    """
    def setUp(self):
        # print "Retrieving BioEnv server..."
        bioenv_server = server_retriever.from_file_ior(IOR_FILE)

        # print "Setting up a GenBank dictionary..."
        feat_parser = GenBank.FeatureParser()
        test_dict = GenBank.dictionary_from_bioenv(bioenv_server,
                                                   'cor_genbank',
                                                   parser = feat_parser)

        # print "Getting a SeqRecord to test from..."
        self.test_record = test_dict['X62281']

        # print "Getting the Seq to test from..."
        self.test_seq = self.test_record.seq

        # print "Getting the SeqFeature to test from..."
        self.test_feature = self.test_record.features[4]

    # --- SeqRecord tests

    def t_seqrecord_name(self):
        print "SeqRecord.name:", self.test_record.name

    def t_seqrecord_id(self):
        print "SeqRecord.id:", self.test_record.id

    def t_seqrecord_description(self):
        print "SeqRecord.description:", self.test_record.description

    # --- Seq tests

    def t_seq_alphabet(self):
        print "Seq.alphabet:", self.test_seq.alphabet

    def t_seq_len(self):
        print "Seq.len:", len(self.test_seq)

    def t_seq_slice(self):
        print "Seq.slice"
        print "seq[5:]:", self.test_seq[5:]
        print "seq[:5]:", self.test_seq[:5]
        print "seq[3:5]:", self.test_seq[3:5]

    def t_seq_tostring(self):
        print "Seq.tostring:", self.test_seq.tostring()

    def t_seq_data(self):
        print "Seq.data:", self.test_seq.data

    # --- SeqFeature tests
    def t_seqfeat_location(self):
        print "SeqFeature.location:", self.test_feature.location

    def t_seqfeat_type(self):
        print "SeqFeature.type:", self.test_feature.type

    def t_seqfeat_strand(self):
        print "SeqFeature.strand:", self.test_feature.strand

    def t_seqfeat_qualifiers(self):
        print "SeqFeature.qualfiers:", self.test_feature.qualifiers

    def t_seqfeat_sub_features(self):
        print "SeqFeature.subfeatures"
        for sub_feat in self.test_feature.sub_features:
            print "Got subfeature of type %s at location %s" \
                  % (sub_feat.type, sub_feat.location)
        
# now run all of the tests
all_tests = [GenBankDictionaryTest, FastaDictionaryTest, FastaIteratorTest,
             SeqRecordTest]

for cur_test in all_tests:
    test_suite = unittest.makeSuite(cur_test, 't_')
    runner = unittest.NoTimeTextTestRunner(sys.stdout)
    runner.run(test_suite)


