"""Groups of reusable tests for specific interfaces.

This module contains tests for specific BioCorba interfaces that test all
of the functions of the interfaces. These classes can be imported and used
in tests for specific situations.

The tests use the PyUnit unit testing framework
http://pyunit.sourceforge.net/, to set up the tests.
"""
# standard modules
import sys

# PyUnit
import unittest

# local stuff
from BioCorba.Client.Seqcore import CorbaExceptions

class GnomeMemoryPrint(unittest.TestCase):
    """Test the GNOME memory management functions by printing.
    """
    def __init__(self, method, test_ob = None):
        unittest.TestCase.__init__(self, method)
        self._test_ob = test_ob

    def setUp(self):
        assert self._test_ob is not None, \
               "Need to pass in test_ob, or subclass and set _test_ob"

    # Gnome::Unknown tests don't really work right ... Need to figure
    # out a better way to test for these.
    
    #def t_ref(self):
    #    pass
        # print "Calling ref"
        # self._test_ob.ref()

    #def t_unref(self):
    #    pass
        # print "Calling unref"
        # self._test_ob.unref()

    #def t_query_interface(self):
    #    pass
        # print "Calling query_interface"
        # self._test_ob.query_interface('fake_id')

    # non-test functions which can be reused in test functions

    def test_PrimarySeq(self, cur_seq):
        """Test a PrimarySeq object.
        """
        assert cur_seq is not None, "Need to set cur_seq as a global object."

        # now test the sequence we get back
        test_suite = unittest.makeSuite(PrimarySeqPrint, 't_',
                                        args = [cur_seq])
        runner = unittest.NoTimeTextTestRunner(sys.stdout)
        runner.run(test_suite)

    def test_SeqFeature(self, cur_seq_feature):
        """Test a SeqFeature object,
        """
        assert cur_seq_feature is not None, \
               "Need to set cur_seq_feature as a global object."

        # test the feature we get back
        test_suite = unittest.makeSuite(SeqFeaturePrint, 't_',
                                        args = [cur_seq_feature])
        runner = unittest.NoTimeTextTestRunner(sys.stdout)
        runner.run(test_suite)

    def test_SeqFeatureVector(self, cur_vector):
        """Test a SeqFeatureVector object.
        """
        assert cur_vector is not None, "cur_vector must be global."

        # test the vector we get back
        test_suite = unittest.makeSuite(SeqFeatureVectorPrint, 't_',
                                        args = [cur_vector])
        runner = unittest.NoTimeTextTestRunner(sys.stdout)
        runner.run(test_suite)

class AnonymousSeqPrint(GnomeMemoryPrint):
    """Test AnonymousSeq by printing the information.
    """
    def __init__(self, method, test_ob):
        GnomeMemoryPrint.__init__(self, method, test_ob)
        
    def t_type(self):
        print "type:", self._test_ob.type()

    def t_is_circular(self):
        print "is_circular", self._test_ob.is_circular()

    def t_length(self):
        print "length:", self._test_ob.length()

    def t_seq(self):
        print "seq:", self._test_ob.seq()

    def t_subseq(self):
        seq_len = self._test_ob.length()
        first_subs = min(5, seq_len)
        second_subs = min(20, seq_len)
        print "subseq(%s, %s)" % (first_subs, second_subs), \
              self._test_ob.subseq(first_subs, second_subs)

class PrimarySeqPrint(AnonymousSeqPrint):
    """Test the PrimarySeq functions by printing the information.
    """
    def __init__(self, method, test_ob):
        AnonymousSeqPrint.__init__(self, method, test_ob)

    def t_display_id(self):
        print "display_id:", self._test_ob.display_id()

    def t_primary_id(self):
        print "primary_id", self._test_ob.primary_id()

    def t_accession_number(self):
        print "accession_number:", self._test_ob.accession_number()

    def t_version(self):
        print "version:", self._test_ob.version()

class SeqPrint(PrimarySeqPrint):
    """Test the Seq functions by printing information.
    """
    def __init__(self, method, test_ob):
        PrimarySeqPrint.__init__(self, method, test_ob)

    def setUp(self):
        PrimarySeqPrint.setUp(self)

        self.types_to_test = ['exon']
        self.regions_to_test = [(1, 20), (30, 60), (1, 200)]

    def t_all_SeqFeatures(self):
        cur_vector = self._test_ob.all_SeqFeatures(1)

        self.test_SeqFeatureVector(cur_vector)

    def t_get_SeqFeatures_by_type(self):
        for type_to_test in self.types_to_test:
            cur_vector = self._test_ob.get_SeqFeatures_by_type(1, type_to_test)

            self.test_SeqFeatureVector(cur_vector)

    def t_get_SeqFeatures_in_region(self):
        for region in self.regions_to_test:
            try:
                cur_vector = \
                  self._test_ob.get_SeqFeatures_in_region(region[0],
                                                          region[1], 1)
                self.test_SeqFeatureVector(cur_vector)
            except CorbaExceptions.OutOfRange:
                print "Out of range on %s" % str(region)

    def t_get_SeqFeatures_in_region_by_type(self):
        for region in self.regions_to_test:
            for type in self.types_to_test:
                try:
                    cur_vector = \
                     self._test_ob.get_SeqFeatures_in_region_by_type(region[0],
                                                                     region[1],
                                                                     1, type)
                    self.test_SeqFeatureVector(cur_vector)
                except CorbaExceptions.OutOfRange:
                    print "Out of Range on %s" % str(region)

    def t_get_PrimarySeq(self):
        cur_seq = self._test_ob.get_PrimarySeq()

        self.test_PrimarySeq(cur_seq)

class SeqFeaturePrint(GnomeMemoryPrint):
    """Test the SeqFeature functions by printing the results.
    """
    def __init__(self, method, test_ob):
        GnomeMemoryPrint.__init__(self, method, test_ob)

    def t_type(self):
        print "type:", self._test_ob.type()

    def t_source(self):
        print "source:", self._test_ob.source()

    def t_seq_primary_id(self):
        print "seq_primary_id:", self._test_ob.seq_primary_id()

    def t_start(self):
        print "start:", self._test_ob.start()

    def t_end(self):
        print "end:", self._test_ob.end()

    def t_strand(self):
        print "strand:", self._test_ob.strand()

    def t_qualifiers(self):
        print "qualifiers:", self._test_ob.qualifiers()

    def t_sub_SeqFeatures(self):
        # print "testing sub_SeqFeatures"
        # print "Skipping test..."
        global cur_vector
        cur_vector = self._test_ob.sub_SeqFeatures(1)
        self.test_SeqFeatureVector(cur_vector)

    def t_locations(self):
        print "locations:"
        all_locations = self._test_ob.locations()
        for location in all_locations:
            print "location: %s, strand: %s" % (location[0], location[1])

    def t_PrimarySeq_is_available(self):
        print "PrimarySeq is available:", \
              self._test_ob.PrimarySeq_is_available()

    def t_get_PrimarySeq(self):
        if self._test_ob.PrimarySeq_is_available():
            cur_seq = self._test_ob.get_PrimarySeq()
        
            self.test_PrimarySeq(cur_seq)

class PrimarySeqIteratorPrint(GnomeMemoryPrint):
    """Test the PrimarySeqIterator functions by printing results.
    """
    def __init__(self, method, test_ob):
        GnomeMemoryPrint.__init__(self, method, test_ob)

    def t_next(self):
        for n in range(1):
            try:
                cur_seq = self._test_ob.next()

                self.test_PrimarySeq(cur_seq)
            except CorbaExceptions.EndOfStream:
                print "Ran out of primary seqs"

    def t_has_more(self):
        print "has_more:", self._test_ob.has_more()

class SeqFeatureIteratorPrint(GnomeMemoryPrint):
    """Test the SeqFeatureIterator functions by printing.
    """
    def __init__(self, method, test_ob):
        GnomeMemoryPrint.__init__(self, method, test_ob)

    def t_next(self):
        for n in range(1):
            try:
                cur_seq_feature = self._test_ob.next()

                self.test_SeqFeature(cur_seq_feature)
            except CorbaExceptions.EndOfStream:
                print "Ran out of seq features"

    def t_has_more(self):
        print "has_more:", self._test_ob.has_more()

class SeqFeatureVectorPrint(GnomeMemoryPrint):
    """Test the SeqFeatureVector functions by printing.
    """
    def __init__(self, method, test_ob):
        GnomeMemoryPrint.__init__(self, method, test_ob)

    def t_size(self):
        print "size:", self._test_ob.size()

    def t_elementAt(self):
        subs = min(5, (self._test_ob.size() - 1))

        if subs > -1:
            print "testing elementAt on element %s" % subs

            cur_seq_feature = self._test_ob.elementAt(subs)
        
            self.test_SeqFeature(cur_seq_feature)
        else:
            print "Could not test elementAt -- vector length is zero"

    def t_iterator(self):
        cur_it = self._test_ob.iterator()

        # test the iterator we get back
        test_suite = unittest.makeSuite(SeqFeatureIteratorPrint, 't_',
                                        args = [cur_it])
        runner = unittest.NoTimeTextTestRunner(sys.stdout)
        runner.run(test_suite)
  
class PrimarySeqVectorPrint(GnomeMemoryPrint):
    """Test the PrimarySeqVector functions by printing.
    """
    def __init__(self, method, test_ob):
        GnomeMemoryPrint.__init__(self, method, test_ob)

    def t_size(self):
        print "size:", self._test_ob.size()

    def t_elementAt(self):
        subs = min(5, self._test_ob.size() - 1)

        if subs > -1:
            print "testing elementAt on element %s" % subs

            global cur_seq
            cur_seq = self._test_ob.elementAt(subs)
        
            self.test_PrimarySeq(cur_seq)
        else:
            print "Could not test elementAt, vector length is zero"

    def t_iterator(self):
        global cur_it
        cur_it = self._test_ob.iterator()

        # test the iterator we get back
        test_suite = unittest.makeSuite(PrimarySeqIteratorPrint, 't_',
                                        args = [cur_it])
        runner = unittest.NoTimeTextTestRunner(sys.stdout)
        runner.run(test_suite)

class PrimarySeqDBPrint(GnomeMemoryPrint):
    """Test the PrimarySeqDB functions by printing the information.
    """
    def __init__(self, method, test_ob, acc_num, version = 0):
        GnomeMemoryPrint.__init__(self, method, test_ob)
        self._acc_num = acc_num
        self._version = version

    def setUp(self):
        GnomeMemoryPrint.setUp(self)

        assert self._acc_num is not None, \
               "Need to subclass and define the _acc_num attribute"

    def t_name(self):
        print "name:", self._test_ob.name()
        
    def t_version(self):
        print "version:", self._test_ob.version()

    def t_max_sequence_length(self):
        print "max_sequence_length:", self._test_ob.max_sequence_length()

    def t_get_PrimarySeq(self):
        global cur_seq
        cur_seq = self._test_ob.get_PrimarySeq(self._acc_num, self._version)

        self.test_PrimarySeq(cur_seq)
        
    def t_get_PrimarySeqVector(self):
        try:
            global cur_vector
            cur_vector = self._test_ob.get_PrimarySeqVector()

            # test the vector we get back
            test_suite = unittest.makeSuite(PrimarySeqVectorPrint, 't_',
                                            args = [cur_vector])
            runner = unittest.NoTimeTextTestRunner(sys.stdout)
            runner.run(test_suite)
        except AssertionError:
            print "Does not implement PrimarySeqVector interface"
                
class SeqDBPrint(PrimarySeqDBPrint):
    """Test the SeqDB functions by printing.
    """
    def __init__(self, method, test_ob, acc_num, version = 0):
        PrimarySeqDBPrint.__init__(self, method, test_ob, acc_num, version)
    
    def t_get_Seq(self):
        # grab the sequence and create a test case from it.
        global cur_seq
        cur_seq = self._test_ob.get_Seq(self._acc_num, self._version)

        # now test the sequence we get back
        test_suite = unittest.makeSuite(SeqPrint, 't_',
                                        args = [cur_seq])

        runner = unittest.NoTimeTextTestRunner(sys.stdout)
        runner.run(test_suite)

    def t_accession_numbers(self):
        print "accession_numbers:", self._test_ob.accession_numbers()
        
class UpdateableSeqDBPrint(SeqDBPrint):
    """Test the UpdateableSeqDB functions by printing results.

    XXX ToDo -- define tests for this interface once we've got a server
    that handles it.
    """
    def __init__(self, method, test_ob):
        SeqDBPrint.__init__(self, method, test_ob)
