#!/usr/bin/env python
"""Test the Ensembl CORBA server.

Usage:
python test_Ensembl.py </path/to/ior>

Where </path/to/ior> is the full path to an IOR
for a server implementing the EnsemblFactory interface. This can also
be a URL specifying a remote location. URLs are assumed to start with
either http or ftp.
"""
# standard modules
import sys
import os
import getopt
import string

# pyunit
import unittest

# local modules
import InterfaceTests
from BioCorba.Client.BiocorbaConnect import PerlCorbaClient
from BioCorba.Client.Ensembl import CorbaEnsemblFactory

def main(argv):
    """Perform unit tests against the Ensembl server.
    """
    # make sure we got the right command line arguments
    options, arguments = getopt.getopt(argv[1:], '')
                        
    if len(arguments) != 1:
        raise SystemExit(__doc__)
    
    ior_location = arguments[0]

    print "Retrieving the ensembl server from %s" % ior_location
    # Get the Ensembl server
    server_retriever = PerlCorbaClient(CorbaEnsemblFactory)
    if (string.find(ior_location, "http") >= 0 or
        string.find(ior_location, "ftp") >= 0):
        ensembl_server = server_retriever.from_url_ior(ior_location)
    else:
        ensembl_server = server_retriever.from_file_ior(ior_location)

    # set up all of the tests
    all_tests = [EnsemblServerTest, VirtualContigFactoryTest,
                 VirtualContigTest, GeneFactoryTest, GeneTest, TranscriptTest]
    
    # organize them into a TestSuite
    test_suite = unittest.TestSuite()

    for test in all_tests:
        server_test = test(ensembl_server)
        test_suite.addTest(server_test)

    runner = unittest.TextTestRunner()
    runner.run(test_suite)

class CreateTestMixin:
    """A mixin class which sets up default stuff useful for all test.

    This ties to the runTest function to create a test suite from
    all functions prefixed by t_, so that you can pass information to
    a Test, and still make use of the make_suite functionality of unittest.

    This also automatically gives a description for the entire set of
    Tests from the doc-string for the class.
    """
    def shortDescription(self):
        return string.rstrip(self.__doc__)

    def runTest(self):
        test_names = unittest.getTestCaseNames(self.__class__, 't_', None)
        
        for test_name in test_names:
            print "Running %s..." % test_name
            test_case = getattr(self, test_name)
            test_case()
        
class VirtualContigFactoryTest(CreateTestMixin, unittest.TestCase):
    """Retreiving contigs from a Virtual Contig Factory.
    """
    def __init__(self, ensembl_factory):
        unittest.TestCase.__init__(self)
        self._test_ob = ensembl_factory.get_VirtualContigFactory()
        
    def t_list_all_chr(self):
        """List all chromosomes present in the database.
        """
        # XXX not yet implemented
        # all_chrs = self._test_ob.list_all_chr()
        # print "\n%s" % all_chrs
        pass

    def t_length_of_chr(self):
        """Find the length of a chromosome.
        """
        # XXX not yet implemented
        # test_chr = 'chr2'
        # chr_length = self._test_ob.length_of_chr(test_chr)
        # print "%s, length: %s" % (test_chr, chr_length)
        pass

    def t_fetch_VirtualContig_by_chr_start_end(self):
        """Fetch a virtual contig on a chromosome by location.
        """
        virtual_contig = \
           self._test_ob.fetch_VirtualContig_by_chr_start_end('chr2', 200, 300)

    def t_fetch_VirtualContig_by_chr(self):
        """Fetch an entire virtual contig for a chromosome.
        """
        # XXX Known not to work, as of 13 April 01
        # virtual_contig = self._test_ob.fetch_VirtualContig_by_chr('chr2')
        pass

class VirtualContigTest(CreateTestMixin, InterfaceTests.SeqPrint):
    """Retrieval of information from a VirtualContig.
    """
    def __init__(self, ensembl_factory):
        unittest.TestCase.__init__(self)
        vc_factory = ensembl_factory.get_VirtualContigFactory()
        self._test_ob = \
          vc_factory.fetch_VirtualContig_by_chr_start_end('chr2', 200, 300)
        
    def t_get_GeneIterator(self):
        """Retrieve and use an Iterator over Gene objects.
        """
        gene_iterator = self._test_ob.get_GeneIterator()

        for loop in range(5):
            if not(gene_iterator.has_more()):
                break
            
            cur_gene = gene_iterator.next()
            print "current gene id %s" % cur_gene.id()

class GeneFactoryTest(CreateTestMixin, unittest.TestCase):
    """Retrieve genes via a GeneFactory.
    """
    def __init__(self, ensembl_factory):
        unittest.TestCase.__init__(self)
        self._test_ob = ensembl_factory.get_GeneFactory()

    def t_fetch_Gene_by_id(self):
        """Retrieving genes from the factory based on their IDs.
        """
        all_ids = self._test_ob.list_all_Gene_ids()

        for id in all_ids[:1]:
            cur_gene = self._test_ob.fetch_Gene_by_id(id)
            assert cur_gene.id() == id, \
                   "Fetching incorrect genes, expected %s, got %s" \
                   % (id, cur_gene.id())

    def t_fetch_GeneIterator(self):
        """Retrieve and use an Iterator over Gene objects.
        """
        gene_iterator = self._test_ob.fetch_GeneIterator()

        for loop in range(5):
            if not(gene_iterator.has_more()):
                break
            
            cur_gene = gene_iterator.next()
            print "current gene id %s" % cur_gene.id()

class GeneTest(CreateTestMixin, unittest.TestCase):
    """Display information about a Gene.
    """
    def __init__(self, ensembl_factory):
        unittest.TestCase.__init__(self)
        gene_factory = ensembl_factory.get_GeneFactory()
        self._test_ob = gene_factory.fetch_Gene_by_id('ENSG00000067761')

    def t_id_information(self):
        """Retrieve id and version information about the gene.
        """
        cur_id = self._test_ob.id()
        cur_version = self._test_ob.version()

        print "Current gene is %s, version %s" % (cur_id, cur_version)

    def t_transcripts(self):
        """Test the retrieval of a list of transcripts.
        """
        tc_list = self._test_ob.transcripts()

        for tc in tc_list[:1]:
            print "Got transcript %s, version %s" % (tc.id(), tc.version())

    def t_unique_exons(self):
        """Retrieve and get information about unique Exons of a gene.
        """
        exon_list = self._test_ob.unique_Exons()
        test_exon = exon_list[0]

        print "Got exon %s, verison %s" % (test_exon.id(), test_exon.version())
        print "The phase is from %s to %s" % (test_exon.phase(),
                                              test_exon.end_phase())

        print "SeqFeature properties of the exon"
        test_names = unittest.getTestCaseNames(InterfaceTests.SeqFeaturePrint,
                                               't_', None)
        test_suite = unittest.TestSuite()
        for test_name in test_names:
            test_case = InterfaceTests.SeqFeaturePrint(test_name, test_exon)
            test_suite.addTest(test_case)
            
        runner = unittest.TextTestRunner()
        runner.run(test_suite)            

class TranscriptTest(CreateTestMixin, unittest.TestCase):
    """Display information relating to a transcript of a gene.
    """
    def __init__(self, ensembl_factory):
        unittest.TestCase.__init__(self)
        gene_factory = ensembl_factory.get_GeneFactory()
        gene = gene_factory.fetch_Gene_by_id('ENSG00000067761')
        tc_list = gene.transcripts()

        self._test_ob = tc_list[0]

    def t_id_information(self):
        """Retrieve id and version information about a transcript.
        """
        cur_id = self._test_ob.id()
        cur_version = self._test_ob.version()

        print "Got id %s, version %s" % (cur_id, cur_version)

    def t_exons(self):
        """Retreive the exons of a transcript.
        """
        exon_list = self._test_ob.exons()
        test_exon = exon[0]

        print "Got exon %s, verison %s" % (test_exon.id(), test_exon.version())
        print "The phase is from %s to %s" % (test_exon.phase(),
                                              test_exon.end_phase())

        print "SeqFeature properties of the exon"
        test_names = unittest.getTestCaseNames(InterfaceTests.SeqFeaturePrint,
                                               't_', None)
        test_suite = unittest.TestSuite()
        for test_name in test_names:
            test_case = InterfaceTests.SeqFeaturePrint(test_name, test_exon)
            test_suite.addTest(test_case)

        runner = unittest.TextTestRunner()
        runner.run(test_suite)  

    def t_translate(self):
        """Retrieve a translated sequence.
        """
        translated_seq = self._test_ob.translate()
        
        test_names = unittest.getTestCaseNames(InterfaceTests.PrimarySeqPrint,
                                               't_', None)
        test_suite = unittest.TestSuite()
        for test_name in test_names:
            test_case = InterfaceTests.PrimarySeqPrint(test_name,
                                                       translated_seq)
            test_suite.addTest(test_case)

        runner = unittest.TextTestRunner()
        runner.run(test_suite)

    def t_get_translation(self):
        """Retrieve information about the translation of the transcript.
        """
        translation = self._test_ob.get_translation()

        print "Got id %s, version %s" % (translation.id(),
                                         translation.version())

        print "Starts on exon %s, position %s" % (translation.start_exon_id(),
                                                  translation.start())

        print "Ends on exon %s, position %s" % (translation.end_exon_id(),
                                                translation.end())

class EnsemblServerTest(unittest.TestCase):
    """Demonstrate interoperability with an ensembl server.
    """
    def __init__(self, ensembl_server):
        unittest.TestCase.__init__(self)

        self._ensembl_server = ensembl_server

    def shortDescription(self):
        return string.rstrip(self.__doc__)
    
    def runTest(self):
        # Test a VirtualContigFactory
        vc_factory = self._ensembl_server.get_VirtualContigFactory()

        virtual_contig = \
          vc_factory.fetch_VirtualContig_by_chr_start_end('chr2', 200, 300)

        print "Sequence is:", virtual_contig.seq()

        # Test a GeneFactory
        gene_factory = self._ensembl_server.get_GeneFactory()
        gene = gene_factory.fetch_Gene_by_id('ENSG00000067761')

        print "Gene is %s, version %s" % (gene.id(), gene.version())

        all_transcripts = gene.transcripts()

        for transcript in all_transcripts:
            print "transcript is %s, version %s" % \
                  (transcript.id(), transcript.version())
            print "protein for transcript: %s" % transcript.id()

            translation = transcript.get_translation()
            print "  translation is %s, version %s" % \
                  (translation.id(), translation.version())
            print "  start exon id: %s, end exon id: %s" % \
                  (translation.start_exon_id(), translation.end_exon_id())
            print "  start: %s, end: %s" % \
                  (translation.start(), translation.end())

        all_exons = gene.unique_Exons()
        for exon in all_exons:
            print "exon = %s/%s, phase = %s, end phase = %s" % \
                  (exon.id(), exon.version(), exon.phase(), exon.end_phase())

        gene_ids = gene_factory.list_all_Gene_ids()
        print "%s genes found" % gene_ids

        gene_iterator = gene_factory.fetch_GeneIterator()

        for loop in range(5):
            if not(gene_iterator.has_more()):
                break
            
            cur_gene = gene_iterator.next()
            print "current gene id %s" % cur_gene.id()
        

if __name__ == "__main__":
    sys.exit(main(sys.argv))
