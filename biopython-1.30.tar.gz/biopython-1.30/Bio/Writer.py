class Writer:
    def __init__(self, outfile):
        self.outfile = outfile
    def writeHeader(self):
        pass
    def write(self, record):
        pass
    def writeFooter(self):
        pass
