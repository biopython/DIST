NSsites = bad
