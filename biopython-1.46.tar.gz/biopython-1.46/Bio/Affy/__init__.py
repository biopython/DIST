"""Deal with Affymetrix related data such as cel files.
"""
