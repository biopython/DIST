valid_sequence_dict = { "P1": "complete protein", "F1": "protein fragment", \
    "DL": "linear DNA", "DC": "circular DNA", "RL": "linear RNA", \
    "RC":"circular RNA", "N3": "transfer RNA", "N1": "other"
    }
