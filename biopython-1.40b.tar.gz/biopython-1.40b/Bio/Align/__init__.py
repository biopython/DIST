"""Code for dealing with sequence alignments.
"""
