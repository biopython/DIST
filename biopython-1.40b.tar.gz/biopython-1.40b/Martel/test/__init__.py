# This is a Python module

def test():
    import run_tests
    run_tests.main([])

if __name__ == "__main__":
    test()
