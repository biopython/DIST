"""Code to interact with the ever-so-useful EMBOSS programs.
"""
