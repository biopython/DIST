#!/usr/bin/env python
"""Provide tests for Features and Annotations of Sequences.
"""
# standard library
import sys
import os

# PyUnit
import unittest

# biopython
from Bio.Seq import Seq
from Bio.SeqRecord import SeqRecord
from Bio.Alphabet import IUPAC
from Bio.SeqFeature import SeqFeature, FeatureLocation, WithinPosition

# biocorba stuff we are testing
import BioCorba.Server.Seqcore.CorbaSequence as SequenceServer
from BioCorba.Client.BiocorbaConnect import PythonCorbaClient
import BioCorba.Client.Seqcore.CorbaSequence as SequenceClient
from BioCorba.Client.Bsane import Base
from BioCorba.Client.Seqcore import CorbaSeqFeature
from BioCorba.Client.Bsane import CorbaExceptions

def run_tests(argv):
    test_suite = testing_suite()
    runner = unittest.TextTestRunner(sys.stdout, verbosity = 2)
    runner.run(test_suite)

def testing_suite():
    """Generate the suite of tests.
    """
    test_suite = unittest.TestSuite()

    test_loader = unittest.TestLoader()
    test_loader.testMethodPrefix = 't_'
    tests = [AnnotationTest, SeqFeatureTest]
    
    for test in tests:
        cur_suite = test_loader.loadTestsFromTestCase(test)
        test_suite.addTest(cur_suite)

    return test_suite

class AnnotationTest(unittest.TestCase):
    """Tests for Annotations (ie. extended name/value pairs) on Sequences.
    """
    def setUp(self):
        """Set up a simple Sequence with annotations to test with.
        """
        test_seq = Seq("GATCGATC", IUPAC.unambiguous_dna)
        test_seqrecord = SeqRecord(test_seq, "FAKEID", "Test Sequence",
                                   "This is just a little test sequence.")
        test_seqrecord.annotations = {"organism" : "Opuntia ficus-indica",
                                      "chromosome" : "1",
                                      "clone_name" : ["T25K", "T25L"]}
        server = SequenceServer.BioSequence(test_seqrecord)
        server_obj = server.get_object()

        # now set up a client connected to the server
        client_generator = \
                   PythonCorbaClient(SequenceClient.BioSequence)
        self.client = client_generator.from_object(server_obj)

    def t_all_annotations(self):
        """Test retrieval of all annotations for a sequence.
        """
        ann_collection = self.client.get_annotations()

        num_annotations = ann_collection.get_num_annotations()
        assert num_annotations == 4, \
          "Unexpected number of annotations: %s" % num_annotations

        first_annotations, rest = ann_collection.get_annotations(2)
        assert len(first_annotations) == 2, \
          "Got incorrect number of annotations: %s" % len(first_annotations)

        # check the first annotation
        first_annotation = first_annotations[0]
        name = first_annotation.get_name()
        assert name == "chromosome", "Got unexpected name: %s" % name
        value = first_annotation.get_value()
        assert value == "1", \
          "Got unexpected value: %s" % value
        basis = first_annotation.get_basis()
        assert basis == "not known", "Got unexpected basis: %s" % basis

    def t_annotation_iterator(self):
        """Test iterating over a list of annotations.
        """
        ann_collection = self.client.get_annotations()
        first_annotations, iterator = ann_collection.get_annotations(0)
        assert len(first_annotations) == 0, \
          "Expected no annotations got %s" % (len(first_annotations))

        # iterate through the annotations and make sure they come out
        # correctly
        first = iterator.next()
        name = first.get_name()
        value = first.get_value()
        assert name == "chromosome" and value == "1", \
          "Got unexpected name and value -- %s:%s" % (name, value)

        second = iterator.next()
        third = iterator.next()
        fourth = iterator.next()

        # we should get a StopIteration error with the last item
        try:
            last = iterator.next()
            raise AssertionError("Didn't stop iterating properly.")
        except Base.StopIteration:
            pass

    def t_annotations_by_name(self):
        """Retrieve single annotations by name.
        """
        ann_collection = self.client.get_annotations()
        
        ann_list = ann_collection.get_annotations_by_name("organism")
        assert len(ann_list) == 1, \
          "Expected 1 annotation, got %s" % len(ann_list)
        value = ann_list[0].get_value()
        assert value == "Opuntia ficus-indica", \
          "Got unexpected value for organism: %s" % value

    def t_multiple_annotations_by_name(self):
        """Retrieve multiple annotations by name
        """
        ann_collection = self.client.get_annotations()
        
        ann_list = ann_collection.get_annotations_by_name("clone_name")
        assert len(ann_list) == 2, \
          "Got unexpected number of annotations: %s" % len(ann_list)

        expected_values = ["T25K", "T25L"]
        actual_values = []
        for annotation in ann_list:
            actual_values.append(annotation.get_value())
        actual_values.sort()
        assert actual_values == expected_values, "Got %s, expected %s" % \
          (actual_values, expected_values)

class SeqFeatureTest(unittest.TestCase):
    """Provide tests for sequence features.
    """
    def setUp(self):
        """Create a sequence server with features and a connected client.
        """
        test_seq = Seq("GATCGATC", IUPAC.unambiguous_dna)
        test_seqrecord = SeqRecord(test_seq, "FAKEID", "Test Sequence",
                                   "This is just a little test sequence.")
        first_feature = SeqFeature(FeatureLocation(2, 50),
                                   "CDS", "join", -1, 
                                   "SequenceFeatureNumber1")
        first_feature.qualifiers = {"locus" : "AFAKELOCUS",
                                    "chromosome" : "1"}
        first_feature.sub_features = \
          [SeqFeature(FeatureLocation(2, 20), 
                      "CDS_join", "join", 0, "InternalFeature1"),
           SeqFeature(FeatureLocation(20, 50),
                      "CDS_join", "join", 1, "InternalFeature2")]
        test_seqrecord.features.append(first_feature)
        second_feature = SeqFeature(FeatureLocation(1, 300),
                                   "locus", None, 1, 
                                   "SequenceFeatureNumber2")
        second_feature.qualifiers = {"locus" : "AFAKELOCUS2",
                                    "chromosome" : "2"}
        second_feature.sub_features = []
        test_seqrecord.features.append(second_feature)
                                    
        server = SequenceServer.BioSequence(test_seqrecord)
        server_obj = server.get_object()

        # now set up a client connected to the server
        client_generator = \
                   PythonCorbaClient(SequenceClient.BioSequence)
        self.client = client_generator.from_object(server_obj)

    def t_feature_retrieval(self):
        """Get sequence features from a SeqFeatureCollection.
        """
        feature_collection = self.client.get_seq_features()

        feature_region = FeatureLocation(1, 300)
        num_features = \
          feature_collection.num_features_on_region(feature_region)
        assert num_features == 2, \
          "Got unexpected number of features: %s" % (num_features)

        feature_list, iterator = \
          feature_collection.get_features_on_region(1, feature_region)
        assert len(feature_list) == 1, \
          "Got unexpected number of features: %s" % len(feature_list)
        
        feature_list, iterator = \
          feature_collection.get_features_on_region(2, feature_region)
        assert len(feature_list) == 2, \
          "Got unexpected number of features: %s" % len(feature_list)
        
    def t_feature_iterator(self):
        """Iterate over a group of SeqFeatures.
        """
        feature_collection = self.client.get_seq_features()
        feature_region = FeatureLocation(1, 300)
        feature_list, iterator = \
          feature_collection.get_features_on_region(0, feature_region)

        assert len(feature_list) == 0, \
          "Got features in the feature list when not expected."

        first_feature = iterator.next()
        assert isinstance(first_feature, CorbaSeqFeature.SeqFeature), \
          "Did not get SeqFeature when expected."
        second_feature = iterator.next()
        assert isinstance(second_feature, CorbaSeqFeature.SeqFeature), \
          "Did not get SeqFeature when expected."

        try:
            last = iterator.next()
            raise AssertionError("Didn't stop iterating properly.")
        except Base.StopIteration:
            pass

    def t_feature_information(self):
        """Retrieve the start and end coordinates, and other info of a feature.
        """
        feature_collection = self.client.get_seq_features()
        feature_region = FeatureLocation(1, 300)
        feature_list, iterator = \
          feature_collection.get_features_on_region(1, feature_region)

        feature = feature_list[0]
        feature_start = feature.get_start()
        assert feature_start == 2, \
          "Expected 2 for start, got %s" % feature_start
        feature_end = feature.get_end()
        assert feature_end == 50, "Expected 50 for end, got %s" % feature_end

        try:
            owner_seq = feature.get_owner_sequence()
            raise AssertionError("Did not give an error on getting seq.")
        except CorbaExceptions.DoesNotExist:
            pass

    def t_feature_locations(self):
        """Look at all of the locations of a sequence feature.
        """
        feature_collection = self.client.get_seq_features()
        feature_region = FeatureLocation(1, 300)
        feature_list, iterator = \
          feature_collection.get_features_on_region(1, feature_region)

        feature = feature_list[0]
        locations = feature.get_locations()
        assert len(locations) == 1, "Got an incorrect number of locations."
        location_feature = locations[0]

        # check that the returned seq_feature with locations seems right
        assert str(location_feature.location) == \
          str(FeatureLocation(2, 50)), \
          "Incorrect location found: %s" % location_feature.location
        assert location_feature.strand == -1, \
          "Unexpected strand: %s" % location_feature.strand
        assert location_feature.id == "SequenceFeatureNumber1", \
          "Got unexpected id: %s" % location_feature.id
        assert location_feature.location_operator == "join", \
          "Got unexpected location operator: %s" \
          % location_feature.location_operator
        
    def t_feature_annotations(self):
        """Get the annotations on a sequence feature.
        """
        feature_collection = self.client.get_seq_features()
        feature_region = FeatureLocation(1, 300)
        feature_list, iterator = \
          feature_collection.get_features_on_region(1, feature_region)

        feature = feature_list[0]
        ann_collection = feature.get_annotations()
        annotations, rest = ann_collection.get_annotations(2)
        assert len(annotations) == 2, \
          "Got unexpected number of annotations: %s" % len(annotations)
        value = annotations[0].get_value()
        name = annotations[0].get_name()
        assert name == "chromosome" and value == "1", \
          "Unexpected name, value pair: %s, %s" % (name, value)

        value = annotations[1].get_value()
        name = annotations[1].get_name()
        assert name == "locus" and value == "AFAKELOCUS", \
          "Unexpected name, value pair: %s, %s" % (name, value)
        
    def t_sub_feature_locations(self):
        """Make sure sub_features are handled correctly.
        """
        feature_collection = self.client.get_seq_features()
        feature_region = FeatureLocation(1, 300)
        feature_list, iterator = \
          feature_collection.get_features_on_region(1, feature_region)
        locations = feature_list[0].get_locations()
        assert len(locations) == 1, \
          "Expected a single location, got %s" % locations
        # now look at the biopython feature information from the
        # CORBA location struct
        feature = locations[0]

        # test the sub-feature information which is conserved during the
        # transfer, which are start, end and strand.
        assert len(feature.sub_features) == 2, \
          "Expected 2 sub-features, got %s" % len(feature.sub_features)
        first_sub = feature.sub_features[0]
        assert str(first_sub.location.start) == "2", \
          "Got unexpected start location %s" % first_sub.start
        assert str(first_sub.location.end) == "20", \
          "Got unexpected end location %s" % first_sub.end
        assert first_sub.strand == 0, \
          "Got unexpected strand %s" % first_sub.strand

        second_sub = feature.sub_features[1]
        assert str(second_sub.location.start) == "20", \
          "Got unexpected start location %s" % second_sub.start
        assert str(second_sub.location.end) == "50", \
          "Got unexpected end location %s" % second_sub.end
        assert second_sub.strand == 1, \
          "Got unexpected strand %s" % second_sub.strand
        
if __name__ == "__main__":
    sys.exit(run_tests(sys.argv))
