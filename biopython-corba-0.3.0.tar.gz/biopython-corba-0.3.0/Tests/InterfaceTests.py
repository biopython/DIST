"""Groups of reusable tests for specific interfaces.

This module contains tests for specific BioCorba interfaces that test all
of the functions of the interfaces. These classes can be imported and used
in tests for specific situations.

The basic idea behind these is that they make it quick 'n dirty to test
interfaces under a number of different conditions. All the functions
do is print out the information, so you have to go through and sort out
the output.

These interfaces are structured as classes so they can inherit from
each other (and thus avoid duplicating code), but act sorta like functions,
so all you need to do to run the test code on a class is do:

    TestClass(arg1, arg2)

and it'll automagically go.
"""
# local stuff
from BioCorba.Client.Bsane.Base import StopIteration
from BioCorba.Client.Bsane import CorbaExceptions

# biopython
from Bio.SeqFeature import FeatureLocation

class TestBase:
    """Actually add the test object and run the tests on the class.
    """
    def __init__(self, test_ob):
        self._test_ob = test_ob

        # the big daddy call -- run the tests
        self.run()

class TestRemovable(TestBase):
    """Test the memory management functions.
    """
    def __init__(self, test_ob):
        TestBase.__init__(self, test_ob)

    def run(self):
        pass

class TestIterator(TestRemovable):
    """Generic test for iterators.
    """
    def __init__(self, test_ob, return_test_class):
        """Initialize with a test class to call on each returned object.
        """
        self._test_class = return_test_class
        TestRemovable.__init__(self, test_ob)

    def run(self):
        TestRemovable.run(self)

        for loop in range(0, 10):
            try:
                next_item = self._test_ob.next()
            except StopIteration:
                break
            self._test_class(next_item)

class TestIdentifiable:
    """Print out information for the identifiable interface.
    """
    def run(self):
        print "id:", self._test_ob.get_id()
        print "name:", self._test_ob.get_name()
        print "description:", self._test_ob.get_description()
        print "basis:", self._test_ob.get_basis()

class TestAnnotation(TestRemovable):
    """Print out information for an annotation.
    """
    def __init__(self, test_ob):
        TestRemovable.__init__(self, test_ob)

    def run(self):
        TestRemovable.run(self)
        print "name:", self._test_ob.get_name()
        print "value:", self._test_ob.get_value()
        print "basis:", self._test_ob.get_basis()

class TestAnnotationCollection(TestBase):
    def __init__(self, test_ob, test_name = "Annotation Name"):
        self._test_name = test_name
        TestBase.__init__(self, test_ob)

    def run(self):
        print "number of annotations:", self._test_ob.get_num_annotations()

        # first test the annotation list
        num_annotations = self._test_ob.get_num_annotations()
        ann_list, iterator = self._test_ob.get_annotations(num_annotations)
        for ann in ann_list:
            TestAnnotation(ann)

        # now test out the iterator
        ann_list, iterator = self._test_ob.get_annotations(0)
        TestIterator(iterator, TestAnnotation)

        # test retrieving stuff by name
        try:
            ann_list = self._test_ob.get_annotations_by_name(self._test_name)
            for ann in all_list:
                TestAnnotation(ann)
        except CorbaExceptions.IdentifierNotResolvable:
            print "Did not find annotation with name %s" % self._test_name

class TestAnnotatable:
    """Print out information for the annotatable interface.
    """
    def run(self):
        annotation_collection = self._test_ob.get_annotations()
        TestAnnotationCollection(annotation_collection)

class TestAnnotatableSequence(TestAnnotatable):
    """Print out information for the AnnotatableSequence interface.
    """
    def run(self):
        TestAnnotatable.run(self)

        seq_feat_collection = self._test_ob.get_seq_features()
        TestSeqFeatureCollection(seq_feat_collection)

class TestSeqFeature(TestAnnotation, TestAnnotatable):
    def __init__(self, test_ob):
        TestAnnotation.__init__(self, test_ob)

    def run(self):
        TestAnnotation.run(self)
        TestAnnotatable.run(self)

        print "start:", self._test_ob.get_start()
        print "end:", self._test_ob.get_end()
        locations = self._test_ob.get_locations()
        print "locations:"
        for location in locations:
            print "\t%s" % location
            
        try:
            anon_seq = self._test_ob.get_owner_sequence()
            TestAnonymousSequence(anon_seq)
        except CorbaExceptions.DoesNotExist:
            print "Anonymous Sequence isn't available on SeqFeature."

class TestSeqFeatureCollection(TestAnnotationCollection):
    def __init__(self, test_ob, ann_name = "Annotation Name", 
                 seq_regions = [FeatureLocation(0, 100), 
                                FeatureLocation(5, 20), 
                                FeatureLocation(25, 75)]):
        """Intialize to test a SeqFeatureCollection.

        ann_name is a name of annotation types to retrieve (in 
        TestAnnotationCollection) and seq_regions is a list of regions to
        display the features for.
        """
        self._regions = seq_regions
        TestAnnotationCollection.__init__(self, test_ob, ann_name)

    def run(self):
        TestAnnotationCollection.run(self)

        for region in self._regions:
            try:
                # test out lists
                sf_list, iterator = \
                  self._test_ob.get_features_on_region(10, region)
                for sf in sf_list:
                    TestSeqFeature(sf)

                # now test out iterators
                sf_list, iterator = \
                  self._test_ob.get_features_on_region(0, region)
                TestIterator(iterator, TestSeqFeature)
            except CorbaExceptions.SeqFeatureLocationOutOfBounds:
                print "location %s was out of bounds" % region
        
class TestAnonymousSequence(TestRemovable):
    """Test AnonymousSequence by printing the information.
    """
    def __init__(self, test_ob):
        TestRemovable.__init__(self, test_ob)
    
    def run(self):
        TestRemovable.run(self)
        print "type:", self._test_ob.get_type()
        print "is_circular", self._test_ob.is_circular()
        print "length:", self._test_ob.get_length()
        print "seq:", self._test_ob.seq()

        # sub_seq
        seq_len = self._test_ob.get_length()
        first_subs = min(5, seq_len)
        second_subs = min(20, seq_len)
        print "subseq(%s, %s)" % (first_subs, second_subs), \
              self._test_ob.sub_seq(first_subs, second_subs)

class TestBioSequence(TestAnonymousSequence, TestIdentifiable,
                      TestAnnotatableSequence):  
    """Test the BioSequence functions by printing the information.
    """
    def __init__(self, test_ob):
        TestAnonymousSequence.__init__(self, test_ob)

    def run(self):
        TestAnonymousSequence.run(self)
        TestIdentifiable.run(self)
        TestAnnotatableSequence.run(self)

        anonymous_seq = self._test_ob.get_anonymous_sequence()
        TestAnonymousSequence(anonymous_seq)

class TestBioSequenceIdentifierResolver:
    def run(self):
        for id in self._test_ids:
            try:
                bio_seq = self._test_ob.resolve(id)
                TestBioSequence(bio_seq)
            except CorbaExceptions.IdentifierDoesNotExist:
                print "ID %s does not exist."
            except CorbaExceptions.IdentifierNotResolvable:
                print "ID %s was not resolvable."
            except CorbaExceptions.IdentifierNotUnique:
                print "ID %s was not unique."

class TestBioSequenceCollection(TestBioSequenceIdentifierResolver,
                                TestIdentifiable, TestAnnotatable, TestBase):
    def __init__(self, test_ob, test_ids = ["FAKE Id 1"]):
        """initialize with the object and test ids to try out.
        """
        self._test_ids = test_ids
        TestBase.__init__(self, test_ob)

    def run(self):
        TestIdentifiable.run(self)
        TestAnnotatable.run(self)
        TestBioSequenceIdentifierResolver.run(self)

        # test out sequence list
        bio_seq_list, iterator = self._test_ob.get_seqs(5)
        for bio_seq in bio_seq_list:
            TestBioSequence(bio_seq)

        # test out BioSequence iterators
        bio_seq_list, iterator = self._test_ob.get_seqs(0)
        TestIterator(iterator, TestBioSequence)
        
