#!/usr/bin/env python
"""Test python implemented servers by running them through interface tests.

This tests the server which can be started by running
Scripts/collection_server.py. It gets the IOR for this server
from ../ior/collection.ior.
"""
# standard modules
import os
import sys

# local testing stuff
import InterfaceTests

# local modules
from BioCorba.Client.Seqcore.CorbaCollection import BioSequenceCollection
from BioCorba.Client.BiocorbaConnect import PythonCorbaClient

# --- constants
IOR_FILE = os.path.join(os.getcwd(), os.pardir, 'ior', 'collection.ior')
TEST_IDS = ["X62281", "M81224"]

# get the bioenv server
print "Retrieving server..."
server_retriever = PythonCorbaClient(BioSequenceCollection)
collection_server = server_retriever.from_file_ior(IOR_FILE)

# make sure the collection_server is running
try:
    name = collection_server.get_name()
    print "Running tests on database: %s..." % name
# we will get a CORBA.COMM_FAILURE here if the server is not started
except ValueError:
    print "You must start up the collection_server in the Scripts"
    print "directory, by running 'python collection_server.py"
    sys.exit()

InterfaceTests.TestBioSequenceCollection(collection_server, TEST_IDS)

