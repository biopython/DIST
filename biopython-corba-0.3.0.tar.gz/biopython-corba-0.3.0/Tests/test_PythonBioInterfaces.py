#!/usr/bin/env python
"""Test the Bio-like interfaces to BioCorba using the python BioEnv server.

To test the interfaces, you need to start the BioEnv server in
Scripts/bioenv_server.py.

The IOR for this server will be retrieved from ../ior/bioenv.ior.
"""
# standard modules
import os
import sys

# PyUnit testing framework
import unittest

# local modules
from BioCorba.Client.BiocorbaConnect import PythonCorbaClient
import BioCorba.Client.Seqcore.CorbaSequence as SequenceClient
import BioCorba.Server.Seqcore.CorbaSequence as SequenceServer
import BioCorba.Server.Seqcore.CorbaCollection as CollectionServer
import BioCorba.Client.Seqcore.CorbaCollection as CollectionClient

# bio-interface
from BioCorba.Bio.Seq import Seq as BioCorbaSeq
from BioCorba.Bio.SeqRecord import SeqRecord as BioCorbaSeqRecord
from BioCorba.Bio import Fasta as BioCorbaFasta
from BioCorba.Bio import GenBank as BioCorbaGenBank

# biopython
from Bio.SeqFeature import SeqFeature, FeatureLocation, AfterPosition
from Bio.Seq import Seq
from Bio.SeqRecord import SeqRecord
from Bio import Alphabet
from Bio.Alphabet import IUPAC
from Bio import GenBank

def run_tests(argv):
    test_suite = testing_suite()
    runner = unittest.TextTestRunner(sys.stdout, verbosity = 2)
    runner.run(test_suite)

def testing_suite():
    """Generate the suite of tests.
    """
    test_suite = unittest.TestSuite()

    test_loader = unittest.TestLoader()
    test_loader.testMethodPrefix = 't_'
    tests = [SeqTest, SeqRecordTest, SeqFeatureTest, GenBankTest]
    
    for test in tests:
        cur_suite = test_loader.loadTestsFromTestCase(test)
        test_suite.addTest(cur_suite)

    return test_suite

class SeqTest(unittest.TestCase):
    """Test the Biopython-like Seq interface to BioCorba.
    """
    def setUp(self):
        """Start an AnonymousSequence server and client to use in testing.
        """
        # get the server
        test_seq = Seq("GATCGATC", IUPAC.unambiguous_dna)
        server = SequenceServer.AnonymousSequence(test_seq)
        server_obj = server.get_object()

        # now set up a client connected to the server
        client_generator = \
                   PythonCorbaClient(SequenceClient.AnonymousSequence)
        self.client = client_generator.from_object(server_obj)

        # now get ourselves a BioCorba.Seq object
        self.seq = BioCorbaSeq(self.client)

    def t_alphabet(self):
        """Make sure the alphabet chooser picks proper alphabets.
        """
        assert self.seq.alphabet == Alphabet.generic_dna, \
          "Got unexpected found alphabet: %r" % self.seq.alphabet

        pick_seq = BioCorbaSeq(self.client, IUPAC.unambiguous_dna)
        assert pick_seq.alphabet == IUPAC.unambiguous_dna, \
          "Got unexpected chosen alphabet: %r" % pick_seq.alphabet

    def t_simple_items(self):
        """Test for getting the length and sequence of the sequence.
        """
        string_seq = self.seq.data
        assert string_seq == "GATCGATC", "Got unexpected seq: %s" % string_seq

        length = len(self.seq)
        assert length == 8, "Got unexpected length: %s" % length

    def t_slices(self):
        """Test the ability to make slices out of the sequence.
        """
        entire_seq = self.seq[:]
        expected_entire = "GATCGATC"

        front_seq = self.seq[0:3]
        expected_front = "GAT"

        end_seq = self.seq[4:]
        expected_end = "GATC"

        middle_seq = self.seq[1:5]
        expected_middle = "ATCG"

        for seq, expect in [(entire_seq, expected_entire), 
                            (front_seq, expected_front),
                            (end_seq, expected_end),
                            (middle_seq, expected_middle)]:
            assert isinstance(seq, Seq), \
              "Expected Bio.Seq object, got %r" % seq
            assert seq.data == expect, \
              "Expected sequence of %s, got %s" % (expect, seq.data)

class SeqRecordTest(unittest.TestCase):
    """Test the Biopython-like SeqRecord interface to BioCorba.
    """
    def setUp(self):
        """Create a BioSequence server and client to perform the tests with.
        """
        test_seq = Seq("GATCGATC", IUPAC.unambiguous_dna)
        test_seqrecord = SeqRecord(test_seq, "FAKEID", "Test Sequence",
                                   "This is just a little test sequence.")
        test_seqrecord.annotations = {"organism" : "Opuntia ficus-indica",
                                      "chromosome" : "1",
                                      "clone_name" : ["T25K", "T25L"]}
        server = SequenceServer.BioSequence(test_seqrecord)
        server = SequenceServer.BioSequence(test_seqrecord)
        server_obj = server.get_object()

        # now set up a client connected to the server
        client_generator = \
                   PythonCorbaClient(SequenceClient.BioSequence)
        client = client_generator.from_object(server_obj)

        # finally get ourselves a SeqRecord object
        self.seq_record = BioCorbaSeqRecord(client)

    def t_get_simple_attributes(self):
        """Retrieve basic attributes of the SeqRecord.
        """
        seq = self.seq_record.seq
        assert isinstance(seq, BioCorbaSeq), \
          "Got unexpected seq type: %r" % seq
        id = self.seq_record.id
        assert id == "FAKEID", "Got Unexpected ID: %s" % id
        name = self.seq_record.name
        assert name == "Test Sequence", "Got unexpected name: %s" % name
        description = self.seq_record.description
        assert description == "This is just a little test sequence.", \
          "Got unexpected description: %s" % description

        try:
            self.seq_record.fake_attribute
            raise AssertionError("Fake attribute didn't raise an error.")
        except AttributeError:
            pass

    def t_annotations(self):
        """Retrieve the annotations on the SeqRecord.
        """
        annotations = self.seq_record.annotations
        assert annotations.has_key("organism") and \
          annotations["organism"] == ["Opuntia ficus-indica"], \
          "Got unexpected annotations: %s" % annotations
        
        assert annotations.has_key("chromosome") and \
          annotations["chromosome"] == ["1"], \
          "Got unexpected annotations: %s" % annotations
        
        assert annotations.has_key("clone_name") and \
          annotations["clone_name"] == ["T25K", "T25L"], \
          "Got unexpected annotations: %s" % annotations
        
class SeqFeatureTest(unittest.TestCase):
    """Test the Biopython-like SeqFeature interface to BioCorba.
    """
    def setUp(self):
        """Create a SeqFeature object we can use for testing.
        """
        test_seq = Seq("GATCGATC", IUPAC.unambiguous_dna)
        test_seqrecord = SeqRecord(test_seq, "FAKEID", "Test Sequence",
                                   "This is just a little test sequence.")
        first_feature = SeqFeature(FeatureLocation(2, 6),
                                   "CDS", "join", -1, 
                                   "SequenceFeatureNumber1")
        first_feature.qualifiers = {"locus" : "AFAKELOCUS",
                                    "chromosome" : "1"}
        first_feature.sub_features = \
          [SeqFeature(FeatureLocation(2, 4), 
                      "CDS_join", "join", 0, "InternalFeature1"),
           SeqFeature(FeatureLocation(4, 6),
                      "CDS_join", "join", 1, "InternalFeature2")]
        test_seqrecord.features.append(first_feature)
                                    
        server = SequenceServer.BioSequence(test_seqrecord)
        server_obj = server.get_object()

        # now set up a client connected to the server
        client_generator = \
                   PythonCorbaClient(SequenceClient.BioSequence)
        client = client_generator.from_object(server_obj)

        # finally get a SeqFeature object
        seq_record = BioCorbaSeqRecord(client)
        features = seq_record.features
        assert len(features) == 1, "Got unexpected features: %s" % features
        self.feature = features[0]

    def t_simple_attributes(self):
        """Retrieve basic attributes of the SeqFeature object.
        """
        type = self.feature.type
        assert type == "CDS", "Unexpected type: %s" % type
        strand = self.feature.strand
        assert strand == -1, "Unexpected strand: %s" % strand
        id = self.feature.id
        assert id == "SequenceFeatureNumber1", \
          "Unexpected ID: %s" % id
        
        try:
            self.feature.fake_attribute
            raise AssertionError("Fake attribute did not cause error.")
        except AttributeError:
            pass
        
    def t_qualifiers(self):
        """Retrieve qualifers of the SeqFeature.
        """
        qualifiers = self.feature.qualifiers
        assert qualifiers.has_key("locus") and \
          qualifiers["locus"] == ["AFAKELOCUS"], \
          "Got unexpected qualifiers: %s" % qualifiers
        
        assert qualifiers.has_key("chromosome") and \
          qualifiers["chromosome"] == ["1"], \
          "Got unexpected qualifiers: %s" % qualifiers
       
    def t_location(self):
        """Get the FeatureLocation of the SeqFeature.
        """
        location = self.feature.location
        assert str(location) == str(FeatureLocation(2, 6)), \
          "Got unexpected location: %s" % location

    def t_sub_features(self):
        """Retrieve sub_SeqFeatures of the SeqFeature.
        """
        sub_features = self.feature.sub_features
        assert len(sub_features) == 2, \
          "Got unexpected sub_features: %s" % sub_features

        assert sub_features[0].strand == 0 and \
          str(sub_features[0].location) == str(FeatureLocation(2, 4)), \
          "Unexpected first sub_feature: %s" % sub_features[0]

        assert sub_features[1].strand == 1 and \
          str(sub_features[1].location) == str(FeatureLocation(4, 6)), \
          "Unexpected second sub_feature: %s" % sub_features[1]

class GenBankTest(unittest.TestCase):
    """Test the GenBank interface to BioSequenceCollection information.

    This looks at the ability of the BioCorba server to go from
    GenBank to GenBank.
    """
    def setUp(self):
        """Create a GenBank based BioSequenceCollection server.
        """
        gb_file = os.path.join(os.getcwd(), "files", "cor6_6.gb")
        # create the name of the index file and index it
        file_name, ext = os.path.splitext(gb_file)
        index_file = file_name + '.idx'
        GenBank.index_file(gb_file, index_file)

        # set up the GenBank dictionary and Collection server
        seqfeat_parser = GenBank.FeatureParser()
        db_dict = GenBank.Dictionary(index_file, seqfeat_parser)
        server = CollectionServer.BioSequenceCollection(db_dict)
        server_obj = server.get_object()

        # now set up a client connected to the server
        client_generator = \
                   PythonCorbaClient(CollectionClient.BioSequenceCollection)
        client = client_generator.from_object(server_obj)

        # finally set up the GenBank database and iterator
        parser = BioCorbaGenBank.FeatureParser()
        self.database = BioCorbaGenBank.Dictionary(client, parser)
        self.iterator = BioCorbaGenBank.Iterator(client, parser)

    def t_dictionary_properties(self):
        """Test basic properties of the GenBank dictionary.
        """
        num_items = len(self.database)
        assert num_items == 6, \
          "Got unexpected number of items: %s" % num_items

        keys = self.database.keys()
        assert keys == ['AF297471', 'AJ237582', 'L31939', 'M81224', 
                        'X55053', 'X62281'], \
          "Got unexpected keys from dictionary: %s" % keys

    def t_dictionary_retrieval(self):
        """Test the retrieval of items from the dictionary.
        """
        first_item = self.database["X55053"]
        assert first_item.id == "X55053.1", \
          "Unexpected item: %s" % first_item.id
        second_item = self.database["L31939"]
        assert second_item.id == "L31939.1", \
          "Unexpected item: %s" % second_item.id

        try:
            fake_item = self.database["NOTREAL"]
            raise AssertionError("Did not get error with fake ID.")
        except KeyError:
            pass

    def t_genbank_iterator(self):
        """Test looping over items with an iterator.
        """
        expected_ids = ['AF297471.1', 'AJ237582.1', 'L31939.1', 
                        'M81224.1', 'X55053.1', 'X62281.1']

        # loop through all of the expected records and check 'em
        for i in range(6):
            expect_id = expected_ids[i]
            next_item = self.iterator.next()
            assert next_item.id == expect_id, \
              "Got unexpected item: %s, wanted %s" % (next_item.id, expect_id)

        # make sure iteration ends properly
        done_iterating_item = self.iterator.next()
        assert done_iterating_item is None, \
          "Expected None at end of iteration, got %s" % done_iterating_item

    def t_detailed_object(self):
        """Test a record in detail to see how well information is passed.
        """
        test_item = self.database["X55053"]

        # test basic SeqRecord properties in detail
        assert test_item.id == "X55053.1", \
          "Got unexpected id: %s" % test_item.id
        assert test_item.name == "ATCOR66M", \
          "Got unexpected name: %s" % test_item.name
        assert test_item.description == "A.thaliana cor6.6 mRNA.", \
          "Got unexpected description: %s" % test_item.description
        partial_seq = test_item.seq[:10]
        assert partial_seq.data == "AACAAAACAC", \
          "Got unexpected partial sequence: %s" % partial_seq.data

        # look at the annotations of the SeqRecord
        assert test_item.annotations["gi"] == ["16229"], \
          "Unexpected gi annotation: %s" % test_item.annotations["gi"]
        assert test_item.annotations["keywords"] == \
          ['antifreeze protein homology', 'cold-regulated gene', 
           'cor6.6 gene', 'KIN1 homology'], \
           "Unexpected keywords: %s" % test_item.annotations["keywords"]

        # test the features of the SeqRecord
        assert len(test_item.features) == 3,  \
          "Unexpected features: %s" % test_item.features

        source_feature = test_item.features[0]
        assert source_feature.type == "source", \
          "Unexpected feature type: %s" % source_feature.type
        assert str(source_feature.location) == str(FeatureLocation(0, 513)), \
          "Unexpected feature location: %s" % source_feature.location
        assert source_feature.qualifiers["organism"] == \
          ["Arabidopsis thaliana"], \
          "Got unexpected organism: %s" % source_feature.qualifiers
        assert source_feature.qualifiers["db_xref"] == ["taxon:3702"], \
          "Got unexpected db_xref: %s" % source_feature.qualifiers

        cds_feature = test_item.features[2]
        assert cds_feature.type == "CDS", \
          "Unexpected feature_type: %s" % cds_feature.type
        assert str(cds_feature.location) == str(FeatureLocation(49, 250)), \
          "Unexpected location: %s" % cds_feature.location
        assert cds_feature.qualifiers["codon_start"] == ["1"], \
          "Unexpected codon_start: %s" % cds_feature.qualifiers
        assert cds_feature.qualifiers["db_xref"] == \
          ["GI:16230", "SWISS-PROT:P31169"], \
          "Unexpected db_xref: %s" % cds_feature.qualifiers

    def t_tricky_details(self):
        """Test potentially sneaky details of passing GenBank information.
        """
        test_item = self.database["X62281"]
        assert test_item.id == "X62281.1", \
          "Unexpected item: %s" % test_item.id
        
        # test passing over join information
        join_feature = test_item.features[6]
        assert join_feature.type == "CDS", \
          "Unexpected feature type: %s" % join_feature.type
        assert str(join_feature.location) == str(FeatureLocation(103, 579)), \
          "Unexpected location: %s" % join_feature.location
        assert join_feature.location_operator == "join", \
          "Unexpected location operator: %s" % join_feature.location_operator
        assert len(join_feature.sub_features) == 3, \
          "Unexpected sub_features: %s" % join_feature.sub_features

        assert str(join_feature.sub_features[0].location) == \
          str(FeatureLocation(103, 160)), \
          "Unexpected location: %s" % join_feature.sub_features[0].location
        
        # XXX with the current hack sub_feature BioCorba implementation to
        # support ORBit, type information is not passed across
        # assert join_feature.sub_features[0].type == "CDS", \
        #  "Unexpected type: %s" % join_feature.sub_features[0].type

        assert str(join_feature.sub_features[1].location) == \
          str(FeatureLocation(319, 390)), \
          "Unexpected location: %s" % join_feature.sub_features[1].location
        assert str(join_feature.sub_features[2].location) == \
          str(FeatureLocation(503, 579)), \
          "Unexpected location: %s" % join_feature.sub_features[2].location

        # test fuzzy location passing
        fuzzy_feature = test_item.features[3]
        assert fuzzy_feature.type == "prim_transcript", \
          "Unexpected feature type: %s" % fuzzy_feature.type
        assert str(fuzzy_feature.location) == \
          str(FeatureLocation(43, AfterPosition(579))), \
          "Unexpected fuzzy position: %s" % fuzzy_feature.location

if __name__ == "__main__":
    sys.exit(run_tests(sys.argv))

