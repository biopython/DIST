# Copyright 2000,2001 by Brad Chapman.  All rights reserved.
# This code is part of the Biopython distribution and governed by its
# license.  Please see the LICENSE file that should have been included
# as part of this package.
"""Deal with a Sequence object that doesn't have any identifier.

This holds a sequence that you can do operations on, but that doesn't
define any type of annotations like type, etc. This is similar to a
Bio.Seq object in biopython.
"""

# stubs generated from the idl
import BioCorba.bsane__POA.seqcore as seqcore__POA
import BioCorba.bsane.seqcore as seqcore
import BioCorba.bsane as bsane

# local classes
from BioCorba.Server.Bsane.Base import Removable, Identifiable
from BioCorba.Server.Bsane.Annotation import Annotatable
from BioCorba.Server.Seqcore.CorbaSeqFeature import SeqFeatureCollection
from BioCorba.Share.SeqFeature import _safe_give_keywords

# configuration variables
from BioCorba.biocorbaconfig import *

# biopython
from Bio import Alphabet

class AnonymousSequence(seqcore__POA.AnonymousSequence, Removable):
    """Represent a sequence class that only knows sequence information.

    This class inherets from two different classes:
    * seqcore__POA.AnonymousSequence - The skeleton code generated
    by the corba orb implementation defining the connection of this
    class with a corba server.
    * Removable - The corba class from which
    this class derives in the idl. This provides basic memory
    management features.
    """
    def __init__(self, sequence):
        """Initialize an AnonymousSequence object.

        Arguments:
        * seqeuence - A Bio.Seq object that we will use to get
        the information.
        """
        Removable.__init__(self)
        self._seq = sequence

    def remove(self):
        """Get rid of references to our sequence object when removed.
        """
        self._seq = None
        Removable.remove(self)

    def get_type(self):
        """Return the type of sequence represented in the object.

        Uses the alphabet of the sequence to guess at what type it
        is.
        """
        if isinstance(self._seq.alphabet, Alphabet.ProteinAlphabet):
            seq_type = seqcore.SeqType.PROTEIN
        elif isinstance(self._seq.alphabet, Alphabet.DNAAlphabet):
            seq_type = seqcore.SeqType.DNA
        elif isinstance(self._seq.alphabet, Alphabet.RNAAlphabet):
            seq_type = seqcore.SeqType.RNA
        else:
            seq_type = seqcore.SeqType.UNKNOWN

        return seq_type

    def is_circular(self):
        """Define if a sequence is circular or not.

        XXX Right now always return zero, since I'm not sure how we will be
        able to know this with the Biopython setup.
        """
        return 0

    def get_length(self):
        """Return the length of the seqeuence.
        """
        return len(self._seq)

    def seq(self):
        """Return the actual sequence.

        Raises:
        * RequestTooLarge - If the sequence length is greater than
        the MAX_SEQ_SIZE
        """
        if self.get_length() > MAX_SEQ_SIZE:
            exception = _safe_give_keywords(bsane.RequestTooLarge, 
              [("reason", 'Exceeds maximum sequence size to return'), 
               ('suggested_size', MAX_SEQ_SIZE)])
            raise exception

        return self._seq.data

    def sub_seq(self, start, end):
        """Retrieve a subsequence of the current sequence.

        Arguments:
        start - The first residue to get in the subsequence. This is
        in biological coordinates, so 1 is the first base.
        end - The last residue (inclusive) to get in the subsequence.

        Raises:
        * OutOfRange - If the call slices a region not in the sequence.
        * RequestTooLarge - If the slice requested is greater than
        MAX_SEQ_SIZE
        """
        # check the passed coordinates to make sure they are in the
        # sequence
        if start < 1:
            exception = _safe_give_keywords(bsane.OutOfBounds,
              [("reason", 'Start of subsequence is less then 1.')])
            raise exception
        elif end > self.get_length():
            exception = _safe_give_keywords(bsane.OutOfBounds,
              [("reason", "End of subsequence past sequence end.")])
            raise exception
        # check the size of the request
        elif (end - start) > MAX_SEQ_SIZE:
            exception = _safe_give_keywords(bsane.RequestTooLarge,
              [("reason", 'Exceeds maximum sequence size to return'), 
                ("suggested_size", MAX_SEQ_SIZE)])
            raise exception

        # Subtract one from the passed start and then get the slice to return
        # what the user is looking for.
        #
        # >>> s = Seq("ABCDEFG")
        # >>> s[1:4]
        # Seq('BCD', Alphabet())
        # >>> s[0:4]
        # Seq('ABCD', Alphabet())
        biopy_start = start - 1
        return self._seq[biopy_start:end].data

class AnnotatableSequence(seqcore__POA.AnnotatableSequence, Annotatable):
    """Mix-in class which allows a sequence to have annotations.

    This class expands on the more general Annotatable class by allowing
    a sequence to have SeqFeatures.

    This class presumes that the class it mixes in with defines an 
    attribute _record, which contains a SeqRecord object to get 
    information from.
    """
    def get_seq_features(self):
        """Return a collection of sequence features.
        """
        collection = SeqFeatureCollection(self._record.features)
        return collection.get_object()

class BioSequence(seqcore__POA.BioSequence, AnonymousSequence, Identifiable,
                  AnnotatableSequence):
    """Represent a biological sequence with features and id information.

    This representation expands on the basic AnonymousSequence type by
    adding the ability for the sequence to have IDs and sequence features.

    This class is roughly analagous to the SeqRecord class in Biopython,
    and to initiate a BioSequence you need to pass in a SeqRecord object.
    """
    def __init__(self, seq_record):
        """Initialize a BioSequence object from a biopython SeqRecord.
        """
        AnonymousSequence.__init__(self, seq_record.seq)
        Identifiable.__init__(self, seq_record)

        # XXX right now reference information isn't handled in BioCorba
        # so we won't pass references through
        if seq_record.annotations.has_key("references"):
            del seq_record.annotations["references"]
        self._record = seq_record

    def remove(self):
        """Add on to the standard remove to get rid of our seq_record
        """
        self._record = None
        AnonymousSequence.remove(self)

    def get_anonymous_sequence(self):
        """Return an anonymous sequence object corresponding to this sequence.
        """
        new_anon_seq = AnonymousSequence(self._record.seq)
        return new_anon_seq.get_object()

    def get_alphabet(self):
        raise bsane.DoesNotExist(reason = "This function has been removed.")
