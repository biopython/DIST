"""General annotation objects in Bsane.

This module defines generally classes which describe annotations in
the Bsane/Biocorba IDLs. These basic classes are inherited from to
provide specific biological objects.
"""
# IDL derived stubs and skeletons
import BioCorba.bsane__POA as bsane__POA
import BioCorba.bsane as bsane

# local classes
from BioCorba.Server.Bsane.Base import Base, Removable, Iterator, _ListIterator
from BioCorba.Share.SeqFeature import _safe_give_keywords

# biopython
from Bio.SeqRecord import SeqRecord
from Bio.SeqFeature import SeqFeature

class Annotation(bsane__POA.Annotation, Removable):
    """Represent an annotation on an object.

    This class is kind of a beefed up name-value pair (ie. from a 
    GenBank entry).
    """
    def __init__(self, name, value, basis = bsane.Basis.NOT_KNOWN):
        """Intialize the annotation with its values.

        Arguments:

        o name - A string name of the annotation.

        o value - The value of the annotation. This can potentially be
        an object of any kind. Right now we can only handle strings.

        o basis - A number (0 - 4) specifying the basis for making
        the annotation. See the bsane.idl file and Basis interface for
        a description of the potential values. By default, we just 
        assume we don't know anything about the annotation basis. Since
        biopython doesn't really handle this right now, this implementation
        mostly assumes we are punting on this.
        """
        Removable.__init__(self)
        self.name = name
        self.value = value
        self.basis = basis

    def get_name(self):
        """Retrieve the string name of the annotation.
        """
        return self.name

    def get_value(self):
        """Retrieve the value, which can potentially be of any type.

        Right now this implementation only handles simple types, and
        punts if we find anything else.
        """
        if type(self.value) == type(""):
            typecode = self._server.string_typecode()
            return self._server.get_any(typecode, self.value)
        elif type(self.value) == type(1.0):
            typecode = self._server.double_typecode()
            return self._server.get_any(typecode, self.value)
        else:
            raise ValueError("Unhandled value type found: %r" % self.value)

    def get_basis(self):
        """The basis on which this annotation is determined to be correct.
        """
        possible_values = [bsane.Basis.NOT_KNOWN, bsane.Basis.EXPERIMENTAL,
                           bsane.Basis.COMPUTATIONAL, bsane.Basis.BOTH,
                           bsane.Basis.NOT_APPLICABLE]

        assert self.basis in possible_values, \
          "Unexpected basis value %s" % self.basis
        return self.basis
        
class AnnotationCollection(bsane__POA.AnnotationCollection, Base):
    """Hold a number of annotations categorized by name and provie access.

    This class is instantiated with a dictionary of annotations (from a
    SeqRecord object, for instance), where the keys of the dictionary 
    are the names of the annotations, and the values are the annotations
    themselves.
    """
    def __init__(self, annotation_dict):
        Base.__init__(self)
        self._annotations = annotation_dict

    def get_num_annotations(self):
        """Return the total number of annotations contained.
        """
        num_annotations = 0
        for key in self._annotations.keys():
            if type(self._annotations[key]) == type([]) or \
               type(self._annotations[key]) == type(()):
                num_annotations += len(self._annotations[key])
            elif type(self._annotations[key]) == type("") or \
                 type(self._annotations[key]) == type(0.0):
                num_annotations += 1
            else:
                raise ValueError("Unexpected annotation type: %r" %
                                 self._annotations[key])
        return num_annotations

    def get_annotations(self, how_many):
        """Retrieve a specified number of annotations.
        """
        # first get all of the annotations contained in this object
        annotations = []
        # sort the keys so that we always return things in the same order
        sorted_keys = self._annotations.keys()
        sorted_keys.sort()

        for key in sorted_keys:
            new_annotations = self._annotations_for_key(key)
            annotations.extend(new_annotations)

        # now split all of the annotations into the list to return
        # and an iterator with the rest of them
        annotation_list = annotations[:how_many]
        iterator_list = annotations[how_many:]
        iterator = Iterator(_ListIterator(iterator_list))

        return annotation_list, iterator.get_object()
        
    def _annotations_for_key(self, key):
        """Retrieve a set of CORBAified Annotation objects from a name.

        This will raise a ValueError if the name is not found.
        """
        annotation_values = self._annotations[key]
        # if we only get back one value, make it a list so we can
        # deal with everything as a list later
        if type(annotation_values) != type([]) and \
           type(annotation_values) != type(()):
            annotation_values = [annotation_values]

        # turn all of the values into CORBAified object for returning
        all_annotations = []
        for value in annotation_values:
            new_annotation = Annotation(key, value)
            all_annotations.append(new_annotation.get_object())

        return all_annotations
            
    def get_annotations_by_name(self, name):
        """Retrieve annotations based on their name identifier.
        """
        try:
            return self._annotations_for_key(name)
        except KeyError:
            exception = _safe_give_keywords(bsane.IdentifierNotResolvable,
             [("id", name), ("reason", "Name not found. Valid names are %s" 
               % self._annotations.keys())])
            raise exception
        
class Annotatable(bsane__POA.Annotatable):
    """Mix-in class which provides the ability to return object annotations.
    
    This class presumes the the class we mixin with has a _record attribute
    defining a SeqRecord object.
    """
    def get_annotations(self):
        """Retrieve annotations of this object as an annotation collection.
        """
        # deal with the different cases for annotations that we can
        # have. Note: This is ugly -- I should be able to do this in
        # a more general way.
        if isinstance(self._record, SeqRecord):
            annotations = self._record.annotations
        elif isinstance(self._record, SeqFeature):
            annotations = self._record.qualifiers
        elif type(self._record) == type({}):
            annotations = self._record
        else:
            raise ValueError("Unexpected record type: %r" % self._record)

        ann_collection = AnnotationCollection(annotations)
        return ann_collection.get_object()


