# Copyright 2000 by Brad Chapman.  All rights reserved.
# This code is part of the Biopython distribution and governed by its
# license.  Please see the LICENSE file that should have been included
# as part of this package.
"""Module dealing with SeqFeature objects

This allows a client interface to features on sequences.
"""
# client corba stub code
import BioCorba.bsane as bsane
import BioCorba.bsane.seqcore as seqcore

# local stuff
from BioCorba.Client.Bsane import CorbaExceptions
from BioCorba.Client.Bsane.Annotation import AnnotationCollection 
from BioCorba.Client.Bsane.Annotation import Annotation, Annotatable
from BioCorba.Client.Bsane.Base import Iterator
from BioCorba.Share.SeqFeature import _CorbaLocationConverter

# Biopython
from Bio import SeqFeature

class SeqFeature(Annotation, Annotatable):
    """Represent a Feature on a biological sequence object.
    """
    def __init__(self, corba_object):
        assert corba_object is not None, "Nil object reference."
        self._object = self._safe_narrow(corba_object,
                                         seqcore.SeqFeature)
        assert self._object is not None, \
                    "Could not narrow to SeqFeature."

    def get_start(self):
        """Retrieve the start location of the SeqFeature.
        
        This returns a number, with 1 being the first base.
        """
        return self._object.get_start()

    def get_end(self):
        """Retrieve the end location of the SeqFeature.
        """
        return self._object.get_end()

    def get_locations(self):
        """Return locations of the SeqFeature along the sequence.

        This will return a list of SeqFeature objects which are the
        potentially fuzzy locations on the sequence the feature is 
        describing.
        """
        location_list = self._object.get_locations()

        # convert the locations into biopython SeqFeatures
        location_info = []
        location_converter = _CorbaLocationConverter()
        for location in location_list:
            biopy_location = location_converter.to_biopython_feature(location)
            location_info.append(biopy_location)
        return location_info

    def get_owner_sequence(self):
        """Retrieve the AnonymousSequence object the SeqFeature describes.
        """
        from CorbaSequence import AnonymousSequence
        try:
            anon_seq = self._object.get_owner_sequence()
        except bsane.DoesNotExist, info:
            raise CorbaExceptions.DoesNotExist(info.reason)

        return AnonymousSequence(anon_seq)

class SeqFeatureCollection(AnnotationCollection):
    """Define a collection of sequence features and methods for retrieving em.
    """
    def __init__(self, corba_object):
        # AnnotationCollection.__init__(self, corba_object)
        
        assert corba_object is not None, "Nil object reference."
        self._object = self._safe_narrow(corba_object,
                                         seqcore.SeqFeatureCollection)
        assert self._object is not None, \
               "Could not narrow to SeqFeatureCollection."

    def get_features_on_region(self, num_features, seq_region):
        """Retrieve sequence features from a region of the sequence.

        This returns two items. The first is a list of SeqFeatures
        in the region, which will be, at max, the specified num_features.
        The second item is an Iterator with the remaining items (if any)
        in the region.

        seq_region should be a biopython location object. This will be 
        converted to the appropriate CORBA representation before being
        sent.
        """
        location_converter = _CorbaLocationConverter()
        corba_region = location_converter.from_biopython_location(seq_region) 
        try:
            seq_features, iterator = \
              self._object.get_features_on_region(num_features,
                                                  corba_region)
        except seqcore.SeqFeatureLocationOutOfBounds, info:
            raise CorbaExceptions.SeqFeatureLocationOutOfBounds(info.invalid,
                                                                info.valid)
        except seqcore.SeqFeatureLocationInvalid, info:
            raise CorbaExceptions.SeqFeatureLocationInvalid(info.reason)

        # convert all of the seq_features into local objects
        local_features = []
        for seq_feature in seq_features:
            local_features.append(SeqFeature(seq_feature))

        # convert the iterator into a local iterator object
        local_iterator = SeqFeatureIterator(iterator)

        return local_features, local_iterator

    def num_features_on_region(self, seq_region):
        """Return the number of sequence features in the specified region.
        
        seq_region should be a biopython location object. This will be 
        converted to the appropriate CORBA representation before being
        sent.
        """
        location_converter = _CorbaLocationConverter()
        corba_region = location_converter.from_biopython_location(seq_region) 
        try:
            return self._object.num_features_on_region(corba_region)
        except seqcore.SeqFeatureLocationOutOfBounds, info:
            raise CorbaExceptions.SeqFeatureLocationOutOfBounds(info.invalid,
                                                                info.valid)
        except seqcore.SeqFeatureLocationInvalid, info:
            raise CorbaExceptions.SeqFeatureLocationInvalid(info.reason)

class SeqFeatureIterator(Iterator):
    """Define an iterator which returns SeqFeature objects.
    """
    def _check_iterator_item(self, item):
        """Verify each item from an iterator is a SeqFeature.

        This checks the validity of the items, and also maps them to a
        local SeqFeature object.
        """
        return SeqFeature(item)
