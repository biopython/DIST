"""Client side interface to Database-like objects.

This module provides code to deal with Collections in Bsane. These
collections are like dictionaries in Biopython, and allow retrieval
of items by ids.
"""
# stubs and skeletons
import BioCorba.bsane as bsane
import BioCorba.bsane.collection as collection

# other biopython-corba classes
from BioCorba.Client.Bsane import CorbaExceptions
from BioCorba.Client.Bsane.Base import Removable, Identifiable
from BioCorba.Client.Seqcore.CorbaSequence import BioSequence
from BioCorba.Client.Seqcore.CorbaSequence import BioSequenceIterator
from BioCorba.Client.Bsane.Annotation import Annotatable

class BioSequenceIdentityResolver:
    """Mix-in class to provide the ability to get BioSequences by id.
    """
    def resolve(self, id):
        """Retrieve a BioSequence object for a given id.
        """
        try:
            bio_seq = self._object.resolve(id)
        except bsane.IdentifierDoesNotExist, info:
            raise CorbaExceptions.IdentifierDoesNotExist(info.id)
        except bsane.IdentiferNotResolvable, info:
            raise CorbaExceptions.IdentifierDoesNotExist(info.id,
                                                         info.reason)
        except bsane.IdentifierNotUnique, info:
            raise CorbaExceptions.IdentifierNotUnique(info.id,
                                                      info.ids)
        return BioSequence(bio_seq)

class BioSequenceCollection(BioSequenceIdentityResolver, Identifiable,
                            Annotatable, Removable):
    """Main interface for accessing a CORBA database of items.
    
    This is the interface to use to access BioSequences in a dictionary-like
    manner.
    """
    def __init__(self, corba_object):
        Removable.__init__(self, corba_object)
        assert corba_object is not None, "Nil object reference."
        self._object = self._safe_narrow(corba_object, 
                                         collection.BioSequenceCollection)
        assert self._object is not None, \
          "Could not narrow to a BioSequenceCollection."

    def get_seqs(self, how_many):
        """Retrieve the specified number of sequences from the collection.

        This returns how_many BioSequences as a list, and returns an
        Iterator to the rest of the collection.
        """
        seq_list, iterator = self._object.get_seqs(how_many)
        # change the seq_list to local objects
        local_bioseqs = []
        for bioseq in seq_list:
            local_bioseqs.append(BioSequence(bioseq))

        # change the iterator to a local iterator
        local_iterator = BioSequenceIterator(iterator)

        return local_bioseqs, local_iterator
        
