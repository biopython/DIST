# Copyright 2000-2001 by Brad Chapman.  All rights reserved.
# This code is part of the Biopython distribution and governed by its
# license.  Please see the LICENSE file that should have been included
# as part of this package.
"""AnonymousSequence interface

Holds a sequence object representation with sequence information only (no
names or features on the sequence).
"""
# corba stubs
import BioCorba.bsane.seqcore as seqcore
import BioCorba.bsane as bsane

# local classes
from BioCorba.Client.Bsane.Base import Removable, Identifiable, Iterator
from BioCorba.Client.Bsane.Annotation import Annotatable
from BioCorba.Client.Bsane import CorbaExceptions
from CorbaSeqFeature import SeqFeatureCollection

class AnonymousSequence(Removable):
    def __init__(self, corba_object):
        """Confirm AnonymousSequence object and setup local implementation.

        Arguments:
        o corba_object - A reference to a remote AnonymousSequence object.
        """
        Removable.__init__(self, corba_object)
        assert corba_object is not None, "Nil object reference."
        self._object = self._safe_narrow(corba_object,
                                         seqcore.AnonymousSequence)
        assert self._object is not None, \
               "Could not narrow to AnonymousSequence."

    def get_length(self):
        return self._object.get_length()

    def get_type(self):
        seq_type = self._object.get_type()

        if seq_type == seqcore.SeqType.PROTEIN:
            return_type = 'PROTEIN'
        elif seq_type == seqcore.SeqType.DNA:
            return_type = 'DNA'
        elif seq_type == seqcore.SeqType.RNA:
            return_type = 'RNA'
        elif seq_type == seqcore.SeqType.UNKNOWN:
            return_type = 'UNKNOWN'
        else:
            raise ValueError("Unexpected sequence type %s" % seq_type)

        return return_type

    def is_circular(self):
        return self._object.is_circular()

    def seq(self):
        try:
            return self._object.seq()
        except bsane.RequestTooLarge, info:
            raise CorbaExceptions.RequestTooLarge(info.reason,
                                                  info.suggested_size)

    def sub_seq(self, start, end):
        try:
            return self._object.sub_seq(start, end)
        except bsane.RequestTooLarge, info:
            raise CorbaExceptions.RequestTooLarge(info.reason,
                                                  info.suggested_size)
        except bsane.OutOfBounds, info:
            raise CorbaExceptions.OutOfBounds(info.reason)

class AnnotatableSequence(Annotatable):
    """Mix-in class which defines a sequence as able to be annotated.

    In addition to annotatable functions, this provides the ability
    to retrieve sequence features.
    """
    def get_seq_features(self):
        """Retrieve all of the features for a sequence.

        Returns a SeqFeatureCollection that can be used to act on
        the sequence.
        """
        collection = self._object.get_seq_features()
        return SeqFeatureCollection(collection)

class BioSequence(AnonymousSequence, Identifiable, AnnotatableSequence):
    """A full-scale sequence object with features and all the fixins.

    This class represents a sequence with an id, name and description,
    and also (potentially) a full set of features describing the object.
    """
    def __init__(self, corba_object):
        AnonymousSequence.__init__(self, corba_object)

        assert corba_object is not None, "Nil object reference."
    
        self._object = self._safe_narrow(corba_object, seqcore.BioSequence)
        assert self._object is not None, \
               "Could not narrow to BioSequence."

    def get_anonymous_sequence(self):
        """Retrieve a corresponding sequence lacking features.

        This function allows you to retrieve a corresponding
        AnonymousSequence without any features, ids, etc. You could
        then free this object using remove().
        """
        anonymous_seq = self._object.get_anonymous_sequence()
        return AnonymousSequence(anonymous_seq)

class BioSequenceIterator(Iterator):
    """Define an iterator which returns BioSequence objects.
    """
    def _check_iterator_item(self, item):
        """Verify each item from an iterator is a BioSequence
        """
        return BioSequence(item)

class NucleotideSequence(BioSequence):
    """DNA or RNA sequences of nucleotides (GATC) with extra operations.

    This class represents specifically a sequence of nucleotides. Since
    we know the sequence is not protein, we can do extra operations on
    it we wouldn't normally be able to do.
    """
    def __init__(self, corba_object):
        BioSequence.__init__(self, corba_object)

        assert corba_object is not None, "Nil object reference."
    
        self._object = self._safe_narrow(corba_object, 
                                         seqcore.NucleotideSequence)
        assert self._object is not None, \
               "Could not narrow to NucleotideSequence."

        raise NotImplementedError("Nucleotide sequences aren't ready yet.")

    def reverse_complement(self):
        pass

    def reverse_complement_internal(self):
        pass

    def translate_seq(self, reading_frame):
        pass

    def translate_seq_region(self, seq_region):
        pass
