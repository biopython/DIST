"""Module providing basic client functionality derived from Bsane stuff.

This is just a place for useful modules that don't really fit anywhere
else. These will probably not need to be called directly by code
using BioCorba, and are instead meant to help with implementations.
"""
import sys

from BioCorba.Client import BiocorbaConnect
from BioCorba.biocorbaconfig import orb_implementation
import CorbaExceptions

import BioCorba.bsane as bsane

# define a StopIteration exception for older python versions
if sys.version_info < (2, 2):
    class StopIteration(Exception):
        pass
# otherwise use the standard StopIteration
else:
    StopIteration = StopIteration

class CorbaBase:
    """A main base class providing some CORBA interoperability functionality.

    All classes should inherit from this class, which just provides
    inter-ORB interoperability.
    """
    def __init__(self, corba_object):
        self._object = corba_object

    def _safe_narrow(self, corba_object, interface):
        """This performs a narrow that works around brokenness in some ORBs

        Right now orbit-python has a _narrow function, but it seems to
        cause seg-faults like crazy. This avoids calling _narrow if
        orbit-python is the ORB.
        """
        if orb_implementation == "ORBit":
            return corba_object
        else:
            return corba_object._narrow(interface)

    def _string_typecode(self):
        """Return the typecode value of a string.
        """
        if orb_implementation == "omniORB":
            from omniORB import CORBA
            return CORBA.TC_string
        elif orb_implementation == "ORBit":
            import CORBA
            return CORBA.TypeCode("IDL:CORBA/String:1.0")
        elif orb_implementation == "Fnorb":
            from Fnorb.orb import CORBA
            return CORBA.TC_string
        else:
            raise NotImplementedError("Haven't done string typecode yet.")

    def _double_typecode(self):
        """Return the typecode value of a double.
        """
        if orb_implementation == "omniORB":
            from omniORB import CORBA
            return CORBA.TC_double
        elif orb_implementation == "ORBit":
            import CORBA
            return CORBA.TypeCode("IDL:CORBA/Double:1.0")
        elif orb_implementation == "Fnorb":
            from Fnorb.orb import CORBA
            return CORBA.TC_double
        else:
            raise NotImplementedError("Double typecode not done for this ORB.")

    def _get_any_info(self, corba_any):
        """Retrieve the typecode and value of an any.

        This varies between ORBs, so the ORB specific details are here.
        """
        if orb_implementation == "omniORB":
            return corba_any.typecode(), corba_any.value()
        elif orb_implementation == "ORBit":
            return corba_any.tc, corba_any.value
        elif orb_implementation == "Fnorb":
            return corba_any.typecode(), corba_any.value()
        else:
            raise NotImplementedError("Haven't dealt with anys yet.")

class Removable(CorbaBase):
    """Memory Management base class for disposing of objects.

    Almost all object should inherit from this base class, which tries
    to deal with memory managment issues. When an object it deleted, this
    calls remove on the object to get rid of it from the server.
    """
    def __init__(self, corba_object):
        CorbaBase.__init__(self, corba_object)
        self._object = corba_object

    def __del__(self):
        if self._object:
            try:
                self.remove()
            # if we get a CORBA.COMM_FAILURE the server died
            # and we just won't worry about unrefing
            except BiocorbaConnect.COMM_FAILURE:
                pass
            # if we get OBJECT_NOT_EXIST, we've already got rid of the
            # server item, so we don't need to do it again
            except BiocorbaConnect.OBJECT_NOT_EXIST:
                pass
            # ditto with NO_IMPLEMENT
            except BiocorbaConnect.NO_IMPLEMENT:
                pass

    def remove(self):
        self._object.remove()

class Identifiable:
    """Provide an object with the ability to identify itself.

    This class provides basic functionality for retrieving information about
    what an object (ie. name, description, etc). This class should be
    used as a mix-in type class to provide ID functionality.
    """
    def get_id(self):
        """Retrieve a string Identifier for the object.
        """
        return self._object.get_id()

    def get_name(self):
        """Return a human readable name for the object.
        """
        return self._object.get_name()

    def get_description(self):
        """Return a description of the object.
        """
        return self._object.get_description()

    def get_basis(self):
        """Query the experimental basis for an object.

        This defines under what conditions a biological object was
        identified.
        """
        basis_num = self._object.get_basis()

        if basis_num == bsane.Basis.NOT_KNOWN:
            return "not known"
        elif basis_num == bsane.Basis.EXPERIMENTAL:
            return "experimental"
        elif basis_num == bsane.Basis.COMPUATIONAL:
            return "computational"
        elif basis_num == bsane.Basis.BOTH:
            return "experimental and computational"
        elif basis_num == bsane.Basis.NOT_APPLICABLE:
            return "not applicable"
        else:
            raise ValueError("Got unexpected number for basis: %s" % basis_num)
    
class Iterator(Removable):
    """Generic Iterator to retrieve objects one at a time.
    """
    def __init__(self, corba_object):
        Removable.__init__(self, corba_object)
        
        assert corba_object is not None, "Nil object reference."
        self._object = self._safe_narrow(corba_object, bsane.Iterator)
        assert self._object is not None, \
               "Could not narrow to Iterator"

    def _check_iterator_item(self, item):
        """Hook for inheriting classes that allows them to verify objects.

        This allows an inherited class to narrow an object to confirm it,
        and hook it up to some local implementation. By default, it
        just returns the item. To change this, inherit from the class
        and override the function.
        """
        return item

    def next(self):
        """Retrieve the next item from the iterator.

        If we've reached the end of the iterator, this will raise
        a StopIteration error (this coincides with how Iterators work
        in Python 2.2).
        """
        try:
            is_okay, next_object = self._object.next()
        except bsane.IteratorInvalid, info:
            raise CorbaExceptions.IteratorInvalid(info.reason)

        if not(is_okay) and next_object is None:
            raise StopIteration
        else:
            return self._check_iterator_item(next_object)

    def next_n(self, how_many):
        """Retreives the next set of items from the Iterator.

        This works like next(), except that it retrieves a specified number
        of items as a list.
        """
        try:
            is_done, next_object_list = self._object.next()
        except bsane.IteratorInvalid, info:
            raise CorbaExceptions.IteratorInvalid(info.reason)

        if is_done:
            raise StopIteration
        else:
            checked_items = []
            for next_object in next_object_list:
                checked_items.append(self._check_iterator_item(next_object))

            return checked_items
        
