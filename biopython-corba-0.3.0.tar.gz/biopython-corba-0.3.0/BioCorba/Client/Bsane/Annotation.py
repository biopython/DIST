"""Classes to deal with general annotations on objects.
"""
from Base import Removable, Identifiable, Iterator, CorbaBase
import CorbaExceptions

import BioCorba.bsane as bsane

class Annotation(Removable, Identifiable):
    """Hold a basic annotation of an object.

    You will probably want to inherit from Annotation (or a class the
    derived from it) and over-ride the get_value function. get_value
    returns a CORBA Any, so you will need some specialized information
    about the context to determine how to deal with it.
    """
    def __init__(self, corba_object):
        Removable.__init__(self, corba_object)
        assert corba_object is not None, "Nil object reference."

        self._object = self._safe_narrow(corba_object, bsane.Annotation)
        assert self._object is not None, \
               "Could not narrow to Annotation."
    
    # --- override those Identifiable functions that Annotations do
    # not actually provide
    def get_id(self):
        raise NotImplementedError("Annotation doesn't have this.")
    def get_description(self):
        raise NotImplementedError("Annotation doesn't have this.")

    def get_value(self):
        """Retrieve the information in the annotation.

        Note: This returns a CORBA::Any, so you'll probably need to know
        what to expect.

        By default we try to handle common types. 
        """
        any_item = self._object.get_value()

        item_typecode, item_value = self._get_any_info(any_item)
        # handle the string type -- note: we handle the comparison using
        # str()s because orbit-python doesn't likt to compare straight
        # TypeCodes. Hopefully this will work portably across ORBs.
        if str(item_typecode) == str(self._string_typecode()) or \
           item_typecode == self._string_typecode(): 
            return item_value
        elif str(item_typecode) == str(self._double_typecode()) or \
           item_typecode == self._double_typecode():
            return item_value
        # pass anything else out as an any
        else:
            return any_item

class AnnotationIterator(Iterator):
    """Define an iterator which return Annotation objects.
    """
    def _check_iterator_item(self, item):
        """Return each item in the iterator wrapped around an Annotation.
        """
        return Annotation(item)

class AnnotationCollection(CorbaBase):
    """Hold a list of Annotations for retrieval.
    """
    def __init__(self, corba_object):
        CorbaBase.__init__(self, corba_object)
        
        assert corba_object is not None, "Nil object reference."

        self._object = self._safe_narrow(corba_object,
                                         bsane.AnnotationCollection)
        assert self._object is not None, \
               "Could not narrow to AnnotationCollection."        
    
    def get_num_annotations(self):
        """Return the number of annotations available in the collection.
        """
        return self._object.get_num_annotations()

    def get_annotations(self, how_many):
        """Retrieve the specified number of annotations from the collection.

        This function returns two items. The first is a list of the specified
        annotations, and the second is an Iterator with the remaining
        annotations in the collection.
        """
        annotations, iterator = self._object.get_annotations(how_many)

        # convert the annotations into local representations
        local_annotations = []
        for annotation in annotations:
            local_annotations.append(Annotation(annotation))

        return local_annotations, AnnotationIterator(iterator)

    def get_annotations_by_name(self, name):
        """Retrieve annotations based on name.

        Returns a list of annotation objects having the given name.
        """
        try:
            annotations = self._object.get_annotations_by_name(name)
        except bsane.IdentifierNotResolvable, info:
            raise CorbaExceptions.IdentifierNotResolvable(info.id, info.reason)

        # convert the annotations into local representations
        local_annotations = []
        for annotation in annotations:
            local_annotations.append(Annotation(annotation))
        return local_annotations

class Annotatable:
    """Mix-in class to allow an object to return annotations.
    """
    def get_annotations(self):
        """Retrieve a collection of annotations for the object.
        """
        collection = self._object.get_annotations()

        return AnnotationCollection(collection)

