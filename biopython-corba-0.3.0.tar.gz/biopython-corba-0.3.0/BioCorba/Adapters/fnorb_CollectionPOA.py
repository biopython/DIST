"""Adapters around actual Fnorb stubs so they behave like the python
 mapping.

Each class does two things:
1. Inherets from the actual skel, so that the inheritence in the main code
can be uniform.

2. Defines a _this() function which creates a unique object ref for a
class object, and registers it with the boa.
"""
# import the General Adapter code
from BioCorba.Adapters.Generic import GenericFnorbAdapter

# import the actual skeleton code
import BioCorba.bsane_skel.collection_skel as skel_base
       
class BioSequenceIdentifierResolver( \
  skel_base.BioSequenceIdentifierResolver_skel, GenericFnorbAdapter):
    unique_name = 'BioSequenceIdentifierResolver'
       
class BioSequenceCollection(skel_base.BioSequenceCollection_skel,
                            GenericFnorbAdapter):
    unique_name = 'BioSequenceCollection'

class TreeNode(skel_base.TreeNode_skel, GenericFnorbAdapter):
    unique_name = 'TreeNode'
