"""Shared classes used by client and server SeqFeature implementations.

This module contains SeqFeature related classes which can be used by
both the client and the server. In general, none of these classes should
need to be called by a BioCorba user, and are only for the internal
implementation.
"""
# biocorba stubs
import BioCorba.bsane.seqcore as seqcore

# other biopython-corba stuff
from BioCorba.Client.Bsane.Base import StopIteration

# biopython
from Bio import SeqFeature


def _get_annotations(corba_object):
    """Retrieve a dictionary of annotations for this object.

    This is a helper function to convert an object's annotations into
    a dictionary. corba_object must implement the Annotatable (ie.
    you must be able to call get_annotations on it).
    """
    annotations = {}

    # get all of the annotations through an iterator interface
    ann_collection = corba_object.get_annotations()
    empty_list, iterator = ann_collection.get_annotations(0)
    assert len(empty_list) == 0, "Got unexpected annotations."

    while 1:
        try:
            cur_ann = iterator.next()
        except StopIteration:
            break

        cur_name = cur_ann.get_name()
        cur_value = cur_ann.get_value()

        # if we already have an annotation of this name, add it on
        if annotations.has_key(cur_name):
            annotations[cur_name].append(cur_value)
        # otherwise start up a new list of annotations
        else:
            annotations[cur_name] = [cur_value]

    return annotations

# set up a keywords converter to use
def _safe_give_keywords(new_class, arg_tuples):
    """This provides a safe way of passing args to different ORBs.

    The different python ORBs have different semantics required when
    applying arguments to structs and expections. ORBit-python 
    requires using argument names, while Fnorb doesn't allow it all
    all. 

    This helps deal with this effectively. new_class is the class to
    create, and arg_tuples ia s two tuple list of the arguments, ie.
    [("arg1name", "arg1argument"), ("arg2name", "arg2argument")]
    """
    try:
        arg_dict = {}
        for arg_name, arg in arg_tuples:
            arg_dict[arg_name] = arg
        return apply(new_class, [], arg_dict)
    except TypeError:
        args = []
        for arg_name, arg in arg_tuples:
           args.append(arg)
        return apply(new_class, args)

class _CorbaLocationConverter:
    """Internal class which converts Corba struct-based locations.

    This is basically used to convert Corba locations into their 
    biopython representations.
    """
    def __init__(self):
        pass

    def from_biopython_feature(self, feature):
        """Convert the given biopython SeqFeature into a CORBA location.
        """
        assert isinstance(feature, SeqFeature.SeqFeature), \
          "Expected a SeqFeature object to work with."
        # convert the initial location information
        corba_location = self.from_biopython_location(feature.location)

        # set the other attributes of the SeqFeatureLocation
        corba_location.seq_location.strand = \
          self._corba_strand_from_biopy(feature.strand)
        corba_location.region_operator = \
          self._region_from_location(feature.location_operator)
        corba_location.id = feature.id

        # now recursively convert the sub-locations
        sub_locations = []
        for sub_feature in feature.sub_features:
            # convert the entire feature, and then just add on the
            # seq_location to the sub_seq_locations
            new_location = self.from_biopython_feature(sub_feature)
            sub_locations.append(new_location.seq_location)
        corba_location.sub_seq_locations = sub_locations

        return corba_location

    def from_biopython_location(self, location):
        """Convert a biopython location object into a CORBA location.
        """
        # first convert the start and end into SeqFeaturePositions
        corba_start = \
          self._biopy_to_corba_position(location.start)
        # convert the start from biopython coordinates to BioCorba 
        # coordinates (which are 1 based)
        corba_start.position += 1
        corba_end = \
          self._biopy_to_corba_position(location.end)

        # just add default values for everything else
        corba_strand = seqcore.StrandType.NOT_KNOWN
        corba_id = "<unknown id>"
        corba_region_operator = seqcore.SeqFeatureLocationOperator.NONE

        simple_location = _safe_give_keywords(seqcore.SeqLocation,
          [("start", corba_start), ("end", corba_end),
            ("strand", corba_strand)])

        corba_location = _safe_give_keywords(seqcore.SeqFeatureLocation,
          [("seq_location", simple_location), 
            ("region_operator", corba_region_operator),
            ("sub_seq_locations", []),
            ("id", corba_id)])

        return corba_location

    def _biopy_to_corba_position(self, position):
        """Convert a position from biopython to CORBA representations.
        """
        corba_pos = position.position
        corba_ext = position.extension
        corba_fuzzy = self._corba_fuzzy_from_position_class(position)

        corba_position = _safe_give_keywords(seqcore.SeqFeaturePosition,
          [("position", corba_pos), ("extension", corba_ext),
            ("fuzzy", corba_fuzzy)])

        return corba_position

    def _corba_fuzzy_from_position_class(self, position):
        """Return the CORBA fuzzy representation for a Biopython position.

        In biopython the position types (ie. exact, within, etc.) are
        encoded as different position classes. This function extracts this
        information from the class type and returns the appropriate 
        CORBA representation.
        """
        if isinstance(position, SeqFeature.ExactPosition):
            return seqcore.FuzzyType.EXACT
        elif isinstance(position, SeqFeature.WithinPosition):
            return seqcore.FuzzyType.WITHIN
        elif isinstance(position, SeqFeature.BetweenPosition):
            return seqcore.FuzzyType.BETWEEN
        elif isinstance(position, SeqFeature.BeforePosition):
            return seqcore.FuzzyType.BEFORE
        elif isinstance(position, SeqFeature.AfterPosition):
            return seqcore.FuzzyType.AFTER
        else:
            raise ValueError("Unexpected position type: %r" % position)

    def _region_from_location(self, type):
        """Extract region (ie. join, order) info from a feature location

        This extracts the location information from a location_operator
        on the sequence feature.
        """
        if type.find("join") >= 0:
            return seqcore.SeqFeatureLocationOperator.JOIN
        elif type.find("order") >= 0:
            return seqcore.SeqFeatureLocationOperator.ORDER
        else:
            return seqcore.SeqFeatureLocationOperator.NONE

    def _corba_strand_from_biopy(self, strand):
        """Convert Biopython strand information in the CORBA represenation.

        The way I coded this in biopython is pretty messy, so I'm not sure
        yet if this handles all cases. Ugh!
        """
        if strand == 1:
            return seqcore.StrandType.PLUS
        elif strand == -1:
            return seqcore.StrandType.MINUS
        elif strand == 0:
            return seqcore.StrandType.BOTH
        elif strand is None:
            return seqcore.StrandType.NOT_APPLICABLE
        else:
            return seqcore.StrandType.NOT_KNOWN

    def to_biopython_feature(self, location):
        """Convert the given corba location into a Biopython SeqFeature stub.
        
        The returned SeqFeature object only has the information contained
        in a BioCorba SeqFeatureLocation, so might need to have additional
        information added afterwards, like the annotations on the feature.
        """
        biopy_feature = SeqFeature.SeqFeature()
        biopy_feature.location = \
          self._get_biopy_location(location.seq_location)
        biopy_feature.type = self._type_from_corba(location.region_operator)
        biopy_feature.location_operator = \
          self._type_from_corba(location.region_operator)
        biopy_feature.strand = \
          self._strand_from_corba(location.seq_location.strand)
        biopy_feature.id = location.id

        # recursively add on information for the sub_regions
        for sub_region in location.sub_seq_locations:
            sub_location = self._get_biopy_location(sub_region)
            new_feature = SeqFeature.SeqFeature()
            new_feature.location = sub_location
            new_feature.strand = self._strand_from_corba(sub_region.strand)
            biopy_feature.sub_features.append(new_feature)

        return biopy_feature

    def _get_biopy_location(self, location):
        """Retrieve a biopython location object for the given CORBA location.
        """
        start_position_class = \
        self._position_class(location.start.fuzzy)
        start_pos = self._get_position(start_position_class,
                                       location.start.position,
                                       location.start.extension)

        # convert the start position to biopython coordinates
        start_pos.position = start_pos.position - 1

        end_position_class = \
          self._position_class(location.end.fuzzy)
        end_pos = self._get_position(end_position_class,
                                     location.end.position,
                                     location.end.extension)

        biopy_location = SeqFeature.FeatureLocation(start_pos, end_pos)

        return biopy_location

    def _type_from_corba(self, corba_region):
        """Convert a BioCorba region_operator into a string type.
        """
        if corba_region == seqcore.SeqFeatureLocationOperator.NONE:
            return ""
        elif corba_region == seqcore.SeqFeatureLocationOperator.JOIN:
            return "join"
        elif corba_region == seqcore.SeqFeatureLocationOperator.ORDER:
            return "order"
        else:
            raise ValueError("Unexpected operator %s" % corba_region)

    def _strand_from_corba(self, strand):
        """Convert BioCorba strand information into the Biopython equivalent.
        """
        if strand == seqcore.StrandType.NOT_KNOWN:
            # XXX what is a good representation for this?
            return None
        elif strand == seqcore.StrandType.NOT_APPLICABLE:
            return None
        elif strand == seqcore.StrandType.PLUS:
            return 1
        elif strand == seqcore.StrandType.MINUS:
            return -1
        elif strand == seqcore.StrandType.BOTH:
            return 0
        else:
            raise ValueError("Unexpected strand type: %s" % strand)

    def _position_class(self, type_code):
        """Return a position class for a specific BioCorba FuzzyTypeCode.
        
        This maps the FuzzyTypeCodes of BioCorba to the Biopython
        position classes which represent the same information. This
        allows us to take care of fuzzy representations of locations.
        """
        if type_code == seqcore.FuzzyType.EXACT:
            return SeqFeature.ExactPosition
        elif type_code == seqcore.FuzzyType.WITHIN:
            return SeqFeature.WithinPosition
        elif type_code == seqcore.FuzzyType.BETWEEN:
            return SeqFeature.BetweenPosition
        elif type_code == seqcore.FuzzyType.BEFORE:
            return SeqFeature.BeforePosition
        elif type_code == seqcore.FuzzyType.AFTER:
            return SeqFeature.AfterPosition
        else:
            return ValueError("Unexpected FuzzyTypeCode value %s" % type_code)

    def _get_position(self, pos_class, position, extension):
        """Get the position object for a given class and position information.

        This handles checking for bad arguments (non-zero extensions where
        we shouldn't have any) and raises an error in these situations.
        """
        try:
            return pos_class(position, extension)
        except AttributeError:
            raise ValueError("Non-zero extension %s not accepted by %s"
                             % (extension, pos_class))

