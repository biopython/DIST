#!/usr/bin/env python
"""Start up a basic BioSequenceCollection server.

Right now this is mostly meant to fire up a server which can be used to
test the functionality of the Biopython client and server.

Right now has the following databases loaded up.
o cor_genbank - GenBank-based database of some cold tolerance genes

The IOR for the Collection server is written to the file ../ior/collection.ior

Usage:
python collection_server.py

The server will block and wait for client calls, so you need to run it
in the background if you want to run a client in the same window.
"""
# standard modules
import os
import string

# biopython
from Bio.Alphabet import IUPAC
from Bio import GenBank

# biopython-corba
from BioCorba.Server.Seqcore.CorbaCollection import BioSequenceCollection

# -- constants
ior_file = os.path.join(os.getcwd(), os.pardir, 'ior', 'collection.ior')
file_dir = os.path.join(os.getcwd(), os.pardir, 'Tests', 'files')

gb_file = os.path.join(file_dir, 'cor6_6.gb')
db_name = 'cor_genbank'
db_version = 1.0
db_description = "A small databse of cold resistance genes."

# create the IOR directory if it doesn't exist
if not(os.path.exists(os.path.dirname(ior_file))):
       os.makedirs(os.path.dirname(ior_file))

# load up Genbank files
print "loading information from %s" % gb_file    
    
# create the name of the index file
file_name, ext = os.path.splitext(gb_file)
index_file = file_name + '.idx'

# now index the file
GenBank.index_file(gb_file, index_file)

# now get the parser and set up the dictionary
seqfeat_parser = GenBank.FeatureParser()
db_dict = GenBank.Dictionary(index_file, seqfeat_parser)

# now setup the Collection server and write the IOR to a file
collection_server = BioSequenceCollection(db_dict, db_name, db_version,
                                          db_description)
collection_server.string_ior_to_file(ior_file)
print "Collection server is running. IOR is located at %s..." % ior_file

# run the server and wait for client calls
collection_server.run()
    
