"""build_helper.py

These are just a bunch of functions to help when building and installing
biopython-corba. These functions will be used when 'python setup.py
install' is run, and provide scripts to run idl compilers and install
"""
# standard modules
import os
import shutil
import tempfile
import string

# local stuff
from BioCorba.biocorbaconfig import supported_interfaces, orb_implementation

# --- constants
IDL_DIR = os.path.join(os.getcwd(), 'idl')
STUBS_DIRECTORY = os.path.join(os.getcwd(), 'BioCorba')
BIOCORBA_DIR = os.path.join(os.getcwd(), 'BioCorba')
# directories which may be created by idl compilers
GENERATED_DIRS = ["bsane", "bsane_skel", "bsane__POA", "Types", 
                  "Types__POA", "Types_skel"]

def _generate_stubs(idl_compiler, compiler_options, idl_name, remove_old):
    """Generic function to generate stubs and skeletons.

    Arguments:
    o idl_compiler - The name of the idl compiler to use.
    o compiler_options - A string of options to pass to the compiler.
    o idl_name - The name of the idl file to run the compiler on.
    o remove_old - Whether or not to clear out old generated files
    """
    # change into the directory with the idl files to generate them
    original_dir = os.getcwd()
    os.chdir(IDL_DIR)

    # remove any old stubs and skeletons
    if remove_old:
        _remove_old_stubs(idl_name, GENERATED_DIRS)

    print "Running %s on %s..." % (idl_compiler, idl_name)
    ret_val = os.system("%s %s %s" % (idl_compiler, compiler_options,
                                      idl_name))

    # if we got an abnormal return value, then we had problems with the
    # IDL compiler, and should stop installing.
    if ret_val != 0:
        warning_message = """WARNING:
        There was a problem with the idl compiler.
        See the error messages generated above for more information."""
        raise SystemExit(warning_message)

    # change back out of the directory
    os.chdir(original_dir)

def generate_omniorb_stubs(idl_name, remove_old = 1):
    """Compile idl files into stubs and skeletons for omniORB.

    Arguments:
    o idl_name - The name of the IDL file to run the idl compiler on.
    o remove_old - Whether or not to clear out old generated files
    """
    _generate_stubs("omniidl",
                    "-bpython -C../ -Wbpackage=BioCorba -I%s" % IDL_DIR,
                    idl_name, remove_old)

def generate_fnorb_stubs(idl_name, remove_old = 1):
    """Compile idl files into stubs and skeletons for Fnorb.

    Arguments:
    o idl_name - The name of the IDL file to run the idl compiler on.
    o remove_old - Whether or not to clear out old generated files
    """
    _generate_stubs("fnidl",
                   "--directory=../ --package=BioCorba -I%s" % IDL_DIR,
                   idl_name, remove_old)

    # apply patches for Fnorb to make it look like it follows
    # the standard mapping
    original_dir = os.getcwd()
    os.chdir(BIOCORBA_DIR)

    idl_type, ext = os.path.splitext(idl_name)
    apply_adapters('fnorb', idl_type)

    if idl_type == 'ensembl':
        for file in [os.path.join("org", "ensembl", "__init__.py"),
                     os.path.join("org_skel", "ensembl_skel", "__init__.py")]:
            print "patching %s..." % file
            patch_fnorb_generated_file(file)

    os.chdir(original_dir)

def patch_fnorb_generated_file(file):
    """Fnorb will generate junk imports such as:

    from BioCorba import org.biocorba.seqcore

    We need to find these and fix them to be valid imports.
    """
    input_handle = open(file, 'r')
    output_file = tempfile.mktemp()
    output_handle = open(output_file, 'w')

    old_import = "BLAH"
    new_import = "BLAH"
    while 1:
        cur_line = input_handle.readline()

        if not(cur_line):
            break

        if string.find(cur_line, "from BioCorba import") >= 0:
            bad_import, rest = string.split(cur_line, "from BioCorba import")
            rest = string.strip(rest)
            rest_parts = string.split(rest, '.')
            old_import = rest
            new_import = rest_parts[-1]
            
            new_line = "import BioCorba.%s as %s\n" % (old_import, new_import)
            output_handle.write(new_line)
        else:
            new_line = string.replace(cur_line, old_import, new_import)
            output_handle.write(new_line)

    # move the new file in place of the old
    input_handle.close()
    output_handle.close()

    # os.rename seems to be broken on *BSD machines (at least FreeBSD and
    # NetBSD), giving 'error: Cross-device link'
    # Thanks to Johann Visagie <johann@egenetics.com> for the workaround.
    
    # os.rename(output_file, file)
    input_handle = open(output_file, 'r')
    output_handle = open(file, 'w')
    S = input_handle.read()
    output_handle.write(S)
    input_handle.close()
    output_handle.close()

def generate_orbit_stubs(idl_name, remove_old = 1):
    """Move adapters to act as stubs and skeletons for ORBit.

    We now do stubs and skeletons for ORBit with import hacks, so all
    we need to do is clean out the old stubs from other IDL compilers.
    """
    original_dir = os.getcwd()
    os.chdir(BIOCORBA_DIR)   

    if remove_old:
        _remove_old_stubs(idl_name, GENERATED_DIRS)

    os.chdir(original_dir)

def _remove_old_stubs(idl_file, created_dirs):
    """Remove old stubs and skeletons from the given directory.

    This tries to clean out everything that might be generated by the idl
    compilers.

    Arguments:
    o idl_file - The name of the idl file which is generating the stubs.
    o created_dirs - A listing of all of the directories which might have
    been created by the idl compilers.
    """
    previous_dir = os.getcwd()
    os.chdir(STUBS_DIRECTORY)
    
    for c_dir in created_dirs:
        if os.path.exists(os.path.join(os.curdir, c_dir)):
            shutil.rmtree(os.path.join(os.curdir, c_dir))

    # create the name of the py file which is created by the omniidl compiler
    idl_base, ext = os.path.split(idl_file)
    gen_idl_file = idl_base + "_idl.py"

    # now remove it if it exists
    if os.path.exists(os.path.join(os.curdir, gen_idl_file)):
        os.remove(os.path.join(os.curdir, gen_idl_file))

    os.chdir(previous_dir)

def apply_adapters(orb_name, idl_type):
    """Apply the required adapters for the specified ORB name.

    Since CORBA implementations do not correspond exactly to the
    python mapping, we need to create adapters to act like they do.
    """
    # --- add the adapters for biocorba
    if idl_type == 'seqcore':
        print 'Adding adapters for bsane__POA...'

        os.mkdir(os.path.join(os.curdir, 'bsane__POA'))
        adapter_name = "%s_BsanePOA.py" % orb_name
        shutil.copy(os.path.join(os.curdir, 'Adapters', adapter_name),
                    os.path.join(os.curdir, 'bsane__POA', '__init__.py'))
        
        os.mkdir(os.path.join(os.curdir, 'bsane__POA', 'seqcore'))
        adapter_name = "%s_SeqcorePOA.py" % orb_name
        shutil.copy(os.path.join(os.curdir, 'Adapters', adapter_name),
                    os.path.join(os.curdir, 'bsane__POA', 'seqcore',
                                 '__init__.py'))

        os.mkdir(os.path.join(os.curdir, 'bsane__POA', 'collection'))
        adapter_name = "%s_CollectionPOA.py" % orb_name
        shutil.copy(os.path.join(os.curdir, 'Adapters', adapter_name),
                    os.path.join(os.curdir, 'bsane__POA', 'collection',
                                 '__init__.py'))

    # --- add the ensembl adapters
    if idl_type == 'ensembl':
        raise NotImplementedError("I haven't done ensembl for bsane yet!")

    print 'All adapters applied successfully.'

