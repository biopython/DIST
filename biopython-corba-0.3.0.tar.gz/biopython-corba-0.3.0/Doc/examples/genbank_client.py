#!/usr/bin/env python
"""Example code using the GenBank-like interfaces to BioCorba.
"""
# --- connect to the BioCorba server
from BioCorba.Client.BiocorbaConnect import PythonCorbaClient
from BioCorba.Client.Seqcore.CorbaCollection import BioSequenceCollection

ior_file = 'a_drought.ior'

client_loader = PythonCorbaClient(BioSequenceCollection)
client = client_loader.from_file_ior(ior_file)

from BioCorba.Bio import GenBank
feature_parser = GenBank.FeatureParser()
gb_dict = GenBank.Dictionary(client, feature_parser)

# --- use the GenBank object
accessions = gb_dict.keys()
print "Accessions:", accessions

seq_record = gb_dict['BE038456']
print "name:", seq_record.name
print "id:", seq_record.id
print "description:", seq_record.description
print "First 50 bases:", seq_record.seq[:50]
print "First SeqFeature:"
print "\tType:", seq_record.features[0].type
print "\tLocation:", seq_record.features[0].location
print "\tQualifiers:", seq_record.features[0].qualifiers
