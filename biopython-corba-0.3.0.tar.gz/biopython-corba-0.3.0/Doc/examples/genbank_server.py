#!/usr/bin/env python
"""Demonstrate how to make a GenBank file available through BioCorba.
"""
# --- first load up the GenBank file into a Biopython Dictionary
from Bio import GenBank

gb_file = "a_drought.gb"
index_file = "a_drought.idx"
GenBank.index_file(gb_file, index_file)
feature_parser = GenBank.FeatureParser()
gb_dictionary = GenBank.Dictionary(index_file, feature_parser) 

# --- Use the dictionary to create a server, and start it running

from BioCorba.Server.Seqcore.CorbaCollection import BioSequenceCollection

server = BioSequenceCollection(gb_dictionary, "Arabidopsis Drought Database", 
           1.0, "Putative Drought Resistance Genes in Arabidopsis")

print "Writing IOR to a file and starting the server..."
server.string_ior_to_file("a_drought.ior")
server.run()
