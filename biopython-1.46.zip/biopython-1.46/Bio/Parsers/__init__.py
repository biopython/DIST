"""Third party and other parsers useful internally to Biopython.
"""
