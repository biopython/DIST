
double PyNumber_AsDouble(PyObject *py_num);
